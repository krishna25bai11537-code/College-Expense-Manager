# 🎓 Smart College Expense Tracker — Spring Boot Backend

A complete, production-grade REST API backend engineered with **Java 17**, **Spring Boot 3**, **Spring Security 6**, **JWT Authentication**, **Spring Data JPA**, and **MySQL**, designed specifically for college students to track, manage, analyze, and split expenses.

---

## 🏗️ Architecture & Clean Layered Design

```
[React Frontend] (Port 3000)
       ↓ (HTTP REST / JWT Bearer)
[Spring Security & JwtAuthenticationFilter]
       ↓
[REST Controllers] (AuthController, ExpenseController, DashboardController, etc.)
       ↓
[Service Layer] (Business Logic, Mathematical Spending Score, Splitter Engine)
       ↓
[Spring Data JPA Repositories]
       ↓ (Hibernate ORM / Dialect)
[MySQL 8.0 Database] (college_expense_db)
```

---

## 📋 Technology Stack

* **Java**: 17+ (LTS)
* **Framework**: Spring Boot 3.2.3
* **Security**: Spring Security 6 with stateless JWT Bearer Token authorization
* **Password Encryption**: BCrypt hashing
* **Persistence**: Spring Data JPA / Hibernate
* **Database**: MySQL 8.0
* **Build Tool**: Apache Maven 3.8+
* **Exporting**: OpenCSV 5.9

---

## 🗄️ MySQL Database Setup

1. **Start your local MySQL service**:
   ```bash
   mysql -u root -p
   ```

2. **Create Database**:
   ```sql
   CREATE DATABASE college_expense_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```

3. **Configure Database Credentials in `src/main/resources/application.properties`**:
   ```properties
   spring.datasource.url=jdbc:mysql://localhost:3306/college_expense_db?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
   spring.datasource.username=root
   spring.datasource.password=your_mysql_password
   ```

4. **Automatic Schema & Seed Data**:
   - The tables are auto-generated via Hibernate `ddl-auto=update` and `schema.sql`.
   - Realistic sample student records (Krishna, Rahul, Aman, Rohan) are auto-loaded from `src/main/resources/data.sql`.

---

## 🚀 How to Run the Backend

### Prerequisites
- JDK 17 or higher (`java -version`)
- Apache Maven (`mvn -version`)
- MySQL server running on port 3306

### Commands
```bash
# Navigate to backend directory
cd backend

# Build and package
mvn clean package -DskipTests

# Run the Spring Boot application
mvn spring-boot:run
```

The server will start at: `http://localhost:8080`

---

## 📡 REST API Documentation

### 1. Authentication
| Method | Endpoint | Description | Protected |
|---|---|---|---|
| `POST` | `/api/auth/register` | Register new student account | No |
| `POST` | `/api/auth/login` | Login and obtain JWT Token | No |
| `GET` | `/api/auth/me` | Fetch currently authenticated student profile | Yes (Bearer) |

### 2. Expenses Management
| Method | Endpoint | Description | Protected |
|---|---|---|---|
| `GET` | `/api/expenses` | List/search/filter student expenses | Yes |
| `POST` | `/api/expenses` | Add new expense | Yes |
| `GET` | `/api/expenses/{id}` | Get single expense details | Yes |
| `PUT` | `/api/expenses/{id}` | Update existing expense | Yes |
| `DELETE`| `/api/expenses/{id}` | Delete expense | Yes |

### 3. Dashboard & Metrics
| Method | Endpoint | Description | Protected |
|---|---|---|---|
| `GET` | `/api/dashboard` | Aggregated monthly cards, trends, score, recent items | Yes |

### 4. Budget Management
| Method | Endpoint | Description | Protected |
|---|---|---|---|
| `GET` | `/api/budget` | Get monthly budget & category budgets with warning statuses | Yes |
| `POST` | `/api/budget` | Set monthly overall budget | Yes |
| `POST` | `/api/budget/category`| Set category-specific budget (Food, Travel, etc.) | Yes |

### 5. Analytics & Visuals
| Method | Endpoint | Description | Protected |
|---|---|---|---|
| `GET` | `/api/analytics` | Complete analytics response with category slices & weekly data | Yes |
| `GET` | `/api/analytics/monthly` | Past 6-month historical trends | Yes |
| `GET` | `/api/analytics/category`| Category-wise distribution | Yes |

### 6. Student Spending Score (Unique Feature)
| Method | Endpoint | Description | Protected |
|---|---|---|---|
| `GET` | `/api/spending-score` | Computes 0–100 score with viva breakdown & status | Yes |

### 7. Smart Spending Alerts
| Method | Endpoint | Description | Protected |
|---|---|---|---|
| `GET` | `/api/alerts` | Rule-based alerts (budget pace, weekly spikes, buffer) | Yes |

### 8. Expense Splitter
| Method | Endpoint | Description | Protected |
|---|---|---|---|
| `GET` | `/api/shared-expenses` | List all shared expenses with net debts | Yes |
| `POST` | `/api/shared-expenses` | Create split expense among friends (e.g. Rahul, Aman, etc.)| Yes |
| `DELETE`| `/api/shared-expenses/{id}`| Remove shared expense | Yes |

### 9. Recurring Expenses
| Method | Endpoint | Description | Protected |
|---|---|---|---|
| `GET` | `/api/recurring-expenses` | List recurring expenses (subscriptions, gym, mess) | Yes |
| `POST` | `/api/recurring-expenses` | Create recurring expense | Yes |
| `DELETE`| `/api/recurring-expenses/{id}`| Remove recurring expense | Yes |

### 10. Reports & CSV Export
| Method | Endpoint | Description | Protected |
|---|---|---|---|
| `GET` | `/api/reports` | Comprehensive monthly report summary | Yes |
| `GET` | `/api/reports/export` | Download `.csv` spreadsheet file directly | Yes |

---

## 🎯 Viva Guide: Student Spending Score Algorithm

Designed without opaque black-box AI so students can easily demonstrate and explain every formula during college viva:

1. **Budget Utilization (35 pts)**: Measures consumption velocity relative to the monthly allowance.
   - $\le 50\%$ spent: 35 pts
   - $50\% - 70\%$: 30 pts
   - $70\% - 85\%$: 22 pts
   - $85\% - 100\%$: 12 pts
   - Deficit ($>100\%$): Penalized proportionally down to 0 pts.

2. **Discretionary / Unnecessary Spending Control (25 pts)**:
   - Evaluates ratio of discretionary categories (Entertainment, Shopping, Other) against vital survival needs (Hostel, Food, Education, Health, Travel).
   - $\le 15\%$ discretionary: 25 pts
   - $15\% - 30\%$: 20 pts
   - $30\% - 45\%$: 15 pts
   - $> 60\%$: 3 pts.

3. **Category Discipline (20 pts)**:
   - Deducts 8 points for each breached category budget and 3 points for near-exhaustion ($>90\%$).

4. **Retained Savings Buffer (20 pts)**:
   - Rewards remaining pocket funds ($\ge 35\%$ saved gives 20 pts, down to 0 for debt).

**Total Score = Utilization + Discretionary + Category + Savings (0–100)**
- $85-100$: **Excellent (A+)**
- $75-84$: **Good (A)** — *"Good — you're managing your money well 👍"*
- $60-74$: **Fair (B)**
- $45-59$: **Needs Attention (C)**
- $<45$: **Critical (D)**
