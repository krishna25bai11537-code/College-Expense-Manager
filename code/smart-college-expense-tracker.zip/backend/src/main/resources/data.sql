-- Sample Test Data for Smart College Expense Tracker

-- User: Krishna (Password: password123, BCrypt hashed)
-- Hash generated with standard BCrypt: $2a$10$wN3tNnK6GjQ7FhZ5jJbFEOv12jX6wO9z4d6vXyA7Zp8q9bC0m1x2y
INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`) 
VALUES (1, 'Krishna Sharma', 'krishna@college.edu', '$2a$10$7Z/YjJzN29mH7vVdQvJtI.Wk7W5P0gZ1b8V3nE8m1t7y9p2c3d4e5', NOW())
ON DUPLICATE KEY UPDATE `email`=`email`;

-- Overall Monthly Budget: ₹10,000 for Current Month (e.g. Month 9, 2026)
INSERT INTO `budgets` (`id`, `user_id`, `month`, `year`, `amount`)
VALUES (1, 1, 9, 2026, 10000.00)
ON DUPLICATE KEY UPDATE `amount`=10000.00;

-- Category Budgets
INSERT INTO `category_budgets` (`id`, `user_id`, `category`, `amount`, `month`, `year`) VALUES
(1, 1, 'Food', 3500.00, 9, 2026),
(2, 1, 'Travel', 1500.00, 9, 2026),
(3, 1, 'Education', 1500.00, 9, 2026),
(4, 1, 'Entertainment', 1000.00, 9, 2026),
(5, 1, 'Hostel', 1500.00, 9, 2026),
(6, 1, 'Bills', 1000.00, 9, 2026)
ON DUPLICATE KEY UPDATE `amount`=VALUES(`amount`);

-- Sample College Expenses for Krishna
INSERT INTO `expenses` (`id`, `user_id`, `amount`, `category`, `payment_method`, `description`, `date`, `created_at`) VALUES
(1, 1, 180.00, 'Food', 'UPI', 'Campus Canteen Lunch & Chai', '2026-09-02', NOW()),
(2, 1, 450.00, 'Education', 'Debit Card', 'Data Structures & Algorithms Reference Book', '2026-09-04', NOW()),
(3, 1, 120.00, 'Travel', 'UPI', 'Auto fare to Metro Station', '2026-09-05', NOW()),
(4, 1, 650.00, 'Food', 'UPI', 'Hostel Mess weekend dinner with roommates', '2026-09-07', NOW()),
(5, 1, 199.00, 'Entertainment', 'Debit Card', 'Netflix Student Subscription', '2026-09-08', NOW()),
(6, 1, 350.00, 'Shopping', 'UPI', 'Lab Notebooks & Stationery', '2026-09-09', NOW()),
(7, 1, 1200.00, 'Hostel', 'UPI', 'Monthly Laundry & Maintenance Fee', '2026-09-10', NOW()),
(8, 1, 280.00, 'Food', 'Cash', 'Evening snacks at Nescafe corner', '2026-09-11', NOW()),
(9, 1, 550.00, 'Health', 'UPI', 'Gym supplements & multivitamins', '2026-09-12', NOW()),
(10, 1, 80.00, 'Travel', 'UPI', 'College Bus ticket pass', '2026-09-14', NOW()),
(11, 1, 420.00, 'Food', 'UPI', 'Pizza treat after mid-term exams', '2026-09-15', NOW())
ON DUPLICATE KEY UPDATE `id`=`id`;

-- Shared Expense: Food bill = ₹1,200 (Friends: Rahul, Aman, Krishna, Rohan)
-- Krishna paid ₹1200, each share is ₹300. Rahul owes Krishna ₹300, Aman owes ₹300, Rohan owes ₹300
INSERT INTO `shared_expenses` (`id`, `user_id`, `title`, `total_amount`, `date`, `created_at`)
VALUES (1, 1, 'College Dhaba Dinner', 1200.00, '2026-09-10', NOW())
ON DUPLICATE KEY UPDATE `id`=`id`;

INSERT INTO `shared_expense_participants` (`id`, `shared_expense_id`, `participant_name`, `amount_paid`, `amount_owed`) VALUES
(1, 1, 'Krishna (You)', 1200.00, 300.00),
(2, 1, 'Rahul', 0.00, 300.00),
(3, 1, 'Aman', 0.00, 300.00),
(4, 1, 'Rohan', 0.00, 300.00)
ON DUPLICATE KEY UPDATE `id`=`id`;

-- Recurring Expenses
INSERT INTO `recurring_expenses` (`id`, `user_id`, `name`, `amount`, `category`, `frequency`, `start_date`, `end_date`, `created_at`) VALUES
(1, 1, 'Hostel Gym Membership', 800.00, 'Health', 'MONTHLY', '2026-08-01', '2027-05-31', NOW()),
(2, 1, 'Spotify Student Pack', 59.00, 'Entertainment', 'MONTHLY', '2026-07-01', NULL, NOW()),
(3, 1, 'Hostel WiFi Contribution', 300.00, 'Bills', 'MONTHLY', '2026-08-01', NULL, NOW())
ON DUPLICATE KEY UPDATE `id`=`id`;
