-- Smart College Expense Tracker MySQL Database Schema
CREATE DATABASE IF NOT EXISTS `college_expense_db`;
USE `college_expense_db`;

-- 1. Users Table
CREATE TABLE IF NOT EXISTS `users` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `email` VARCHAR(150) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Expenses Table
CREATE TABLE IF NOT EXISTS `expenses` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT NOT NULL,
    `amount` DECIMAL(10, 2) NOT NULL,
    `category` VARCHAR(50) NOT NULL,
    `payment_method` VARCHAR(50) NOT NULL,
    `description` VARCHAR(255),
    `date` DATE NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_expense_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Monthly Overall Budget Table
CREATE TABLE IF NOT EXISTS `budgets` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT NOT NULL,
    `month` INT NOT NULL,
    `year` INT NOT NULL,
    `amount` DECIMAL(10, 2) NOT NULL,
    CONSTRAINT `uq_user_month_year` UNIQUE (`user_id`, `month`, `year`),
    CONSTRAINT `fk_budget_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Category-Wise Budgets Table
CREATE TABLE IF NOT EXISTS `category_budgets` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT NOT NULL,
    `category` VARCHAR(50) NOT NULL,
    `amount` DECIMAL(10, 2) NOT NULL,
    `month` INT NOT NULL,
    `year` INT NOT NULL,
    CONSTRAINT `uq_user_cat_month_year` UNIQUE (`user_id`, `category`, `month`, `year`),
    CONSTRAINT `fk_category_budget_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Shared Expenses Table (Expense Splitter)
CREATE TABLE IF NOT EXISTS `shared_expenses` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT NOT NULL,
    `title` VARCHAR(150) NOT NULL,
    `total_amount` DECIMAL(10, 2) NOT NULL,
    `date` DATE NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_shared_expense_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Shared Expense Participants Table
CREATE TABLE IF NOT EXISTS `shared_expense_participants` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `shared_expense_id` BIGINT NOT NULL,
    `participant_name` VARCHAR(100) NOT NULL,
    `amount_paid` DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    `amount_owed` DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    CONSTRAINT `fk_participant_shared_expense` FOREIGN KEY (`shared_expense_id`) REFERENCES `shared_expenses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. Recurring Expenses Table
CREATE TABLE IF NOT EXISTS `recurring_expenses` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT NOT NULL,
    `name` VARCHAR(150) NOT NULL,
    `amount` DECIMAL(10, 2) NOT NULL,
    `category` VARCHAR(50) NOT NULL,
    `frequency` VARCHAR(20) NOT NULL, -- MONTHLY, WEEKLY
    `start_date` DATE NOT NULL,
    `end_date` DATE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_recurring_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
