package com.college.expensetracker.controller;

import com.college.expensetracker.dto.ReportDTO.ReportSummaryResponse;
import com.college.expensetracker.security.UserPrincipal;
import com.college.expensetracker.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/reports")
public class ReportController {

    @Autowired
    private ReportService reportService;

    @GetMapping
    public ResponseEntity<ReportSummaryResponse> getMonthlyReport(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(required = false) Integer month,
            @RequestParam(required = false) Integer year
    ) {
        ReportSummaryResponse report = reportService.generateReport(currentUser.getId(), month, year);
        return ResponseEntity.ok(report);
    }

    @GetMapping("/export")
    public ResponseEntity<byte[]> exportReportCsv(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(required = false) Integer month,
            @RequestParam(required = false) Integer year
    ) {
        byte[] csvBytes = reportService.exportExpensesCsv(currentUser.getId(), month, year);

        String filename = String.format("college_expenses_%d_%d.csv",
                year != null ? year : 2026,
                month != null ? month : 9);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .contentType(MediaType.parseMediaType("text/csv"))
                .body(csvBytes);
    }

    @PostMapping("/export")
    public ResponseEntity<byte[]> postExportReportCsv(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(required = false) Integer month,
            @RequestParam(required = false) Integer year
    ) {
        return exportReportCsv(currentUser, month, year);
    }
}
