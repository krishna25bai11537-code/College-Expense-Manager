package com.college.expensetracker.controller;

import com.college.expensetracker.dto.ExpenseDTO;
import com.college.expensetracker.security.UserPrincipal;
import com.college.expensetracker.service.ExpenseService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/expenses")
public class ExpenseController {

    @Autowired
    private ExpenseService expenseService;

    @GetMapping
    public ResponseEntity<List<ExpenseDTO>> getAllExpenses(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String search,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @RequestParam(defaultValue = "date") String sortBy,
            @RequestParam(defaultValue = "desc") String sortOrder
    ) {
        List<ExpenseDTO> expenses = expenseService.getExpenses(
                currentUser.getId(), category, search, startDate, endDate, sortBy, sortOrder
        );
        return ResponseEntity.ok(expenses);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ExpenseDTO> getExpenseById(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id
    ) {
        ExpenseDTO expense = expenseService.getExpenseById(currentUser.getId(), id);
        return ResponseEntity.ok(expense);
    }

    @PostMapping
    public ResponseEntity<ExpenseDTO> createExpense(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @Valid @RequestBody ExpenseDTO expenseDTO
    ) {
        ExpenseDTO created = expenseService.createExpense(currentUser.getId(), expenseDTO);
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ExpenseDTO> updateExpense(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id,
            @Valid @RequestBody ExpenseDTO expenseDTO
    ) {
        ExpenseDTO updated = expenseService.updateExpense(currentUser.getId(), id, expenseDTO);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteExpense(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id
    ) {
        expenseService.deleteExpense(currentUser.getId(), id);
        return ResponseEntity.noContent().build();
    }
}
