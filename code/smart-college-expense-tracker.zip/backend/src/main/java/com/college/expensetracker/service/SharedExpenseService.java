package com.college.expensetracker.service;

import com.college.expensetracker.dto.SharedExpenseDTO.*;
import com.college.expensetracker.entity.SharedExpense;
import com.college.expensetracker.entity.SharedExpenseParticipant;
import com.college.expensetracker.exception.BadRequestException;
import com.college.expensetracker.exception.ResourceNotFoundException;
import com.college.expensetracker.repository.SharedExpenseParticipantRepository;
import com.college.expensetracker.repository.SharedExpenseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SharedExpenseService {

    @Autowired
    private SharedExpenseRepository sharedExpenseRepository;

    @Autowired
    private SharedExpenseParticipantRepository participantRepository;

    public List<SharedExpenseResponse> getAllSharedExpenses(Long userId) {
        List<SharedExpense> list = sharedExpenseRepository.findByUserIdOrderByDateDesc(userId);
        return list.stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    public SharedExpenseResponse getSharedExpenseById(Long userId, Long id) {
        SharedExpense se = sharedExpenseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Shared expense not found with id " + id));
        if (!se.getUserId().equals(userId)) {
            throw new BadRequestException("Unauthorized access to shared expense");
        }
        return mapToResponse(se);
    }

    @Transactional
    public SharedExpenseResponse createSharedExpense(Long userId, CreateSharedExpenseRequest request) {
        if (request.getParticipants() == null || request.getParticipants().size() < 2) {
            throw new BadRequestException("At least two friends are required to split an expense.");
        }

        SharedExpense sharedExpense = new SharedExpense();
        sharedExpense.setUserId(userId);
        sharedExpense.setTitle(request.getTitle());
        sharedExpense.setTotalAmount(request.getTotalAmount());
        sharedExpense.setDate(request.getDate());

        int numParticipants = request.getParticipants().size();
        BigDecimal splitShare = request.getTotalAmount().divide(BigDecimal.valueOf(numParticipants), 2, RoundingMode.HALF_UP);

        for (ParticipantRequest pReq : request.getParticipants()) {
            SharedExpenseParticipant participant = new SharedExpenseParticipant();
            participant.setParticipantName(pReq.getParticipantName());
            participant.setAmountPaid(pReq.getAmountPaid() != null ? pReq.getAmountPaid() : BigDecimal.ZERO);
            participant.setAmountOwed(splitShare);
            sharedExpense.addParticipant(participant);
        }

        SharedExpense saved = sharedExpenseRepository.save(sharedExpense);
        return mapToResponse(saved);
    }

    @Transactional
    public SharedExpenseResponse updateSharedExpense(Long userId, Long id, CreateSharedExpenseRequest request) {
        SharedExpense sharedExpense = sharedExpenseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Shared expense not found with id " + id));

        if (!sharedExpense.getUserId().equals(userId)) {
            throw new BadRequestException("Unauthorized access to shared expense");
        }

        sharedExpense.setTitle(request.getTitle());
        sharedExpense.setTotalAmount(request.getTotalAmount());
        sharedExpense.setDate(request.getDate());

        sharedExpense.getParticipants().clear();

        int numParticipants = request.getParticipants().size();
        BigDecimal splitShare = request.getTotalAmount().divide(BigDecimal.valueOf(numParticipants), 2, RoundingMode.HALF_UP);

        for (ParticipantRequest pReq : request.getParticipants()) {
            SharedExpenseParticipant participant = new SharedExpenseParticipant();
            participant.setParticipantName(pReq.getParticipantName());
            participant.setAmountPaid(pReq.getAmountPaid() != null ? pReq.getAmountPaid() : BigDecimal.ZERO);
            participant.setAmountOwed(splitShare);
            sharedExpense.addParticipant(participant);
        }

        SharedExpense updated = sharedExpenseRepository.save(sharedExpense);
        return mapToResponse(updated);
    }

    @Transactional
    public void deleteSharedExpense(Long userId, Long id) {
        SharedExpense sharedExpense = sharedExpenseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Shared expense not found with id " + id));

        if (!sharedExpense.getUserId().equals(userId)) {
            throw new BadRequestException("Unauthorized access to shared expense");
        }

        sharedExpenseRepository.delete(sharedExpense);
    }

    private SharedExpenseResponse mapToResponse(SharedExpense se) {
        SharedExpenseResponse response = new SharedExpenseResponse();
        response.setId(se.getId());
        response.setTitle(se.getTitle());
        response.setTotalAmount(se.getTotalAmount());
        response.setDate(se.getDate());

        int count = se.getParticipants().isEmpty() ? 1 : se.getParticipants().size();
        BigDecimal split = se.getTotalAmount().divide(BigDecimal.valueOf(count), 2, RoundingMode.HALF_UP);
        response.setSplitPerPerson(split);

        List<ParticipantResponse> pList = new ArrayList<>();
        List<Debtor> debtors = new ArrayList<>();
        List<Creditor> creditors = new ArrayList<>();

        for (SharedExpenseParticipant p : se.getParticipants()) {
            BigDecimal net = p.getAmountPaid().subtract(p.getAmountOwed());
            pList.add(new ParticipantResponse(p.getId(), p.getParticipantName(), p.getAmountPaid(), p.getAmountOwed(), net));

            if (net.compareTo(BigDecimal.ZERO) < 0) {
                debtors.add(new Debtor(p.getParticipantName(), net.abs()));
            } else if (net.compareTo(BigDecimal.ZERO) > 0) {
                creditors.add(new Creditor(p.getParticipantName(), net));
            }
        }
        response.setParticipants(pList);

        // Calculate settlement notes (e.g. "Rahul owes Krishna ₹300")
        List<SettlementNote> settlements = new ArrayList<>();
        int dIdx = 0;
        int cIdx = 0;

        while (dIdx < debtors.size() && cIdx < creditors.size()) {
            Debtor debtor = debtors.get(dIdx);
            Creditor creditor = creditors.get(cIdx);

            BigDecimal settleAmount = debtor.amount.min(creditor.amount);
            settlements.add(new SettlementNote(debtor.name, creditor.name, settleAmount));

            debtor.amount = debtor.amount.subtract(settleAmount);
            creditor.amount = creditor.amount.subtract(settleAmount);

            if (debtor.amount.compareTo(BigDecimal.valueOf(0.01)) < 0) dIdx++;
            if (creditor.amount.compareTo(BigDecimal.valueOf(0.01)) < 0) cIdx++;
        }

        response.setSettlements(settlements);
        return response;
    }

    private static class Debtor {
        String name;
        BigDecimal amount;
        Debtor(String name, BigDecimal amount) { this.name = name; this.amount = amount; }
    }

    private static class Creditor {
        String name;
        BigDecimal amount;
        Creditor(String name, BigDecimal amount) { this.name = name; this.amount = amount; }
    }
}
