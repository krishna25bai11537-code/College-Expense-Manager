package com.college.expensetracker.dto;

import java.math.BigDecimal;
import java.util.List;

public class SpendingScoreDTO {

    private int score; // 0 to 100
    private String status; // "Excellent", "Good", "Moderate", "Needs Attention", "Critical"
    private String feedbackMessage;
    private String grade; // A+, A, B, C, D

    // Mathematical Breakdown for College Viva Presentation
    private int budgetUtilizationScore;    // max 35 pts
    private int discretionarySpendingScore;// max 25 pts (unnecessary spending control)
    private int categoryDisciplineScore;   // max 20 pts (within category thresholds)
    private int savingsRatioScore;         // max 20 pts (retained budget savings)

    private BigDecimal totalBudget;
    private BigDecimal totalSpent;
    private BigDecimal remainingAmount;
    private double budgetUsedPercentage;
    private double unnecessarySpendingRatio;

    private List<String> vivaExplanationPoints;
    private List<String> studentTips;

    public SpendingScoreDTO() {}

    public int getScore() { return score; }
    public void setScore(int score) { this.score = score; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getFeedbackMessage() { return feedbackMessage; }
    public void setFeedbackMessage(String feedbackMessage) { this.feedbackMessage = feedbackMessage; }

    public String getGrade() { return grade; }
    public void setGrade(String grade) { this.grade = grade; }

    public int getBudgetUtilizationScore() { return budgetUtilizationScore; }
    public void setBudgetUtilizationScore(int budgetUtilizationScore) { this.budgetUtilizationScore = budgetUtilizationScore; }

    public int getDiscretionarySpendingScore() { return discretionarySpendingScore; }
    public void setDiscretionarySpendingScore(int discretionarySpendingScore) { this.discretionarySpendingScore = discretionarySpendingScore; }

    public int getCategoryDisciplineScore() { return categoryDisciplineScore; }
    public void setCategoryDisciplineScore(int categoryDisciplineScore) { this.categoryDisciplineScore = categoryDisciplineScore; }

    public int getSavingsRatioScore() { return savingsRatioScore; }
    public void setSavingsRatioScore(int savingsRatioScore) { this.savingsRatioScore = savingsRatioScore; }

    public BigDecimal getTotalBudget() { return totalBudget; }
    public void setTotalBudget(BigDecimal totalBudget) { this.totalBudget = totalBudget; }

    public BigDecimal getTotalSpent() { return totalSpent; }
    public void setTotalSpent(BigDecimal totalSpent) { this.totalSpent = totalSpent; }

    public BigDecimal getRemainingAmount() { return remainingAmount; }
    public void setRemainingAmount(BigDecimal remainingAmount) { this.remainingAmount = remainingAmount; }

    public double getBudgetUsedPercentage() { return budgetUsedPercentage; }
    public void setBudgetUsedPercentage(double budgetUsedPercentage) { this.budgetUsedPercentage = budgetUsedPercentage; }

    public double getUnnecessarySpendingRatio() { return unnecessarySpendingRatio; }
    public void setUnnecessarySpendingRatio(double unnecessarySpendingRatio) { this.unnecessarySpendingRatio = unnecessarySpendingRatio; }

    public List<String> getVivaExplanationPoints() { return vivaExplanationPoints; }
    public void setVivaExplanationPoints(List<String> vivaExplanationPoints) { this.vivaExplanationPoints = vivaExplanationPoints; }

    public List<String> getStudentTips() { return studentTips; }
    public void setStudentTips(List<String> studentTips) { this.studentTips = studentTips; }
}
