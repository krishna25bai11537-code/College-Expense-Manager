package com.college.expensetracker.dto;

import java.math.BigDecimal;
import java.util.List;

public class ReportDTO {

    public static class ReportSummaryResponse {
        private Integer month;
        private Integer year;
        private BigDecimal totalBudget;
        private BigDecimal totalSpent;
        private BigDecimal netSavings;
        private double budgetUtilizationPercentage;
        private int totalTransactions;
        private BigDecimal averageExpensePerDay;
        private List<AnalyticsDTO.CategorySliceDTO> categorySummary;
        private List<BudgetDTOs.CategoryBudgetDetailDTO> budgetReport;
        private List<ExpenseDTO> expenseItems;

        public ReportSummaryResponse() {}

        public Integer getMonth() { return month; }
        public void setMonth(Integer month) { this.month = month; }
        public Integer getYear() { return year; }
        public void setYear(Integer year) { this.year = year; }
        public BigDecimal getTotalBudget() { return totalBudget; }
        public void setTotalBudget(BigDecimal totalBudget) { this.totalBudget = totalBudget; }
        public BigDecimal getTotalSpent() { return totalSpent; }
        public void setTotalSpent(BigDecimal totalSpent) { this.totalSpent = totalSpent; }
        public BigDecimal getNetSavings() { return netSavings; }
        public void setNetSavings(BigDecimal netSavings) { this.netSavings = netSavings; }
        public double getBudgetUtilizationPercentage() { return budgetUtilizationPercentage; }
        public void setBudgetUtilizationPercentage(double budgetUtilizationPercentage) { this.budgetUtilizationPercentage = budgetUtilizationPercentage; }
        public int getTotalTransactions() { return totalTransactions; }
        public void setTotalTransactions(int totalTransactions) { this.totalTransactions = totalTransactions; }
        public BigDecimal getAverageExpensePerDay() { return averageExpensePerDay; }
        public void setAverageExpensePerDay(BigDecimal averageExpensePerDay) { this.averageExpensePerDay = averageExpensePerDay; }
        public List<AnalyticsDTO.CategorySliceDTO> getCategorySummary() { return categorySummary; }
        public void setCategorySummary(List<AnalyticsDTO.CategorySliceDTO> categorySummary) { this.categorySummary = categorySummary; }
        public List<BudgetDTOs.CategoryBudgetDetailDTO> getBudgetReport() { return budgetReport; }
        public void setBudgetReport(List<BudgetDTOs.CategoryBudgetDetailDTO> budgetReport) { this.budgetReport = budgetReport; }
        public List<ExpenseDTO> getExpenseItems() { return expenseItems; }
        public void setExpenseItems(List<ExpenseDTO> expenseItems) { this.expenseItems = expenseItems; }
    }
}
