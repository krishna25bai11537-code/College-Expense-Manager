package com.college.expensetracker.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class SharedExpenseDTO {

    public static class ParticipantRequest {
        @NotBlank(message = "Participant name is required")
        private String participantName;

        private BigDecimal amountPaid; // what this person paid initially (can be 0 or total)

        public ParticipantRequest() {}
        public ParticipantRequest(String participantName, BigDecimal amountPaid) {
            this.participantName = participantName;
            this.amountPaid = amountPaid != null ? amountPaid : BigDecimal.ZERO;
        }

        public String getParticipantName() { return participantName; }
        public void setParticipantName(String participantName) { this.participantName = participantName; }
        public BigDecimal getAmountPaid() { return amountPaid; }
        public void setAmountPaid(BigDecimal amountPaid) { this.amountPaid = amountPaid; }
    }

    public static class CreateSharedExpenseRequest {
        @NotBlank(message = "Title is required")
        private String title;

        @NotNull(message = "Total amount is required")
        private BigDecimal totalAmount;

        @NotNull(message = "Date is required")
        private LocalDate date;

        @NotEmpty(message = "At least two participants are required")
        private List<ParticipantRequest> participants;

        public CreateSharedExpenseRequest() {}

        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }
        public BigDecimal getTotalAmount() { return totalAmount; }
        public void setTotalAmount(BigDecimal totalAmount) { this.totalAmount = totalAmount; }
        public LocalDate getDate() { return date; }
        public void setDate(LocalDate date) { this.date = date; }
        public List<ParticipantRequest> getParticipants() { return participants; }
        public void setParticipants(List<ParticipantRequest> participants) { this.participants = participants; }
    }

    public static class ParticipantResponse {
        private Long id;
        private String participantName;
        private BigDecimal amountPaid;
        private BigDecimal amountOwed;
        private BigDecimal netBalance; // amountPaid - amountOwed (+ means they get back, - means they owe)

        public ParticipantResponse() {}
        public ParticipantResponse(Long id, String participantName, BigDecimal amountPaid, BigDecimal amountOwed, BigDecimal netBalance) {
            this.id = id;
            this.participantName = participantName;
            this.amountPaid = amountPaid;
            this.amountOwed = amountOwed;
            this.netBalance = netBalance;
        }

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getParticipantName() { return participantName; }
        public void setParticipantName(String participantName) { this.participantName = participantName; }
        public BigDecimal getAmountPaid() { return amountPaid; }
        public void setAmountPaid(BigDecimal amountPaid) { this.amountPaid = amountPaid; }
        public BigDecimal getAmountOwed() { return amountOwed; }
        public void setAmountOwed(BigDecimal amountOwed) { this.amountOwed = amountOwed; }
        public BigDecimal getNetBalance() { return netBalance; }
        public void setNetBalance(BigDecimal netBalance) { this.netBalance = netBalance; }
    }

    public static class SettlementNote {
        private String fromPerson;
        private String toPerson;
        private BigDecimal amount;
        private String displayText; // e.g. "Rahul owes Krishna ₹300.00"

        public SettlementNote() {}
        public SettlementNote(String fromPerson, String toPerson, BigDecimal amount) {
            this.fromPerson = fromPerson;
            this.toPerson = toPerson;
            this.amount = amount;
            this.displayText = String.format("%s owes %s ₹%.2f", fromPerson, toPerson, amount);
        }

        public String getFromPerson() { return fromPerson; }
        public void setFromPerson(String fromPerson) { this.fromPerson = fromPerson; }
        public String getToPerson() { return toPerson; }
        public void setToPerson(String toPerson) { this.toPerson = toPerson; }
        public BigDecimal getAmount() { return amount; }
        public void setAmount(BigDecimal amount) { this.amount = amount; }
        public String getDisplayText() { return displayText; }
        public void setDisplayText(String displayText) { this.displayText = displayText; }
    }

    public static class SharedExpenseResponse {
        private Long id;
        private String title;
        private BigDecimal totalAmount;
        private BigDecimal splitPerPerson;
        private LocalDate date;
        private List<ParticipantResponse> participants;
        private List<SettlementNote> settlements;

        public SharedExpenseResponse() {}

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }
        public BigDecimal getTotalAmount() { return totalAmount; }
        public void setTotalAmount(BigDecimal totalAmount) { this.totalAmount = totalAmount; }
        public BigDecimal getSplitPerPerson() { return splitPerPerson; }
        public void setSplitPerPerson(BigDecimal splitPerPerson) { this.splitPerPerson = splitPerPerson; }
        public LocalDate getDate() { return date; }
        public void setDate(LocalDate date) { this.date = date; }
        public List<ParticipantResponse> getParticipants() { return participants; }
        public void setParticipants(List<ParticipantResponse> participants) { this.participants = participants; }
        public List<SettlementNote> getSettlements() { return settlements; }
        public void setSettlements(List<SettlementNote> settlements) { this.settlements = settlements; }
    }
}
