package com.college.expensetracker.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "shared_expense_participants")
public class SharedExpenseParticipant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "shared_expense_id", nullable = false)
    @JsonIgnore
    private SharedExpense sharedExpense;

    @Column(name = "participant_name", nullable = false, length = 100)
    private String participantName;

    @Column(name = "amount_paid", nullable = false, precision = 10, scale = 2)
    private BigDecimal amountPaid = BigDecimal.ZERO;

    @Column(name = "amount_owed", nullable = false, precision = 10, scale = 2)
    private BigDecimal amountOwed = BigDecimal.ZERO;

    public SharedExpenseParticipant() {}

    public SharedExpenseParticipant(String participantName, BigDecimal amountPaid, BigDecimal amountOwed) {
        this.participantName = participantName;
        this.amountPaid = amountPaid;
        this.amountOwed = amountOwed;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public SharedExpense getSharedExpense() { return sharedExpense; }
    public void setSharedExpense(SharedExpense sharedExpense) { this.sharedExpense = sharedExpense; }

    public String getParticipantName() { return participantName; }
    public void setParticipantName(String participantName) { this.participantName = participantName; }

    public BigDecimal getAmountPaid() { return amountPaid; }
    public void setAmountPaid(BigDecimal amountPaid) { this.amountPaid = amountPaid; }

    public BigDecimal getAmountOwed() { return amountOwed; }
    public void setAmountOwed(BigDecimal amountOwed) { this.amountOwed = amountOwed; }
}
