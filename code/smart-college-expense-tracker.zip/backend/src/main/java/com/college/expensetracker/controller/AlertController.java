package com.college.expensetracker.controller;

import com.college.expensetracker.dto.AlertDTO;
import com.college.expensetracker.security.UserPrincipal;
import com.college.expensetracker.service.AlertService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/alerts")
public class AlertController {

    @Autowired
    private AlertService alertService;

    @GetMapping
    public ResponseEntity<List<AlertDTO>> getSmartAlerts(@AuthenticationPrincipal UserPrincipal currentUser) {
        List<AlertDTO> alerts = alertService.generateAlerts(currentUser.getId());
        return ResponseEntity.ok(alerts);
    }
}
