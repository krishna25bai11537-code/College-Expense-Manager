package com.college.expensetracker.service;

import com.college.expensetracker.dto.AlertDTO;
import com.college.expensetracker.entity.Budget;
import com.college.expensetracker.entity.CategoryBudget;
import com.college.expensetracker.repository.BudgetRepository;
import com.college.expensetracker.repository.CategoryBudgetRepository;
import com.college.expensetracker.repository.ExpenseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class AlertService {

    @Autowired
    private ExpenseRepository expenseRepository;

    @Autowired
    private BudgetRepository budgetRepository;

    @Autowired
    private CategoryBudgetRepository categoryBudgetRepository;

    public List<AlertDTO> generateAlerts(Long userId) {
        List<AlertDTO> alerts = new ArrayList<>();
        LocalDate today = LocalDate.now();
        int currentMonth = today.getMonthValue();
        int currentYear = today.getYear();

        YearMonth ym = YearMonth.of(currentYear, currentMonth);
        LocalDate startOfMonth = ym.atDay(1);
        LocalDate endOfMonth = ym.atEndOfMonth();

        // 1. Alert Rule: Overall Remaining Budget
        // Example: “🎯 You have ₹3,500 remaining from your monthly budget.”
        Optional<Budget> budgetOpt = budgetRepository.findByUserIdAndMonthAndYear(userId, currentMonth, currentYear);
        BigDecimal totalBudget = budgetOpt.map(Budget::getAmount).orElse(BigDecimal.valueOf(10000.00));
        BigDecimal totalSpent = expenseRepository.getTotalExpenseBetween(userId, startOfMonth, endOfMonth);
        if (totalSpent == null) totalSpent = BigDecimal.ZERO;

        BigDecimal remaining = totalBudget.subtract(totalSpent);

        if (remaining.compareTo(BigDecimal.ZERO) >= 0) {
            alerts.add(new AlertDTO(
                    "alert-remaining",
                    "REMAINING_BUDGET",
                    "SUCCESS",
                    "Budget Balance Update",
                    String.format("🎯 You have ₹%s remaining from your monthly budget.", remaining.setScale(0, RoundingMode.HALF_UP).toPlainString()),
                    "target"
            ));
        } else {
            alerts.add(new AlertDTO(
                    "alert-overspent",
                    "REMAINING_BUDGET",
                    "DANGER",
                    "Budget Exceeded",
                    String.format("🚨 You have exceeded your monthly budget by ₹%s!", remaining.abs().setScale(0, RoundingMode.HALF_UP).toPlainString()),
                    "alert-triangle"
            ));
        }

        // 2. Alert Rule: Weekly Spending Velocity Comparison
        // Example: “💡 Your spending this week is 25% higher than last week.”
        LocalDate startOfThisWeek = today.minusDays(today.getDayOfWeek().getValue() - 1);
        LocalDate startOfLastWeek = startOfThisWeek.minusWeeks(1);
        LocalDate endOfLastWeek = startOfThisWeek.minusDays(1);

        BigDecimal thisWeekSpent = expenseRepository.getTotalExpenseBetween(userId, startOfThisWeek, today);
        BigDecimal lastWeekSpent = expenseRepository.getTotalExpenseBetween(userId, startOfLastWeek, endOfLastWeek);

        if (thisWeekSpent == null) thisWeekSpent = BigDecimal.ZERO;
        if (lastWeekSpent == null) lastWeekSpent = BigDecimal.ZERO;

        if (lastWeekSpent.compareTo(BigDecimal.valueOf(100)) > 0) {
            double diff = thisWeekSpent.subtract(lastWeekSpent).divide(lastWeekSpent, 4, RoundingMode.HALF_UP).doubleValue() * 100.0;
            if (diff >= 15.0) {
                alerts.add(new AlertDTO(
                        "alert-weekly-spike",
                        "WEEKLY_SPIKE",
                        "WARNING",
                        "Weekly Pace Spike",
                        String.format("💡 Your spending this week is %.0f%% higher than last week (₹%s vs ₹%s).",
                                diff, thisWeekSpent.setScale(0, RoundingMode.HALF_UP), lastWeekSpent.setScale(0, RoundingMode.HALF_UP)),
                        "trending-up"
                ));
            } else if (diff <= -15.0) {
                alerts.add(new AlertDTO(
                        "alert-weekly-drop",
                        "WEEKLY_SPIKE",
                        "SUCCESS",
                        "Great Spend Control",
                        String.format("🌟 You spent %.0f%% less this week compared to last week! Excellent savings.", Math.abs(diff)),
                        "trending-down"
                ));
            }
        }

        // 3. Alert Rule: Early Month Category Burn Pace
        // Example: “⚠️ You've spent 40% of your food budget in the first 10 days of the month.”
        int dayOfMonth = today.getDayOfMonth();
        List<CategoryBudget> catBudgets = categoryBudgetRepository.findByUserIdAndMonthAndYear(userId, currentMonth, currentYear);
        List<Object[]> catSpends = expenseRepository.getCategoryWiseSum(userId, startOfMonth, today);

        for (CategoryBudget cb : catBudgets) {
            BigDecimal spent = BigDecimal.ZERO;
            for (Object[] row : catSpends) {
                if (cb.getCategory().equalsIgnoreCase((String) row[0])) {
                    spent = (BigDecimal) row[1];
                    break;
                }
            }

            if (cb.getAmount().compareTo(BigDecimal.ZERO) > 0) {
                double pct = spent.divide(cb.getAmount(), 4, RoundingMode.HALF_UP).doubleValue() * 100.0;
                // If in first 15 days, spent > 40% of category
                if (dayOfMonth <= 15 && pct >= 40.0 && pct < 90.0) {
                    alerts.add(new AlertDTO(
                            "alert-pace-" + cb.getCategory().toLowerCase(),
                            "BUDGET_PACE",
                            "WARNING",
                            cb.getCategory() + " Budget Pace Warning",
                            String.format("⚠️ You've spent %.0f%% of your %s budget (₹%s of ₹%s) in the first %d days of the month.",
                                    pct, cb.getCategory().toLowerCase(), spent.setScale(0, RoundingMode.HALF_UP), cb.getAmount().setScale(0, RoundingMode.HALF_UP), dayOfMonth),
                            "clock"
                    ));
                } else if (pct >= 90.0) {
                    alerts.add(new AlertDTO(
                            "alert-exhausted-" + cb.getCategory().toLowerCase(),
                            "CATEGORY_EXCEEDED",
                            "DANGER",
                            cb.getCategory() + " Budget Exhausted",
                            String.format("🚨 Your %s budget is %.0f%% consumed (₹%s / ₹%s). Limit further non-vital spending.",
                                    cb.getCategory(), pct, spent.setScale(0, RoundingMode.HALF_UP), cb.getAmount().setScale(0, RoundingMode.HALF_UP)),
                            "alert-octagon"
                    ));
                }
            }
        }

        return alerts;
    }
}
