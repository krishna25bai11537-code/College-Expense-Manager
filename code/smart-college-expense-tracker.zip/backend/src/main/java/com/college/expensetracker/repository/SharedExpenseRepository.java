package com.college.expensetracker.repository;

import com.college.expensetracker.entity.SharedExpense;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SharedExpenseRepository extends JpaRepository<SharedExpense, Long> {
    List<SharedExpense> findByUserIdOrderByDateDesc(Long userId);
}
