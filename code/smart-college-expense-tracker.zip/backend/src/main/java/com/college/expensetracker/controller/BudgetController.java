package com.college.expensetracker.controller;

import com.college.expensetracker.dto.BudgetDTOs.*;
import com.college.expensetracker.entity.Budget;
import com.college.expensetracker.entity.CategoryBudget;
import com.college.expensetracker.security.UserPrincipal;
import com.college.expensetracker.service.BudgetService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/budget")
public class BudgetController {

    @Autowired
    private BudgetService budgetService;

    @GetMapping
    public ResponseEntity<BudgetOverviewDTO> getBudgetOverview(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(required = false) Integer month,
            @RequestParam(required = false) Integer year
    ) {
        BudgetOverviewDTO overview = budgetService.getBudgetOverview(currentUser.getId(), month, year);
        return ResponseEntity.ok(overview);
    }

    @PostMapping
    public ResponseEntity<Budget> setMonthlyBudget(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @Valid @RequestBody BudgetRequest request
    ) {
        Budget budget = budgetService.setMonthlyBudget(currentUser.getId(), request);
        return ResponseEntity.ok(budget);
    }

    @PutMapping
    public ResponseEntity<Budget> updateMonthlyBudget(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @Valid @RequestBody BudgetRequest request
    ) {
        Budget budget = budgetService.setMonthlyBudget(currentUser.getId(), request);
        return ResponseEntity.ok(budget);
    }

    @PostMapping("/category")
    public ResponseEntity<CategoryBudget> setCategoryBudget(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestBody CategoryBudgetRequest request
    ) {
        CategoryBudget cb = budgetService.setCategoryBudget(currentUser.getId(), request);
        return ResponseEntity.ok(cb);
    }
}
