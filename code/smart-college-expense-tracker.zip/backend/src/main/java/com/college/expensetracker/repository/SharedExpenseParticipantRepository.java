package com.college.expensetracker.repository;

import com.college.expensetracker.entity.SharedExpenseParticipant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SharedExpenseParticipantRepository extends JpaRepository<SharedExpenseParticipant, Long> {
    List<SharedExpenseParticipant> findBySharedExpenseId(Long sharedExpenseId);
}
