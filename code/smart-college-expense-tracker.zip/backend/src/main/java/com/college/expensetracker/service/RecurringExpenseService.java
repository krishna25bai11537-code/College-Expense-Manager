package com.college.expensetracker.service;

import com.college.expensetracker.dto.RecurringExpenseDTO;
import com.college.expensetracker.entity.RecurringExpense;
import com.college.expensetracker.exception.BadRequestException;
import com.college.expensetracker.exception.ResourceNotFoundException;
import com.college.expensetracker.repository.RecurringExpenseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class RecurringExpenseService {

    @Autowired
    private RecurringExpenseRepository recurringExpenseRepository;

    public List<RecurringExpenseDTO> getAllRecurringExpenses(Long userId) {
        return recurringExpenseRepository.findByUserIdOrderByStartDateDesc(userId)
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public RecurringExpenseDTO getById(Long userId, Long id) {
        RecurringExpense re = recurringExpenseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Recurring expense not found with id " + id));
        if (!re.getUserId().equals(userId)) {
            throw new BadRequestException("Unauthorized access to recurring expense");
        }
        return mapToDTO(re);
    }

    @Transactional
    public RecurringExpenseDTO createRecurringExpense(Long userId, RecurringExpenseDTO dto) {
        RecurringExpense re = new RecurringExpense();
        re.setUserId(userId);
        re.setName(dto.getName());
        re.setAmount(dto.getAmount());
        re.setCategory(dto.getCategory());
        re.setFrequency(dto.getFrequency() != null ? dto.getFrequency().toUpperCase() : "MONTHLY");
        re.setStartDate(dto.getStartDate());
        re.setEndDate(dto.getEndDate());

        RecurringExpense saved = recurringExpenseRepository.save(re);
        return mapToDTO(saved);
    }

    @Transactional
    public RecurringExpenseDTO updateRecurringExpense(Long userId, Long id, RecurringExpenseDTO dto) {
        RecurringExpense re = recurringExpenseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Recurring expense not found with id " + id));
        if (!re.getUserId().equals(userId)) {
            throw new BadRequestException("Unauthorized access to recurring expense");
        }

        re.setName(dto.getName());
        re.setAmount(dto.getAmount());
        re.setCategory(dto.getCategory());
        re.setFrequency(dto.getFrequency() != null ? dto.getFrequency().toUpperCase() : "MONTHLY");
        re.setStartDate(dto.getStartDate());
        re.setEndDate(dto.getEndDate());

        RecurringExpense updated = recurringExpenseRepository.save(re);
        return mapToDTO(updated);
    }

    @Transactional
    public void deleteRecurringExpense(Long userId, Long id) {
        RecurringExpense re = recurringExpenseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Recurring expense not found with id " + id));
        if (!re.getUserId().equals(userId)) {
            throw new BadRequestException("Unauthorized access to recurring expense");
        }
        recurringExpenseRepository.delete(re);
    }

    private RecurringExpenseDTO mapToDTO(RecurringExpense entity) {
        RecurringExpenseDTO dto = new RecurringExpenseDTO();
        dto.setId(entity.getId());
        dto.setName(entity.getName());
        dto.setAmount(entity.getAmount());
        dto.setCategory(entity.getCategory());
        dto.setFrequency(entity.getFrequency());
        dto.setStartDate(entity.getStartDate());
        dto.setEndDate(entity.getEndDate());

        LocalDate today = LocalDate.now();
        boolean isActive = entity.getEndDate() == null || !today.isAfter(entity.getEndDate());
        dto.setActive(isActive);

        // Compute next due date
        LocalDate nextDue = entity.getStartDate();
        if ("WEEKLY".equalsIgnoreCase(entity.getFrequency())) {
            while (nextDue.isBefore(today)) {
                nextDue = nextDue.plusWeeks(1);
            }
        } else {
            while (nextDue.isBefore(today)) {
                nextDue = nextDue.plusMonths(1);
            }
        }
        dto.setNextDueDate(nextDue);

        return dto;
    }
}
