package com.college.expensetracker.repository;

import com.college.expensetracker.entity.CategoryBudget;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CategoryBudgetRepository extends JpaRepository<CategoryBudget, Long> {
    List<CategoryBudget> findByUserIdAndMonthAndYear(Long userId, Integer month, Integer year);
    Optional<CategoryBudget> findByUserIdAndCategoryAndMonthAndYear(Long userId, String category, Integer month, Integer year);
}
