package com.college.expensetracker.repository;

import com.college.expensetracker.entity.Expense;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface ExpenseRepository extends JpaRepository<Expense, Long> {

    List<Expense> findByUserIdOrderByDateDesc(Long userId);

    Page<Expense> findByUserId(Long userId, Pageable pageable);

    List<Expense> findByUserIdAndDateBetweenOrderByDateDesc(Long userId, LocalDate startDate, LocalDate endDate);

    @Query("SELECT e FROM Expense e WHERE e.userId = :userId " +
           "AND (:category IS NULL OR e.category = :category) " +
           "AND (:search IS NULL OR LOWER(e.description) LIKE LOWER(CONCAT('%', :search, '%'))) " +
           "AND (:startDate IS NULL OR e.date >= :startDate) " +
           "AND (:endDate IS NULL OR e.date <= :endDate) " +
           "ORDER BY e.date DESC")
    List<Expense> searchExpenses(
            @Param("userId") Long userId,
            @Param("category") String category,
            @Param("search") String search,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate
    );

    @Query("SELECT COALESCE(SUM(e.amount), 0) FROM Expense e WHERE e.userId = :userId AND e.date BETWEEN :startDate AND :endDate")
    BigDecimal getTotalExpenseBetween(
            @Param("userId") Long userId,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate
    );

    @Query("SELECT e.category, SUM(e.amount) FROM Expense e " +
           "WHERE e.userId = :userId AND e.date BETWEEN :startDate AND :endDate " +
           "GROUP BY e.category ORDER BY SUM(e.amount) DESC")
    List<Object[]> getCategoryWiseSum(
            @Param("userId") Long userId,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate
    );

    @Query("SELECT FUNCTION('DATE_FORMAT', e.date, '%Y-%m') as monthStr, SUM(e.amount) " +
           "FROM Expense e WHERE e.userId = :userId " +
           "GROUP BY FUNCTION('DATE_FORMAT', e.date, '%Y-%m') " +
           "ORDER BY monthStr ASC")
    List<Object[]> getMonthlyTrends(@Param("userId") Long userId);
}
