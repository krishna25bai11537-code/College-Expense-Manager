package com.college.expensetracker.service;

import com.college.expensetracker.dto.AnalyticsDTO.*;
import com.college.expensetracker.entity.Budget;
import com.college.expensetracker.repository.BudgetRepository;
import com.college.expensetracker.repository.ExpenseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class AnalyticsService {

    @Autowired
    private ExpenseRepository expenseRepository;

    @Autowired
    private BudgetRepository budgetRepository;

    private static final Map<String, String> CATEGORY_COLORS = new HashMap<>() {{
        put("Food", "#f97316"); // Orange
        put("Travel", "#3b82f6"); // Blue
        put("Education", "#8b5cf6"); // Purple
        put("Entertainment", "#ec4899"); // Pink
        put("Health", "#10b981"); // Emerald
        put("Hostel", "#6366f1"); // Indigo
        put("Shopping", "#f59e0b"); // Amber
        put("Bills", "#06b6d4"); // Cyan
        put("Other", "#64748b"); // Slate
    }};

    public AnalyticsResponse getAnalytics(Long userId, Integer month, Integer year) {
        LocalDate now = LocalDate.now();
        int targetMonth = (month != null) ? month : now.getMonthValue();
        int targetYear = (year != null) ? year : now.getYear();

        YearMonth yearMonth = YearMonth.of(targetYear, targetMonth);
        LocalDate startDate = yearMonth.atDay(1);
        LocalDate endDate = yearMonth.atEndOfMonth();

        BigDecimal totalBudget = budgetRepository.findByUserIdAndMonthAndYear(userId, targetMonth, targetYear)
                .map(Budget::getAmount)
                .orElse(BigDecimal.valueOf(10000.00));

        BigDecimal totalSpent = expenseRepository.getTotalExpenseBetween(userId, startDate, endDate);
        if (totalSpent == null) totalSpent = BigDecimal.ZERO;

        // 1. Category-wise spending
        List<Object[]> rawCategories = expenseRepository.getCategoryWiseSum(userId, startDate, endDate);
        List<CategorySliceDTO> categoryList = new ArrayList<>();

        for (Object[] row : rawCategories) {
            String cat = (String) row[0];
            BigDecimal amt = (BigDecimal) row[1];
            double pct = totalSpent.compareTo(BigDecimal.ZERO) > 0
                    ? amt.multiply(BigDecimal.valueOf(100)).divide(totalSpent, 1, RoundingMode.HALF_UP).doubleValue()
                    : 0.0;
            String color = CATEGORY_COLORS.getOrDefault(cat, "#94a3b8");
            categoryList.add(new CategorySliceDTO(cat, amt, pct, color));
        }

        // 2. Weekly breakdown for line chart
        List<WeeklyDataPointDTO> weeklyList = new ArrayList<>();
        LocalDate weekCursor = startDate;
        int weekNumber = 1;
        while (!weekCursor.isAfter(endDate)) {
            LocalDate weekEnd = weekCursor.plusDays(6);
            if (weekEnd.isAfter(endDate)) {
                weekEnd = endDate;
            }
            BigDecimal weekAmt = expenseRepository.getTotalExpenseBetween(userId, weekCursor, weekEnd);
            weeklyList.add(new WeeklyDataPointDTO("Wk " + weekNumber + " (" + weekCursor.getDayOfMonth() + "-" + weekEnd.getDayOfMonth() + ")",
                    weekAmt != null ? weekAmt : BigDecimal.ZERO));

            weekCursor = weekEnd.plusDays(1);
            weekNumber++;
        }

        // 3. Monthly trends for bar chart (Past 6 months)
        List<MonthlyDataPointDTO> monthlyList = new ArrayList<>();
        for (int i = 5; i >= 0; i--) {
            YearMonth ym = YearMonth.now().minusMonths(i);
            LocalDate ymStart = ym.atDay(1);
            LocalDate ymEnd = ym.atEndOfMonth();
            BigDecimal mSpent = expenseRepository.getTotalExpenseBetween(userId, ymStart, ymEnd);
            BigDecimal mBudget = budgetRepository.findByUserIdAndMonthAndYear(userId, ym.getMonthValue(), ym.getYear())
                    .map(Budget::getAmount).orElse(BigDecimal.valueOf(10000.00));

            String label = ym.format(DateTimeFormatter.ofPattern("MMM yyyy"));
            monthlyList.add(new MonthlyDataPointDTO(label, mSpent != null ? mSpent : BigDecimal.ZERO, mBudget));
        }

        // Top categories (up to 4)
        List<CategorySliceDTO> topCats = categoryList.stream().limit(4).toList();

        AnalyticsResponse response = new AnalyticsResponse();
        response.setSelectedMonth(targetMonth);
        response.setSelectedYear(targetYear);
        response.setTotalSpent(totalSpent);
        response.setTotalBudget(totalBudget);
        response.setCategoryWiseSpending(categoryList);
        response.setMonthlySpending(monthlyList);
        response.setWeeklySpending(weeklyList);
        response.setTopCategories(topCats);

        return response;
    }
}
