package com.college.expensetracker.controller;

import com.college.expensetracker.dto.DashboardDTO;
import com.college.expensetracker.security.UserPrincipal;
import com.college.expensetracker.service.DashboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    @Autowired
    private DashboardService dashboardService;

    @GetMapping
    public ResponseEntity<DashboardDTO> getDashboard(@AuthenticationPrincipal UserPrincipal currentUser) {
        DashboardDTO dashboardData = dashboardService.getDashboardData(currentUser.getId());
        return ResponseEntity.ok(dashboardData);
    }
}
