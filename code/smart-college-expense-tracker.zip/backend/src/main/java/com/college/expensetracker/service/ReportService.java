package com.college.expensetracker.service;

import com.college.expensetracker.dto.AnalyticsDTO;
import com.college.expensetracker.dto.BudgetDTOs;
import com.college.expensetracker.dto.ExpenseDTO;
import com.college.expensetracker.dto.ReportDTO.ReportSummaryResponse;
import com.college.expensetracker.entity.Expense;
import com.college.expensetracker.repository.ExpenseRepository;
import com.opencsv.CSVWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReportService {

    @Autowired
    private ExpenseRepository expenseRepository;

    @Autowired
    private BudgetService budgetService;

    @Autowired
    private AnalyticsService analyticsService;

    @Autowired
    private ExpenseService expenseService;

    public ReportSummaryResponse generateReport(Long userId, Integer month, Integer year) {
        LocalDate now = LocalDate.now();
        int targetMonth = (month != null) ? month : now.getMonthValue();
        int targetYear = (year != null) ? year : now.getYear();

        YearMonth yearMonth = YearMonth.of(targetYear, targetMonth);
        LocalDate start = yearMonth.atDay(1);
        LocalDate end = yearMonth.atEndOfMonth();

        BudgetDTOs.BudgetOverviewDTO budgetOverview = budgetService.getBudgetOverview(userId, targetMonth, targetYear);
        AnalyticsDTO.AnalyticsResponse analytics = analyticsService.getAnalytics(userId, targetMonth, targetYear);
        List<Expense> expenses = expenseRepository.findByUserIdAndDateBetweenOrderByDateDesc(userId, start, end);

        List<ExpenseDTO> expenseDTOs = expenses.stream().map(expenseService::mapToDTO).collect(Collectors.toList());

        BigDecimal totalBudget = budgetOverview.getTotalBudget();
        BigDecimal totalSpent = budgetOverview.getTotalSpent();
        BigDecimal netSavings = totalBudget.subtract(totalSpent);

        int daysInMonth = yearMonth.lengthOfMonth();
        BigDecimal avgDaily = totalSpent.divide(BigDecimal.valueOf(daysInMonth), 2, RoundingMode.HALF_UP);

        ReportSummaryResponse report = new ReportSummaryResponse();
        report.setMonth(targetMonth);
        report.setYear(targetYear);
        report.setTotalBudget(totalBudget);
        report.setTotalSpent(totalSpent);
        report.setNetSavings(netSavings);
        report.setBudgetUtilizationPercentage(budgetOverview.getPercentageUsed());
        report.setTotalTransactions(expenseDTOs.size());
        report.setAverageExpensePerDay(avgDaily);
        report.setCategorySummary(analytics.getCategoryWiseSpending());
        report.setBudgetReport(budgetOverview.getCategoryBudgets());
        report.setExpenseItems(expenseDTOs);

        return report;
    }

    public byte[] exportExpensesCsv(Long userId, Integer month, Integer year) {
        LocalDate now = LocalDate.now();
        int targetMonth = (month != null) ? month : now.getMonthValue();
        int targetYear = (year != null) ? year : now.getYear();

        YearMonth ym = YearMonth.of(targetYear, targetMonth);
        List<Expense> expenses = expenseRepository.findByUserIdAndDateBetweenOrderByDateDesc(userId, ym.atDay(1), ym.atEndOfMonth());

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (CSVWriter writer = new CSVWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8))) {
            // Header
            writer.writeNext(new String[]{
                    "Transaction ID", "Date", "Category", "Amount (INR)", "Payment Method", "Description"
            });

            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            for (Expense exp : expenses) {
                writer.writeNext(new String[]{
                        String.valueOf(exp.getId()),
                        exp.getDate().format(dtf),
                        exp.getCategory(),
                        exp.getAmount().setScale(2, RoundingMode.HALF_UP).toString(),
                        exp.getPaymentMethod(),
                        exp.getDescription() != null ? exp.getDescription() : ""
                });
            }
            writer.flush();
        } catch (Exception e) {
            throw new RuntimeException("Error while exporting CSV report", e);
        }

        return out.toByteArray();
    }
}
