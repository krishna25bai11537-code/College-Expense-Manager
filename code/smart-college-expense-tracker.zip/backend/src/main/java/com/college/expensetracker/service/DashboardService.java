package com.college.expensetracker.service;

import com.college.expensetracker.dto.DashboardDTO;
import com.college.expensetracker.dto.DashboardDTO.MonthlyTrendDTO;
import com.college.expensetracker.dto.ExpenseDTO;
import com.college.expensetracker.entity.Budget;
import com.college.expensetracker.entity.Expense;
import com.college.expensetracker.repository.BudgetRepository;
import com.college.expensetracker.repository.ExpenseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DashboardService {

    @Autowired
    private ExpenseRepository expenseRepository;

    @Autowired
    private BudgetRepository budgetRepository;

    @Autowired
    private ExpenseService expenseService;

    @Autowired
    private AlertService alertService;

    @Autowired
    private SpendingScoreService spendingScoreService;

    public DashboardDTO getDashboardData(Long userId) {
        LocalDate today = LocalDate.now();
        int currentMonth = today.getMonthValue();
        int currentYear = today.getYear();

        YearMonth yearMonth = YearMonth.of(currentYear, currentMonth);
        LocalDate startOfMonth = yearMonth.atDay(1);
        LocalDate endOfMonth = yearMonth.atEndOfMonth();

        // Total expenses this month
        BigDecimal totalSpent = expenseRepository.getTotalExpenseBetween(userId, startOfMonth, endOfMonth);
        if (totalSpent == null) totalSpent = BigDecimal.ZERO;

        // Monthly budget
        BigDecimal monthlyBudget = budgetRepository.findByUserIdAndMonthAndYear(userId, currentMonth, currentYear)
                .map(Budget::getAmount)
                .orElse(BigDecimal.valueOf(10000.00));

        BigDecimal remainingBudget = monthlyBudget.subtract(totalSpent);
        double budgetPercentage = monthlyBudget.compareTo(BigDecimal.ZERO) > 0
                ? totalSpent.multiply(BigDecimal.valueOf(100)).divide(monthlyBudget, 2, RoundingMode.HALF_UP).doubleValue()
                : 0.0;

        // Today's expenses
        BigDecimal todayExpenses = expenseRepository.getTotalExpenseBetween(userId, today, today);
        if (todayExpenses == null) todayExpenses = BigDecimal.ZERO;

        // Transactions this month
        List<Expense> monthlyExpenses = expenseRepository.findByUserIdAndDateBetweenOrderByDateDesc(userId, startOfMonth, endOfMonth);
        long transactionsCount = monthlyExpenses.size();

        // Highest spending category
        List<Object[]> categorySums = expenseRepository.getCategoryWiseSum(userId, startOfMonth, endOfMonth);
        String highestCategory = "None";
        BigDecimal highestCategoryAmount = BigDecimal.ZERO;
        if (!categorySums.isEmpty()) {
            highestCategory = (String) categorySums.get(0)[0];
            highestCategoryAmount = (BigDecimal) categorySums.get(0)[1];
        }

        // Recent transactions (top 5)
        List<ExpenseDTO> recentExpenses = monthlyExpenses.stream()
                .limit(6)
                .map(expenseService::mapToDTO)
                .collect(Collectors.toList());

        // Monthly spending trends (past 6 months)
        List<MonthlyTrendDTO> trend = new ArrayList<>();
        for (int i = 5; i >= 0; i--) {
            YearMonth ym = YearMonth.now().minusMonths(i);
            BigDecimal mSpent = expenseRepository.getTotalExpenseBetween(userId, ym.atDay(1), ym.atEndOfMonth());
            trend.add(new MonthlyTrendDTO(ym.format(DateTimeFormatter.ofPattern("MMM")), mSpent != null ? mSpent : BigDecimal.ZERO));
        }

        DashboardDTO dto = new DashboardDTO();
        dto.setTotalExpensesThisMonth(totalSpent);
        dto.setMonthlyBudget(monthlyBudget);
        dto.setRemainingBudget(remainingBudget);
        dto.setBudgetPercentageUsed(budgetPercentage);
        dto.setTodayExpenses(todayExpenses);
        dto.setTotalTransactionsCount(transactionsCount);
        dto.setHighestSpendingCategory(highestCategory);
        dto.setHighestCategoryAmount(highestCategoryAmount);
        dto.setRecentTransactions(recentExpenses);
        dto.setMonthlySpendingTrend(trend);
        dto.setRecentAlerts(alertService.generateAlerts(userId));
        dto.setQuickSpendingScore(spendingScoreService.calculateScore(userId, currentMonth, currentYear));

        return dto;
    }
}
