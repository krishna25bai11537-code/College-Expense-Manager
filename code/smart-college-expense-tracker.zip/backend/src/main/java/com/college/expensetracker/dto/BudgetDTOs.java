package com.college.expensetracker.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

public class BudgetDTOs {

    public static class BudgetRequest {
        @NotNull(message = "Month is required")
        private Integer month;

        @NotNull(message = "Year is required")
        private Integer year;

        @NotNull(message = "Amount is required")
        @DecimalMin(value = "1.0", message = "Budget amount must be at least ₹1")
        private BigDecimal amount;

        public BudgetRequest() {}
        public BudgetRequest(Integer month, Integer year, BigDecimal amount) {
            this.month = month;
            this.year = year;
            this.amount = amount;
        }

        public Integer getMonth() { return month; }
        public void setMonth(Integer month) { this.month = month; }
        public Integer getYear() { return year; }
        public void setYear(Integer year) { this.year = year; }
        public BigDecimal getAmount() { return amount; }
        public void setAmount(BigDecimal amount) { this.amount = amount; }
    }

    public static class CategoryBudgetRequest {
        private String category;
        private BigDecimal amount;
        private Integer month;
        private Integer year;

        public CategoryBudgetRequest() {}
        public CategoryBudgetRequest(String category, BigDecimal amount, Integer month, Integer year) {
            this.category = category;
            this.amount = amount;
            this.month = month;
            this.year = year;
        }

        public String getCategory() { return category; }
        public void setCategory(String category) { this.category = category; }
        public BigDecimal getAmount() { return amount; }
        public void setAmount(BigDecimal amount) { this.amount = amount; }
        public Integer getMonth() { return month; }
        public void setMonth(Integer month) { this.month = month; }
        public Integer getYear() { return year; }
        public void setYear(Integer year) { this.year = year; }
    }

    public static class CategoryBudgetDetailDTO {
        private Long id;
        private String category;
        private BigDecimal budgetedAmount;
        private BigDecimal spentAmount;
        private BigDecimal remainingAmount;
        private double percentageUsed;
        private String warningMessage;
        private String warningLevel; // "SAFE", "WARNING", "CRITICAL", "EXCEEDED"

        public CategoryBudgetDetailDTO() {}

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getCategory() { return category; }
        public void setCategory(String category) { this.category = category; }
        public BigDecimal getBudgetedAmount() { return budgetedAmount; }
        public void setBudgetedAmount(BigDecimal budgetedAmount) { this.budgetedAmount = budgetedAmount; }
        public BigDecimal getSpentAmount() { return spentAmount; }
        public void setSpentAmount(BigDecimal spentAmount) { this.spentAmount = spentAmount; }
        public BigDecimal getRemainingAmount() { return remainingAmount; }
        public void setRemainingAmount(BigDecimal remainingAmount) { this.remainingAmount = remainingAmount; }
        public double getPercentageUsed() { return percentageUsed; }
        public void setPercentageUsed(double percentageUsed) { this.percentageUsed = percentageUsed; }
        public String getWarningMessage() { return warningMessage; }
        public void setWarningMessage(String warningMessage) { this.warningMessage = warningMessage; }
        public String getWarningLevel() { return warningLevel; }
        public void setWarningLevel(String warningLevel) { this.warningLevel = warningLevel; }
    }

    public static class BudgetOverviewDTO {
        private Integer month;
        private Integer year;
        private BigDecimal totalBudget;
        private BigDecimal totalSpent;
        private BigDecimal remainingBudget;
        private double percentageUsed;
        private String warningMessage;
        private String warningLevel; // "SAFE", "WARNING", "CRITICAL", "EXCEEDED"
        private List<CategoryBudgetDetailDTO> categoryBudgets;

        public BudgetOverviewDTO() {}

        public Integer getMonth() { return month; }
        public void setMonth(Integer month) { this.month = month; }
        public Integer getYear() { return year; }
        public void setYear(Integer year) { this.year = year; }
        public BigDecimal getTotalBudget() { return totalBudget; }
        public void setTotalBudget(BigDecimal totalBudget) { this.totalBudget = totalBudget; }
        public BigDecimal getTotalSpent() { return totalSpent; }
        public void setTotalSpent(BigDecimal totalSpent) { this.totalSpent = totalSpent; }
        public BigDecimal getRemainingBudget() { return remainingBudget; }
        public void setRemainingBudget(BigDecimal remainingBudget) { this.remainingBudget = remainingBudget; }
        public double getPercentageUsed() { return percentageUsed; }
        public void setPercentageUsed(double percentageUsed) { this.percentageUsed = percentageUsed; }
        public String getWarningMessage() { return warningMessage; }
        public void setWarningMessage(String warningMessage) { this.warningMessage = warningMessage; }
        public String getWarningLevel() { return warningLevel; }
        public void setWarningLevel(String warningLevel) { this.warningLevel = warningLevel; }
        public List<CategoryBudgetDetailDTO> getCategoryBudgets() { return categoryBudgets; }
        public void setCategoryBudgets(List<CategoryBudgetDetailDTO> categoryBudgets) { this.categoryBudgets = categoryBudgets; }
    }
}
