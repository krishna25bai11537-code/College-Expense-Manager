package com.college.expensetracker.service;

import com.college.expensetracker.dto.ExpenseDTO;
import com.college.expensetracker.entity.Expense;
import com.college.expensetracker.exception.BadRequestException;
import com.college.expensetracker.exception.ResourceNotFoundException;
import com.college.expensetracker.repository.ExpenseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ExpenseService {

    @Autowired
    private ExpenseRepository expenseRepository;

    public List<ExpenseDTO> getExpenses(Long userId, String category, String search, LocalDate startDate, LocalDate endDate, String sortBy, String sortOrder) {
        List<Expense> expenses = expenseRepository.searchExpenses(
                userId,
                (category != null && !category.equalsIgnoreCase("ALL")) ? category : null,
                (search != null && !search.trim().isEmpty()) ? search.trim() : null,
                startDate,
                endDate
        );

        // Sorting
        Comparator<Expense> comparator;
        if ("amount".equalsIgnoreCase(sortBy)) {
            comparator = Comparator.comparing(Expense::getAmount);
        } else {
            comparator = Comparator.comparing(Expense::getDate);
        }

        if ("asc".equalsIgnoreCase(sortOrder)) {
            expenses.sort(comparator);
        } else {
            expenses.sort(comparator.reversed());
        }

        return expenses.stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public ExpenseDTO getExpenseById(Long userId, Long expenseId) {
        Expense expense = expenseRepository.findById(expenseId)
                .orElseThrow(() -> new ResourceNotFoundException("Expense not found with id " + expenseId));

        if (!expense.getUserId().equals(userId)) {
            throw new BadRequestException("Unauthorized access to this expense");
        }

        return mapToDTO(expense);
    }

    @Transactional
    public ExpenseDTO createExpense(Long userId, ExpenseDTO dto) {
        Expense expense = new Expense();
        expense.setUserId(userId);
        expense.setAmount(dto.getAmount());
        expense.setCategory(dto.getCategory());
        expense.setPaymentMethod(dto.getPaymentMethod());
        expense.setDescription(dto.getDescription());
        expense.setDate(dto.getDate());

        Expense saved = expenseRepository.save(expense);
        return mapToDTO(saved);
    }

    @Transactional
    public ExpenseDTO updateExpense(Long userId, Long expenseId, ExpenseDTO dto) {
        Expense expense = expenseRepository.findById(expenseId)
                .orElseThrow(() -> new ResourceNotFoundException("Expense not found with id " + expenseId));

        if (!expense.getUserId().equals(userId)) {
            throw new BadRequestException("Unauthorized access to this expense");
        }

        expense.setAmount(dto.getAmount());
        expense.setCategory(dto.getCategory());
        expense.setPaymentMethod(dto.getPaymentMethod());
        expense.setDescription(dto.getDescription());
        expense.setDate(dto.getDate());

        Expense updated = expenseRepository.save(expense);
        return mapToDTO(updated);
    }

    @Transactional
    public void deleteExpense(Long userId, Long expenseId) {
        Expense expense = expenseRepository.findById(expenseId)
                .orElseThrow(() -> new ResourceNotFoundException("Expense not found with id " + expenseId));

        if (!expense.getUserId().equals(userId)) {
            throw new BadRequestException("Unauthorized access to this expense");
        }

        expenseRepository.delete(expense);
    }

    public ExpenseDTO mapToDTO(Expense expense) {
        return new ExpenseDTO(
                expense.getId(),
                expense.getAmount(),
                expense.getCategory(),
                expense.getPaymentMethod(),
                expense.getDescription(),
                expense.getDate(),
                expense.getCreatedAt()
        );
    }
}
