package com.college.expensetracker.controller;

import com.college.expensetracker.dto.RecurringExpenseDTO;
import com.college.expensetracker.security.UserPrincipal;
import com.college.expensetracker.service.RecurringExpenseService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/recurring-expenses")
public class RecurringExpenseController {

    @Autowired
    private RecurringExpenseService recurringExpenseService;

    @GetMapping
    public ResponseEntity<List<RecurringExpenseDTO>> getAllRecurring(@AuthenticationPrincipal UserPrincipal currentUser) {
        List<RecurringExpenseDTO> list = recurringExpenseService.getAllRecurringExpenses(currentUser.getId());
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<RecurringExpenseDTO> getById(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id
    ) {
        RecurringExpenseDTO dto = recurringExpenseService.getById(currentUser.getId(), id);
        return ResponseEntity.ok(dto);
    }

    @PostMapping
    public ResponseEntity<RecurringExpenseDTO> create(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @Valid @RequestBody RecurringExpenseDTO dto
    ) {
        RecurringExpenseDTO created = recurringExpenseService.createRecurringExpense(currentUser.getId(), dto);
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<RecurringExpenseDTO> update(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id,
            @Valid @RequestBody RecurringExpenseDTO dto
    ) {
        RecurringExpenseDTO updated = recurringExpenseService.updateRecurringExpense(currentUser.getId(), id, dto);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id
    ) {
        recurringExpenseService.deleteRecurringExpense(currentUser.getId(), id);
        return ResponseEntity.noContent().build();
    }
}
