package com.college.expensetracker.controller;

import com.college.expensetracker.dto.AnalyticsDTO.*;
import com.college.expensetracker.security.UserPrincipal;
import com.college.expensetracker.service.AnalyticsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/analytics")
public class AnalyticsController {

    @Autowired
    private AnalyticsService analyticsService;

    @GetMapping
    public ResponseEntity<AnalyticsResponse> getAnalytics(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(required = false) Integer month,
            @RequestParam(required = false) Integer year
    ) {
        AnalyticsResponse response = analyticsService.getAnalytics(currentUser.getId(), month, year);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/monthly")
    public ResponseEntity<List<MonthlyDataPointDTO>> getMonthlySpending(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(required = false) Integer month,
            @RequestParam(required = false) Integer year
    ) {
        AnalyticsResponse response = analyticsService.getAnalytics(currentUser.getId(), month, year);
        return ResponseEntity.ok(response.getMonthlySpending());
    }

    @GetMapping("/category")
    public ResponseEntity<List<CategorySliceDTO>> getCategorySpending(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(required = false) Integer month,
            @RequestParam(required = false) Integer year
    ) {
        AnalyticsResponse response = analyticsService.getAnalytics(currentUser.getId(), month, year);
        return ResponseEntity.ok(response.getCategoryWiseSpending());
    }
}
