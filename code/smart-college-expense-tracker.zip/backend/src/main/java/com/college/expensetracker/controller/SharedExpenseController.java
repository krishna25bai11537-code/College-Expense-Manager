package com.college.expensetracker.controller;

import com.college.expensetracker.dto.SharedExpenseDTO.*;
import com.college.expensetracker.security.UserPrincipal;
import com.college.expensetracker.service.SharedExpenseService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/shared-expenses")
public class SharedExpenseController {

    @Autowired
    private SharedExpenseService sharedExpenseService;

    @GetMapping
    public ResponseEntity<List<SharedExpenseResponse>> getAllSharedExpenses(@AuthenticationPrincipal UserPrincipal currentUser) {
        List<SharedExpenseResponse> list = sharedExpenseService.getAllSharedExpenses(currentUser.getId());
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<SharedExpenseResponse> getSharedExpenseById(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id
    ) {
        SharedExpenseResponse response = sharedExpenseService.getSharedExpenseById(currentUser.getId(), id);
        return ResponseEntity.ok(response);
    }

    @PostMapping
    public ResponseEntity<SharedExpenseResponse> createSharedExpense(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @Valid @RequestBody CreateSharedExpenseRequest request
    ) {
        SharedExpenseResponse created = sharedExpenseService.createSharedExpense(currentUser.getId(), request);
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<SharedExpenseResponse> updateSharedExpense(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id,
            @Valid @RequestBody CreateSharedExpenseRequest request
    ) {
        SharedExpenseResponse updated = sharedExpenseService.updateSharedExpense(currentUser.getId(), id, request);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSharedExpense(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id
    ) {
        sharedExpenseService.deleteSharedExpense(currentUser.getId(), id);
        return ResponseEntity.noContent().build();
    }
}
