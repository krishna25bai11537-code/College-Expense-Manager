package com.college.expensetracker.service;

import com.college.expensetracker.dto.BudgetDTOs.*;
import com.college.expensetracker.entity.Budget;
import com.college.expensetracker.entity.CategoryBudget;
import com.college.expensetracker.repository.BudgetRepository;
import com.college.expensetracker.repository.CategoryBudgetRepository;
import com.college.expensetracker.repository.ExpenseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class BudgetService {

    @Autowired
    private BudgetRepository budgetRepository;

    @Autowired
    private CategoryBudgetRepository categoryBudgetRepository;

    @Autowired
    private ExpenseRepository expenseRepository;

    public BudgetOverviewDTO getBudgetOverview(Long userId, Integer month, Integer year) {
        LocalDate now = LocalDate.now();
        int targetMonth = (month != null) ? month : now.getMonthValue();
        int targetYear = (year != null) ? year : now.getYear();

        YearMonth yearMonth = YearMonth.of(targetYear, targetMonth);
        LocalDate startDate = yearMonth.atDay(1);
        LocalDate endDate = yearMonth.atEndOfMonth();

        // 1. Overall monthly budget
        Optional<Budget> budgetOpt = budgetRepository.findByUserIdAndMonthAndYear(userId, targetMonth, targetYear);
        BigDecimal totalBudget = budgetOpt.map(Budget::getAmount).orElse(BigDecimal.valueOf(10000.00)); // Default ₹10,000 for college students

        BigDecimal totalSpent = expenseRepository.getTotalExpenseBetween(userId, startDate, endDate);
        if (totalSpent == null) totalSpent = BigDecimal.ZERO;

        BigDecimal remainingBudget = totalBudget.subtract(totalSpent);
        double percentageUsed = totalBudget.compareTo(BigDecimal.ZERO) > 0
                ? totalSpent.multiply(BigDecimal.valueOf(100)).divide(totalBudget, 2, RoundingMode.HALF_UP).doubleValue()
                : 0.0;

        BudgetOverviewDTO overview = new BudgetOverviewDTO();
        overview.setMonth(targetMonth);
        overview.setYear(targetYear);
        overview.setTotalBudget(totalBudget);
        overview.setTotalSpent(totalSpent);
        overview.setRemainingBudget(remainingBudget);
        overview.setPercentageUsed(percentageUsed);

        // Warning rules:
        // 70% used -> "You're getting close to your limit."
        // 90% used -> "⚠️ Your budget is almost exhausted."
        // 100%+ -> "🚨 You have exceeded your budget."
        if (percentageUsed >= 100.0) {
            overview.setWarningLevel("EXCEEDED");
            overview.setWarningMessage("🚨 You have exceeded your budget.");
        } else if (percentageUsed >= 90.0) {
            overview.setWarningLevel("CRITICAL");
            overview.setWarningMessage("⚠️ Your budget is almost exhausted.");
        } else if (percentageUsed >= 70.0) {
            overview.setWarningLevel("WARNING");
            overview.setWarningMessage("You're getting close to your limit.");
        } else {
            overview.setWarningLevel("SAFE");
            overview.setWarningMessage("Budget is on track 👍");
        }

        // 2. Category budgets
        List<CategoryBudget> catBudgets = categoryBudgetRepository.findByUserIdAndMonthAndYear(userId, targetMonth, targetYear);
        List<Object[]> catSpends = expenseRepository.getCategoryWiseSum(userId, startDate, endDate);

        List<CategoryBudgetDetailDTO> catDetails = new ArrayList<>();
        for (CategoryBudget cb : catBudgets) {
            CategoryBudgetDetailDTO detail = new CategoryBudgetDetailDTO();
            detail.setId(cb.getId());
            detail.setCategory(cb.getCategory());
            detail.setBudgetedAmount(cb.getAmount());

            BigDecimal spent = BigDecimal.ZERO;
            for (Object[] row : catSpends) {
                if (cb.getCategory().equalsIgnoreCase((String) row[0])) {
                    spent = (BigDecimal) row[1];
                    break;
                }
            }

            detail.setSpentAmount(spent);
            detail.setRemainingAmount(cb.getAmount().subtract(spent));

            double catPct = cb.getAmount().compareTo(BigDecimal.ZERO) > 0
                    ? spent.multiply(BigDecimal.valueOf(100)).divide(cb.getAmount(), 2, RoundingMode.HALF_UP).doubleValue()
                    : 0.0;
            detail.setPercentageUsed(catPct);

            if (catPct >= 100.0) {
                detail.setWarningLevel("EXCEEDED");
                detail.setWarningMessage("🚨 Exceeded " + cb.getCategory() + " budget");
            } else if (catPct >= 90.0) {
                detail.setWarningLevel("CRITICAL");
                detail.setWarningMessage("⚠️ " + cb.getCategory() + " budget almost exhausted");
            } else if (catPct >= 70.0) {
                detail.setWarningLevel("WARNING");
                detail.setWarningMessage("Getting close to limit for " + cb.getCategory());
            } else {
                detail.setWarningLevel("SAFE");
                detail.setWarningMessage("Within healthy limits");
            }

            catDetails.add(detail);
        }

        overview.setCategoryBudgets(catDetails);
        return overview;
    }

    @Transactional
    public Budget setMonthlyBudget(Long userId, BudgetRequest request) {
        Budget budget = budgetRepository.findByUserIdAndMonthAndYear(userId, request.getMonth(), request.getYear())
                .orElse(new Budget(userId, request.getMonth(), request.getYear(), request.getAmount()));
        budget.setAmount(request.getAmount());
        return budgetRepository.save(budget);
    }

    @Transactional
    public CategoryBudget setCategoryBudget(Long userId, CategoryBudgetRequest request) {
        CategoryBudget cb = categoryBudgetRepository.findByUserIdAndCategoryAndMonthAndYear(
                userId, request.getCategory(), request.getMonth(), request.getYear())
                .orElse(new CategoryBudget(userId, request.getCategory(), request.getAmount(), request.getMonth(), request.getYear()));
        cb.setAmount(request.getAmount());
        return categoryBudgetRepository.save(cb);
    }
}
