package com.college.expensetracker.dto;

import java.math.BigDecimal;
import java.util.List;

public class AnalyticsDTO {

    public static class CategorySliceDTO {
        private String category;
        private BigDecimal amount;
        private double percentage;
        private String color;

        public CategorySliceDTO() {}
        public CategorySliceDTO(String category, BigDecimal amount, double percentage, String color) {
            this.category = category;
            this.amount = amount;
            this.percentage = percentage;
            this.color = color;
        }

        public String getCategory() { return category; }
        public void setCategory(String category) { this.category = category; }
        public BigDecimal getAmount() { return amount; }
        public void setAmount(BigDecimal amount) { this.amount = amount; }
        public double getPercentage() { return percentage; }
        public void setPercentage(double percentage) { this.percentage = percentage; }
        public String getColor() { return color; }
        public void setColor(String color) { this.color = color; }
    }

    public static class WeeklyDataPointDTO {
        private String weekLabel;
        private BigDecimal amount;

        public WeeklyDataPointDTO() {}
        public WeeklyDataPointDTO(String weekLabel, BigDecimal amount) {
            this.weekLabel = weekLabel;
            this.amount = amount;
        }

        public String getWeekLabel() { return weekLabel; }
        public void setWeekLabel(String weekLabel) { this.weekLabel = weekLabel; }
        public BigDecimal getAmount() { return amount; }
        public void setAmount(BigDecimal amount) { this.amount = amount; }
    }

    public static class MonthlyDataPointDTO {
        private String month;
        private BigDecimal amount;
        private BigDecimal budget;

        public MonthlyDataPointDTO() {}
        public MonthlyDataPointDTO(String month, BigDecimal amount, BigDecimal budget) {
            this.month = month;
            this.amount = amount;
            this.budget = budget;
        }

        public String getMonth() { return month; }
        public void setMonth(String month) { this.month = month; }
        public BigDecimal getAmount() { return amount; }
        public void setAmount(BigDecimal amount) { this.amount = amount; }
        public BigDecimal getBudget() { return budget; }
        public void setBudget(BigDecimal budget) { this.budget = budget; }
    }

    public static class AnalyticsResponse {
        private Integer selectedMonth;
        private Integer selectedYear;
        private BigDecimal totalSpent;
        private BigDecimal totalBudget;
        private List<CategorySliceDTO> categoryWiseSpending;
        private List<MonthlyDataPointDTO> monthlySpending;
        private List<WeeklyDataPointDTO> weeklySpending;
        private List<CategorySliceDTO> topCategories;

        public AnalyticsResponse() {}

        public Integer getSelectedMonth() { return selectedMonth; }
        public void setSelectedMonth(Integer selectedMonth) { this.selectedMonth = selectedMonth; }
        public Integer getSelectedYear() { return selectedYear; }
        public void setSelectedYear(Integer selectedYear) { this.selectedYear = selectedYear; }
        public BigDecimal getTotalSpent() { return totalSpent; }
        public void setTotalSpent(BigDecimal totalSpent) { this.totalSpent = totalSpent; }
        public BigDecimal getTotalBudget() { return totalBudget; }
        public void setTotalBudget(BigDecimal totalBudget) { this.totalBudget = totalBudget; }
        public List<CategorySliceDTO> getCategoryWiseSpending() { return categoryWiseSpending; }
        public void setCategoryWiseSpending(List<CategorySliceDTO> categoryWiseSpending) { this.categoryWiseSpending = categoryWiseSpending; }
        public List<MonthlyDataPointDTO> getMonthlySpending() { return monthlySpending; }
        public void setMonthlySpending(List<MonthlyDataPointDTO> monthlySpending) { this.monthlySpending = monthlySpending; }
        public List<WeeklyDataPointDTO> getWeeklySpending() { return weeklySpending; }
        public void setWeeklySpending(List<WeeklyDataPointDTO> weeklySpending) { this.weeklySpending = weeklySpending; }
        public List<CategorySliceDTO> getTopCategories() { return topCategories; }
        public void setTopCategories(List<CategorySliceDTO> topCategories) { this.topCategories = topCategories; }
    }
}
