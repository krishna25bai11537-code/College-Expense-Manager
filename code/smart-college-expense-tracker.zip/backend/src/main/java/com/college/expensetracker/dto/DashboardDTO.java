package com.college.expensetracker.dto;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public class DashboardDTO {

    private BigDecimal totalExpensesThisMonth;
    private BigDecimal monthlyBudget;
    private BigDecimal remainingBudget;
    private double budgetPercentageUsed;
    private BigDecimal todayExpenses;
    private long totalTransactionsCount;
    private String highestSpendingCategory;
    private BigDecimal highestCategoryAmount;
    private List<ExpenseDTO> recentTransactions;
    private List<MonthlyTrendDTO> monthlySpendingTrend;
    private List<AlertDTO> recentAlerts;
    private SpendingScoreDTO quickSpendingScore;

    public static class MonthlyTrendDTO {
        private String month;
        private BigDecimal amount;

        public MonthlyTrendDTO() {}
        public MonthlyTrendDTO(String month, BigDecimal amount) {
            this.month = month;
            this.amount = amount;
        }

        public String getMonth() { return month; }
        public void setMonth(String month) { this.month = month; }
        public BigDecimal getAmount() { return amount; }
        public void setAmount(BigDecimal amount) { this.amount = amount; }
    }

    public DashboardDTO() {}

    public BigDecimal getTotalExpensesThisMonth() { return totalExpensesThisMonth; }
    public void setTotalExpensesThisMonth(BigDecimal totalExpensesThisMonth) { this.totalExpensesThisMonth = totalExpensesThisMonth; }

    public BigDecimal getMonthlyBudget() { return monthlyBudget; }
    public void setMonthlyBudget(BigDecimal monthlyBudget) { this.monthlyBudget = monthlyBudget; }

    public BigDecimal getRemainingBudget() { return remainingBudget; }
    public void setRemainingBudget(BigDecimal remainingBudget) { this.remainingBudget = remainingBudget; }

    public double getBudgetPercentageUsed() { return budgetPercentageUsed; }
    public void setBudgetPercentageUsed(double budgetPercentageUsed) { this.budgetPercentageUsed = budgetPercentageUsed; }

    public BigDecimal getTodayExpenses() { return todayExpenses; }
    public void setTodayExpenses(BigDecimal todayExpenses) { this.todayExpenses = todayExpenses; }

    public long getTotalTransactionsCount() { return totalTransactionsCount; }
    public void setTotalTransactionsCount(long totalTransactionsCount) { this.totalTransactionsCount = totalTransactionsCount; }

    public String getHighestSpendingCategory() { return highestSpendingCategory; }
    public void setHighestSpendingCategory(String highestSpendingCategory) { this.highestSpendingCategory = highestSpendingCategory; }

    public BigDecimal getHighestCategoryAmount() { return highestCategoryAmount; }
    public void setHighestCategoryAmount(BigDecimal highestCategoryAmount) { this.highestCategoryAmount = highestCategoryAmount; }

    public List<ExpenseDTO> getRecentTransactions() { return recentTransactions; }
    public void setRecentTransactions(List<ExpenseDTO> recentTransactions) { this.recentTransactions = recentTransactions; }

    public List<MonthlyTrendDTO> getMonthlySpendingTrend() { return monthlySpendingTrend; }
    public void setMonthlySpendingTrend(List<MonthlyTrendDTO> monthlySpendingTrend) { this.monthlySpendingTrend = monthlySpendingTrend; }

    public List<AlertDTO> getRecentAlerts() { return recentAlerts; }
    public void setRecentAlerts(List<AlertDTO> recentAlerts) { this.recentAlerts = recentAlerts; }

    public SpendingScoreDTO getQuickSpendingScore() { return quickSpendingScore; }
    public void setQuickSpendingScore(SpendingScoreDTO quickSpendingScore) { this.quickSpendingScore = quickSpendingScore; }
}
