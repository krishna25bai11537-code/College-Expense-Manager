package com.college.expensetracker.service;

import com.college.expensetracker.dto.SpendingScoreDTO;
import com.college.expensetracker.entity.Budget;
import com.college.expensetracker.entity.CategoryBudget;
import com.college.expensetracker.repository.BudgetRepository;
import com.college.expensetracker.repository.CategoryBudgetRepository;
import com.college.expensetracker.repository.ExpenseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Student Spending Score Calculator
 * Transparent, deterministic Java mathematical model designed for college viva evaluation.
 * Total Score: 0 - 100
 */
@Service
public class SpendingScoreService {

    @Autowired
    private BudgetRepository budgetRepository;

    @Autowired
    private CategoryBudgetRepository categoryBudgetRepository;

    @Autowired
    private ExpenseRepository expenseRepository;

    private static final List<String> DISCRETIONARY_CATEGORIES = Arrays.asList("Entertainment", "Shopping", "Other");

    public SpendingScoreDTO calculateScore(Long userId, Integer month, Integer year) {
        LocalDate now = LocalDate.now();
        int targetMonth = (month != null) ? month : now.getMonthValue();
        int targetYear = (year != null) ? year : now.getYear();

        YearMonth yearMonth = YearMonth.of(targetYear, targetMonth);
        LocalDate startDate = yearMonth.atDay(1);
        LocalDate endDate = yearMonth.atEndOfMonth();

        // 1. Fetch total monthly budget
        BigDecimal totalBudget = budgetRepository.findByUserIdAndMonthAndYear(userId, targetMonth, targetYear)
                .map(Budget::getAmount)
                .orElse(BigDecimal.valueOf(10000.00)); // Default ₹10,000

        // 2. Fetch total spent
        BigDecimal totalSpent = expenseRepository.getTotalExpenseBetween(userId, startDate, endDate);
        if (totalSpent == null) totalSpent = BigDecimal.ZERO;

        BigDecimal remaining = totalBudget.subtract(totalSpent);
        double budgetUsedRatio = totalBudget.compareTo(BigDecimal.ZERO) > 0
                ? totalSpent.divide(totalBudget, 4, RoundingMode.HALF_UP).doubleValue()
                : 0.0;

        // 3. Category breakdowns
        List<Object[]> categorySums = expenseRepository.getCategoryWiseSum(userId, startDate, endDate);
        BigDecimal discretionarySpend = BigDecimal.ZERO;
        for (Object[] row : categorySums) {
            String cat = (String) row[0];
            BigDecimal amt = (BigDecimal) row[1];
            if (DISCRETIONARY_CATEGORIES.stream().anyMatch(c -> c.equalsIgnoreCase(cat))) {
                discretionarySpend = discretionarySpend.add(amt);
            }
        }

        double unnecessaryRatio = totalSpent.compareTo(BigDecimal.ZERO) > 0
                ? discretionarySpend.divide(totalSpent, 4, RoundingMode.HALF_UP).doubleValue()
                : 0.0;

        // --- SCORING ALGORITHM (0 to 100) ---
        // Pillar 1: Budget Utilization (Max 35 points)
        int budgetUtilizationScore;
        if (budgetUsedRatio <= 0.50) {
            budgetUtilizationScore = 35;
        } else if (budgetUsedRatio <= 0.70) {
            budgetUtilizationScore = 30;
        } else if (budgetUsedRatio <= 0.85) {
            budgetUtilizationScore = 22;
        } else if (budgetUsedRatio <= 1.00) {
            budgetUtilizationScore = 12;
        } else {
            double excessRatio = budgetUsedRatio - 1.0;
            budgetUtilizationScore = Math.max(0, (int) Math.round(12 - (excessRatio * 30)));
        }

        // Pillar 2: Discretionary / Unnecessary Spending Control (Max 25 points)
        int discretionaryScore;
        if (unnecessaryRatio <= 0.15) {
            discretionaryScore = 25;
        } else if (unnecessaryRatio <= 0.30) {
            discretionaryScore = 20;
        } else if (unnecessaryRatio <= 0.45) {
            discretionaryScore = 15;
        } else if (unnecessaryRatio <= 0.60) {
            discretionaryScore = 8;
        } else {
            discretionaryScore = 3;
        }

        // Pillar 3: Category Discipline (Max 20 points)
        List<CategoryBudget> catBudgets = categoryBudgetRepository.findByUserIdAndMonthAndYear(userId, targetMonth, targetYear);
        int breachedCategories = 0;
        int warningCategories = 0;

        for (CategoryBudget cb : catBudgets) {
            BigDecimal spentInCat = BigDecimal.ZERO;
            for (Object[] row : categorySums) {
                if (cb.getCategory().equalsIgnoreCase((String) row[0])) {
                    spentInCat = (BigDecimal) row[1];
                    break;
                }
            }
            if (spentInCat.compareTo(cb.getAmount()) > 0) {
                breachedCategories++;
            } else if (cb.getAmount().compareTo(BigDecimal.ZERO) > 0 &&
                    spentInCat.divide(cb.getAmount(), 2, RoundingMode.HALF_UP).doubleValue() >= 0.90) {
                warningCategories++;
            }
        }

        int categoryDisciplineScore = 20;
        categoryDisciplineScore -= (breachedCategories * 8);
        categoryDisciplineScore -= (warningCategories * 3);
        categoryDisciplineScore = Math.max(0, categoryDisciplineScore);

        // Pillar 4: Savings Ratio & Remaining Buffer (Max 20 points)
        int savingsScore;
        double remainingRatio = totalBudget.compareTo(BigDecimal.ZERO) > 0
                ? remaining.divide(totalBudget, 4, RoundingMode.HALF_UP).doubleValue()
                : 0.0;

        if (remainingRatio >= 0.35) {
            savingsScore = 20;
        } else if (remainingRatio >= 0.20) {
            savingsScore = 15;
        } else if (remainingRatio >= 0.10) {
            savingsScore = 10;
        } else if (remainingRatio >= 0.0) {
            savingsScore = 5;
        } else {
            savingsScore = 0;
        }

        // Compute aggregate score
        int finalScore = Math.min(100, Math.max(0, budgetUtilizationScore + discretionaryScore + categoryDisciplineScore + savingsScore));

        // Determine status and grade
        String status;
        String grade;
        String feedbackMessage;

        if (finalScore >= 85) {
            status = "Excellent — Outstanding financial discipline! 🌟";
            grade = "A+";
            feedbackMessage = "You have exceptional control over your college budget, high savings potential, and balanced spending habits.";
        } else if (finalScore >= 75) {
            status = "Good — you're managing your money well 👍";
            grade = "A";
            feedbackMessage = "Your spending is healthy and well-regulated. Keep an eye on minor weekend splurges to stay in top tier.";
        } else if (finalScore >= 60) {
            status = "Fair — Moderate financial stability ⚖️";
            grade = "B";
            feedbackMessage = "You are currently within safe limits, but your discretionary expenditures and remaining buffer need closer observation.";
        } else if (finalScore >= 45) {
            status = "Needs Attention — High spending velocity ⚠️";
            grade = "C";
            feedbackMessage = "You have consumed a large percentage of your monthly funds. Cut back on non-essential entertainment and shopping.";
        } else {
            status = "Critical — Budget depleted or exceeded 🚨";
            grade = "D";
            feedbackMessage = "Immediate expense freezing required. Re-evaluate core daily expenses and settle outstanding shared debts.";
        }

        // Assemble DTO
        SpendingScoreDTO dto = new SpendingScoreDTO();
        dto.setScore(finalScore);
        dto.setStatus(status);
        dto.setGrade(grade);
        dto.setFeedbackMessage(feedbackMessage);

        dto.setBudgetUtilizationScore(budgetUtilizationScore);
        dto.setDiscretionarySpendingScore(discretionaryScore);
        dto.setCategoryDisciplineScore(categoryDisciplineScore);
        dto.setSavingsRatioScore(savingsScore);

        dto.setTotalBudget(totalBudget);
        dto.setTotalSpent(totalSpent);
        dto.setRemainingAmount(remaining);
        dto.setBudgetUsedPercentage(Math.round(budgetUsedRatio * 10000.0) / 100.0);
        dto.setUnnecessarySpendingRatio(Math.round(unnecessaryRatio * 10000.0) / 100.0);

        List<String> vivaPoints = new ArrayList<>();
        vivaPoints.add(String.format("1. Budget Utilization Factor (35 pts max): Achieved %d pts. Budget used: %.1f%%.", budgetUtilizationScore, budgetUsedRatio * 100));
        vivaPoints.add(String.format("2. Discretionary Spending Factor (25 pts max): Achieved %d pts. Non-essential ratio (Shopping/Fun): %.1f%%.", discretionaryScore, unnecessaryRatio * 100));
        vivaPoints.add(String.format("3. Category Discipline (20 pts max): Achieved %d pts. Breached categories: %d.", categoryDisciplineScore, breachedCategories));
        vivaPoints.add(String.format("4. Retained Savings Buffer (20 pts max): Achieved %d pts. Net remaining buffer: ₹%s.", savingsScore, remaining.toPlainString()));
        dto.setVivaExplanationPoints(vivaPoints);

        List<String> tips = new ArrayList<>();
        if (discretionaryScore < 15) {
            tips.add("Reduce entertainment and online shopping purchases by setting strict weekly caps.");
        }
        if (breachedCategories > 0) {
            tips.add(String.format("Adjust your category budgets for next month to better reflect your actual campus routine."));
        }
        if (remainingRatio < 0.15) {
            tips.add("Aim to save at least 15% (₹" + totalBudget.multiply(BigDecimal.valueOf(0.15)).intValue() + ") of your monthly pocket allowance.");
        }
        if (tips.isEmpty()) {
            tips.add("Great job! Consider transferring your surplus savings to an emergency student fund.");
        }
        dto.setStudentTips(tips);

        return dto;
    }
}
