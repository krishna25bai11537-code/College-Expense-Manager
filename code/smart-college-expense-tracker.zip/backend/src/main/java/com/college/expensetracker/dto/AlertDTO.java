package com.college.expensetracker.dto;

public class AlertDTO {

    private String id;
    private String type; // "BUDGET_PACE", "WEEKLY_SPIKE", "REMAINING_BUDGET", "CATEGORY_EXCEEDED"
    private String severity; // "INFO", "WARNING", "DANGER", "SUCCESS"
    private String title;
    private String message;
    private String icon;

    public AlertDTO() {}

    public AlertDTO(String id, String type, String severity, String title, String message, String icon) {
        this.id = id;
        this.type = type;
        this.severity = severity;
        this.title = title;
        this.message = message;
        this.icon = icon;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getSeverity() { return severity; }
    public void setSeverity(String severity) { this.severity = severity; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getIcon() { return icon; }
    public void setIcon(String icon) { this.icon = icon; }
}
