package com.college.expensetracker.controller;

import com.college.expensetracker.dto.SpendingScoreDTO;
import com.college.expensetracker.security.UserPrincipal;
import com.college.expensetracker.service.SpendingScoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/spending-score")
public class SpendingScoreController {

    @Autowired
    private SpendingScoreService spendingScoreService;

    @GetMapping
    public ResponseEntity<SpendingScoreDTO> getSpendingScore(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(required = false) Integer month,
            @RequestParam(required = false) Integer year
    ) {
        SpendingScoreDTO score = spendingScoreService.calculateScore(currentUser.getId(), month, year);
        return ResponseEntity.ok(score);
    }
}
