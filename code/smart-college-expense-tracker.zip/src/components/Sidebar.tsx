import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Receipt,
  PlusCircle,
  PiggyBank,
  PieChart,
  Users2,
  RefreshCw,
  FileSpreadsheet,
  Gauge,
  BookOpen,
  User,
  X,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  quickScore?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose, quickScore = 82 }) => {
  const { user } = useAuth();

  const navItems = [
    { to: '/', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/expenses', label: 'Expense History', icon: Receipt },
    { to: '/add-expense', label: 'Add Expense', icon: PlusCircle },
    { to: '/budget', label: 'Budget & Limits', icon: PiggyBank },
    { to: '/analytics', label: 'Analytics & Trends', icon: PieChart },
    { to: '/splitter', label: 'Expense Splitter', icon: Users2 },
    { to: '/recurring', label: 'Recurring Bills', icon: RefreshCw },
    { to: '/reports', label: 'Reports & CSV', icon: FileSpreadsheet },
    { to: '/score', label: 'Spending Score', icon: Gauge, badge: `${quickScore}/100` },
    { to: '/docs', label: 'Viva & Architecture', icon: BookOpen },
    { to: '/profile', label: 'Student Profile', icon: User },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-40 lg:hidden animate-in fade-in"
        />
      )}

      {/* Sidebar Drawer */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 w-64 bg-slate-900/95 lg:bg-slate-900/60 lg:backdrop-blur-xl border-r border-slate-800/80 flex flex-col transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Mobile Header Close */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 lg:hidden">
          <div className="flex items-center space-x-2">
            <span className="font-bold text-white text-sm">Smart Expense Tracker</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Student Quick Pill (Top) */}
        <div className="p-4 border-b border-slate-800/60 hidden lg:block">
          <div className="p-3 rounded-2xl bg-gradient-to-br from-indigo-950/50 via-slate-800/40 to-slate-900 border border-indigo-500/20 shadow-inner">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-indigo-400 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-indigo-400" /> Student Score
              </span>
              <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                {quickScore}/100
              </span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 transition-all duration-500"
                style={{ width: `${quickScore}%` }}
              ></div>
            </div>
            <p className="text-[10px] text-slate-400 mt-2 truncate">
              {user?.name || 'Krishna Sharma'} • Year 2
            </p>
          </div>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={onClose}
                end={item.to === '/'}
                className={({ isActive }) =>
                  `flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold tracking-wide transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-indigo-600 to-indigo-700 text-white shadow-md shadow-indigo-600/25'
                      : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/60'
                  }`
                }
              >
                <div className="flex items-center space-x-3">
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-[10px] px-2 py-0.5 rounded-md font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    {item.badge}
                  </span>
                )}
              </NavLink>
            );
          })}
        </nav>

        {/* Architecture & College Viva Footnote */}
        <div className="p-4 border-t border-slate-800/60">
          <div className="p-2.5 rounded-xl bg-slate-800/40 border border-slate-800 text-[11px] text-slate-400">
            <div className="font-semibold text-slate-300 mb-0.5">Spring Boot 3 + MySQL</div>
            <p className="text-[10px] leading-tight text-slate-500">
              Clean 4-tier design with deterministic Viva scoring algorithm.
            </p>
          </div>
        </div>
      </aside>
    </>
  );
};
