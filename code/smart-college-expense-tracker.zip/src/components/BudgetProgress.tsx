import React from 'react';
import { AlertCircle, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { CategoryBudgetDetail } from '../types';

interface BudgetProgressProps {
  detail: CategoryBudgetDetail;
  onEdit?: (detail: CategoryBudgetDetail) => void;
}

export const BudgetProgress: React.FC<BudgetProgressProps> = ({ detail, onEdit }) => {
  const { category, budgetedAmount, spentAmount, remainingAmount, percentageUsed, warningLevel, warningMessage } =
    detail;

  // Determine color theme based on 70%, 90%, 100%+
  let barGradient = 'from-emerald-500 to-teal-400';
  let badgeColor = 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
  let Icon = CheckCircle2;

  if (percentageUsed >= 100) {
    barGradient = 'from-rose-600 to-red-500';
    badgeColor = 'bg-rose-500/20 text-rose-300 border-rose-500/30';
    Icon = AlertCircle;
  } else if (percentageUsed >= 90) {
    barGradient = 'from-orange-500 to-amber-500';
    badgeColor = 'bg-orange-500/20 text-orange-300 border-orange-500/30';
    Icon = AlertTriangle;
  } else if (percentageUsed >= 70) {
    barGradient = 'from-amber-400 to-yellow-400';
    badgeColor = 'bg-amber-500/20 text-amber-300 border-amber-500/30';
    Icon = AlertTriangle;
  }

  const cappedPercentage = Math.min(percentageUsed, 100);

  return (
    <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 transition">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center space-x-2">
          <span className="text-sm font-bold text-white tracking-wide">{category}</span>
          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border flex items-center space-x-1 ${badgeColor}`}>
            <Icon className="w-3 h-3 mr-0.5 inline" />
            <span>{percentageUsed}%</span>
          </span>
        </div>

        {onEdit && (
          <button
            onClick={() => onEdit(detail)}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold"
          >
            Edit Limit
          </button>
        )}
      </div>

      {/* Progress Bar Container */}
      <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden my-2.5">
        <div
          className={`h-full bg-gradient-to-r ${barGradient} transition-all duration-500 rounded-full`}
          style={{ width: `${cappedPercentage}%` }}
        />
      </div>

      {/* Spending Breakdown Numbers */}
      <div className="flex items-center justify-between text-xs text-slate-400 font-mono mt-1">
        <span>Spent: <strong className="text-slate-200">₹{spentAmount.toLocaleString()}</strong></span>
        <span>Limit: <strong className="text-slate-200">₹{budgetedAmount.toLocaleString()}</strong></span>
      </div>

      {/* Dynamic Warning Message if 70% or more */}
      {percentageUsed >= 70 && (
        <div
          className={`mt-3 p-2 rounded-xl text-[11px] font-medium border flex items-start space-x-1.5 ${
            percentageUsed >= 100
              ? 'bg-rose-950/40 border-rose-800/60 text-rose-300'
              : percentageUsed >= 90
              ? 'bg-orange-950/40 border-orange-800/60 text-orange-300'
              : 'bg-amber-950/40 border-amber-800/60 text-amber-300'
          }`}
        >
          <Icon className="w-3.5 h-3.5 shrink-0 mt-0.5" />
          <span>{warningMessage}</span>
        </div>
      )}
    </div>
  );
};
