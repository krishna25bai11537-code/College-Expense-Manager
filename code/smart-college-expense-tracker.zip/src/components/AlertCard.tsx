import React from 'react';
import { AlertCircle, AlertTriangle, TrendingUp, Target, Clock, CheckCircle2 } from 'lucide-react';
import { AlertItem } from '../types';

interface AlertCardProps {
  alert: AlertItem;
  onDismiss?: (id: string) => void;
}

export const AlertCard: React.FC<AlertCardProps> = ({ alert, onDismiss }) => {
  const getIcon = () => {
    switch (alert.icon) {
      case 'trending-up':
        return TrendingUp;
      case 'target':
        return Target;
      case 'clock':
        return Clock;
      case 'alert-triangle':
        return AlertTriangle;
      default:
        return alert.severity === 'DANGER'
          ? AlertCircle
          : alert.severity === 'WARNING'
          ? AlertTriangle
          : CheckCircle2;
    }
  };

  const IconComponent = getIcon();

  const styles = {
    DANGER: {
      bg: 'bg-rose-950/20 border-rose-800/40 text-rose-200',
      iconBg: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
      badge: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
    },
    WARNING: {
      bg: 'bg-amber-950/20 border-amber-800/40 text-amber-200',
      iconBg: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
      badge: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
    },
    SUCCESS: {
      bg: 'bg-emerald-950/20 border-emerald-800/40 text-emerald-200',
      iconBg: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
      badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    },
    INFO: {
      bg: 'bg-indigo-950/20 border-indigo-800/40 text-indigo-200',
      iconBg: 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30',
      badge: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
    },
  }[alert.severity || 'INFO'];

  return (
    <div className={`p-4 rounded-2xl border backdrop-blur-sm transition-all hover:scale-[1.01] ${styles.bg}`}>
      <div className="flex items-start space-x-3.5">
        <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${styles.iconBg}`}>
          <IconComponent className="w-4 h-4" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-1">
            <h4 className="text-xs font-bold text-white tracking-wide truncate">{alert.title}</h4>
            <span className={`px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wider border ${styles.badge}`}>
              {alert.type.replace('_', ' ')}
            </span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">{alert.message}</p>
        </div>
      </div>
    </div>
  );
};
