import React, { useState } from 'react';
import { 
  GraduationCap, 
  PlusCircle, 
  Bell, 
  Server, 
  Check, 
  AlertTriangle, 
  LogOut, 
  User as UserIcon, 
  FileText,
  Menu
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Link, useNavigate } from 'react-router-dom';
import { AlertItem } from '../types';

interface NavbarProps {
  onOpenAddExpense: () => void;
  alerts?: AlertItem[];
  onToggleSidebar?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenAddExpense, alerts = [], onToggleSidebar }) => {
  const { user, logout, backendMode, setMode } = useAuth();
  const [showAlertsMenu, setShowAlertsMenu] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showBackendModal, setShowBackendModal] = useState(false);
  const [customBackendUrl, setCustomBackendUrl] = useState('http://localhost:8080/api');
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="sticky top-0 z-30 bg-slate-900/80 backdrop-blur-md border-b border-slate-800/80 px-4 lg:px-8 py-3 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        
        {/* Left: Mobile Toggle & Title */}
        <div className="flex items-center space-x-3">
          <button
            onClick={onToggleSidebar}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/80 lg:hidden transition"
            aria-label="Toggle menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          <Link to="/" className="flex items-center space-x-2.5 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-violet-500 flex items-center justify-center shadow-lg shadow-indigo-500/25 border border-indigo-400/30 group-hover:scale-105 transition-transform">
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-slate-100 tracking-tight text-base sm:text-lg">
                  Campus<span className="text-indigo-400 font-extrabold">Expense</span>
                </span>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                  Student Edition
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-mono hidden md:block">
                {user?.collegeName || 'VIT Bhopal University'} • {user?.studentId || '25BAI11537'}
              </p>
            </div>
          </Link>
        </div>

        {/* Right Action Bar */}
        <div className="flex items-center space-x-2 sm:space-x-4">
          
          {/* Spring Boot / Simulator Connection Pill */}
          <button
            onClick={() => setShowBackendModal(true)}
            className="flex items-center space-x-2 px-2.5 py-1.5 rounded-xl text-xs font-medium bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 text-slate-300 transition shadow-sm"
            title="Configure Backend Connection (Spring Boot vs Simulator)"
          >
            <Server className={`w-3.5 h-3.5 ${backendMode === 'spring-boot' ? 'text-emerald-400 animate-pulse' : 'text-indigo-400'}`} />
            <span className="hidden md:inline">
              {backendMode === 'spring-boot' ? 'Spring Boot 3 (Port 8080)' : 'Client Simulator (Active)'}
            </span>
            <span className={`w-2 h-2 rounded-full ${backendMode === 'spring-boot' ? 'bg-emerald-400' : 'bg-indigo-400'}`}></span>
          </button>

          {/* Quick Add Expense Button */}
          <button
            id="nav-add-expense-btn"
            onClick={onOpenAddExpense}
            className="flex items-center space-x-1.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold shadow-md shadow-indigo-500/20 active:scale-95 transition"
          >
            <PlusCircle className="w-4 h-4" />
            <span className="hidden xs:inline">Add Expense</span>
          </button>

          {/* Smart Alerts Bell Notification */}
          <div className="relative">
            <button
              onClick={() => {
                setShowAlertsMenu(!showAlertsMenu);
                setShowProfileMenu(false);
              }}
              className="relative p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/80 border border-slate-800 transition"
              aria-label="Smart Alerts"
            >
              <Bell className="w-5 h-5" />
              {alerts.length > 0 && (
                <span className="absolute top-1.5 right-1.5 flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
                </span>
              )}
            </button>

            {showAlertsMenu && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-4 z-50 animate-in fade-in-50 slide-in-from-top-2">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-bold text-white">Smart Spending Alerts</span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                      {alerts.length} Active
                    </span>
                  </div>
                  <button 
                    onClick={() => setShowAlertsMenu(false)}
                    className="text-xs text-slate-400 hover:text-white"
                  >
                    Close
                  </button>
                </div>

                <div className="mt-3 space-y-2.5 max-h-72 overflow-y-auto pr-1">
                  {alerts.length === 0 ? (
                    <p className="text-xs text-slate-400 py-4 text-center">No current spending alerts. All budgets in safe zone!</p>
                  ) : (
                    alerts.map((alert) => (
                      <div
                        key={alert.id}
                        className={`p-3 rounded-xl border text-xs leading-relaxed ${
                          alert.severity === 'DANGER'
                            ? 'bg-rose-950/30 border-rose-800/50 text-rose-200'
                            : alert.severity === 'WARNING'
                            ? 'bg-amber-950/30 border-amber-800/50 text-amber-200'
                            : 'bg-emerald-950/30 border-emerald-800/50 text-emerald-200'
                        }`}
                      >
                        <div className="font-semibold mb-0.5 flex items-center justify-between">
                          <span>{alert.title}</span>
                          <span className="text-[10px] opacity-75 uppercase">{alert.severity}</span>
                        </div>
                        <p className="opacity-90">{alert.message}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* User Profile Dropdown */}
          <div className="relative">
            <button
              onClick={() => {
                setShowProfileMenu(!showProfileMenu);
                setShowAlertsMenu(false);
              }}
              className="flex items-center space-x-2 p-1.5 rounded-xl hover:bg-slate-800/80 border border-transparent hover:border-slate-800 transition"
            >
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center font-bold text-white text-xs shadow">
                {user?.name ? user.name.charAt(0) : 'S'}
              </div>
            </button>

            {showProfileMenu && (
              <div className="absolute right-0 mt-2 w-56 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-2 z-50 animate-in fade-in-50 slide-in-from-top-2">
                <div className="px-3 py-2 border-b border-slate-800/80 mb-1">
                  <p className="text-xs font-bold text-white truncate">{user?.name || 'Krishna Sharma'}</p>
                  <p className="text-[11px] text-slate-400 font-mono truncate">{user?.email || 'student@vitbhopal.ac.in'}</p>
                </div>

                <Link
                  to="/profile"
                  onClick={() => setShowProfileMenu(false)}
                  className="flex items-center space-x-2.5 px-3 py-2 rounded-xl text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 transition"
                >
                  <UserIcon className="w-4 h-4 text-indigo-400" />
                  <span>Student Profile</span>
                </Link>

                <Link
                  to="/docs"
                  onClick={() => setShowProfileMenu(false)}
                  className="flex items-center space-x-2.5 px-3 py-2 rounded-xl text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 transition"
                >
                  <FileText className="w-4 h-4 text-emerald-400" />
                  <span>Viva & Architecture Docs</span>
                </Link>

                <div className="border-t border-slate-800/80 my-1"></div>

                <button
                  onClick={handleLogout}
                  className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-xs font-medium text-rose-400 hover:bg-rose-950/40 hover:text-rose-300 transition"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sign Out</span>
                </button>
              </div>
            )}
          </div>
        </div>

      </div>

      {/* Backend Mode Switcher Modal */}
      {showBackendModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
                <Server className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Full-Stack Backend Configuration</h3>
                <p className="text-xs text-slate-400">Spring Boot REST API or Built-in Simulator</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 mb-4 leading-relaxed">
              This application has a complete <strong>Spring Boot 3 + Spring Data JPA + Spring Security + MySQL</strong> backend in the <code className="bg-slate-800 px-1.5 py-0.5 rounded text-indigo-300">/backend</code> directory.
            </p>

            <div className="space-y-3 mb-5">
              <label
                onClick={() => setMode('mock')}
                className={`flex items-start space-x-3 p-3 rounded-xl border cursor-pointer transition ${
                  backendMode === 'mock'
                    ? 'bg-indigo-950/40 border-indigo-500 text-white'
                    : 'bg-slate-800/40 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <div className="pt-0.5">
                  <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${backendMode === 'mock' ? 'border-indigo-400 bg-indigo-500' : 'border-slate-500'}`}>
                    {backendMode === 'mock' && <Check className="w-2.5 h-2.5 text-white" />}
                  </div>
                </div>
                <div>
                  <div className="text-xs font-semibold">Browser Sandbox Mode (Instant Preview)</div>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Runs client-side simulation replicating the exact same Java scoring algorithms, alerts, and MySQL schemas without needing local MySQL or Maven running.
                  </p>
                </div>
              </label>

              <label
                onClick={() => setMode('spring-boot', customBackendUrl)}
                className={`flex items-start space-x-3 p-3 rounded-xl border cursor-pointer transition ${
                  backendMode === 'spring-boot'
                    ? 'bg-emerald-950/40 border-emerald-500 text-white'
                    : 'bg-slate-800/40 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <div className="pt-0.5">
                  <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${backendMode === 'spring-boot' ? 'border-emerald-400 bg-emerald-500' : 'border-slate-500'}`}>
                    {backendMode === 'spring-boot' && <Check className="w-2.5 h-2.5 text-white" />}
                  </div>
                </div>
                <div>
                  <div className="text-xs font-semibold">Live Spring Boot Backend (Localhost)</div>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Connects directly to your running <code className="text-emerald-400 font-mono">mvn spring-boot:run</code> on port 8080 with JWT security & MySQL.
                  </p>
                </div>
              </label>
            </div>

            {backendMode === 'spring-boot' && (
              <div className="mb-5 p-3 rounded-xl bg-slate-800/60 border border-slate-700/80">
                <label className="block text-[11px] font-semibold text-slate-300 mb-1.5">
                  Spring Boot REST Base URL
                </label>
                <input
                  type="text"
                  value={customBackendUrl}
                  onChange={(e) => setCustomBackendUrl(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500 font-mono"
                  placeholder="http://localhost:8080/api"
                />
              </div>
            )}

            <div className="flex justify-end space-x-2">
              <button
                onClick={() => setShowBackendModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white transition"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
