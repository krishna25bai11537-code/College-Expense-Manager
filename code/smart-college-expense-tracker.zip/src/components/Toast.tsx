import React from 'react';
import { CheckCircle2, AlertTriangle, AlertCircle, Info, X } from 'lucide-react';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  message: string;
}

interface ToastProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const Toast: React.FC<{
  type: 'success' | 'error' | 'warning' | 'info';
  message: string;
  onClose: () => void;
}> = ({ type, message, onClose }) => {
  React.useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 4000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed bottom-5 right-5 z-50 max-w-sm w-full animate-in fade-in slide-in-from-bottom-3">
      <div
        className={`flex items-center justify-between p-3.5 rounded-xl shadow-2xl border backdrop-blur-md transition-all ${
          type === 'success'
            ? 'bg-emerald-950/90 border-emerald-700/60 text-emerald-100'
            : type === 'error'
            ? 'bg-rose-950/90 border-rose-700/60 text-rose-100'
            : type === 'warning'
            ? 'bg-amber-950/90 border-amber-700/60 text-amber-100'
            : 'bg-slate-900/90 border-slate-700/60 text-slate-100'
        }`}
      >
        <div className="flex items-center space-x-3">
          {type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />}
          {type === 'error' && <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />}
          {type === 'warning' && <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />}
          {type === 'info' && <Info className="w-5 h-5 text-sky-400 shrink-0" />}
          <span className="text-xs font-semibold leading-tight">{message}</span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg hover:bg-white/10 text-white/70 hover:text-white transition"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

