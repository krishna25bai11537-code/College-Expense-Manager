import React, { useState } from 'react';
import { X, Users2, IndianRupee, Plus, Trash2, Calendar, Check } from 'lucide-react';

interface SplitModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: {
    title: string;
    totalAmount: number;
    date: string;
    participants: { participantName: string; amountPaid: number }[];
  }) => Promise<void>;
}

export const SplitModal: React.FC<SplitModalProps> = ({ isOpen, onClose, onSave }) => {
  const [title, setTitle] = useState('');
  const [totalAmount, setTotalAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [participants, setParticipants] = useState([
    { name: 'Krishna (You)', amountPaid: '' },
    { name: 'Rahul', amountPaid: '' },
    { name: 'Aman', amountPaid: '' },
    { name: 'Rohan', amountPaid: '' },
  ]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleAddParticipant = () => {
    setParticipants([...participants, { name: '', amountPaid: '0' }]);
  };

  const handleRemoveParticipant = (index: number) => {
    if (participants.length <= 2) {
      setError('At least 2 friends are required to split a bill.');
      return;
    }
    setParticipants(participants.filter((_, i) => i !== index));
  };

  const handleParticipantChange = (index: number, field: 'name' | 'amountPaid', val: string) => {
    const updated = [...participants];
    updated[index] = { ...updated[index], [field]: val };
    setParticipants(updated);
  };

  // Split calculations
  const parsedTotal = parseFloat(totalAmount) || 0;
  const numFriends = participants.length || 1;
  const splitPerPerson = parsedTotal > 0 ? (parsedTotal / numFriends).toFixed(2) : '0.00';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Please provide a title for the split bill.');
      return;
    }
    if (parsedTotal <= 0) {
      setError('Please enter a total bill amount greater than 0.');
      return;
    }
    for (const p of participants) {
      if (!p.name.trim()) {
        setError('All participants must have a name.');
        return;
      }
    }

    // Check sum of paid amounts matches or prompt
    const totalPaidInput = participants.reduce((sum, p) => sum + (parseFloat(p.amountPaid) || 0), 0);
    if (Math.abs(totalPaidInput - parsedTotal) > 1 && totalPaidInput > 0) {
      setError(`Sum of amounts paid (₹${totalPaidInput}) does not equal total bill amount (₹${parsedTotal}).`);
      return;
    }

    setIsSubmitting(true);
    try {
      await onSave({
        title: title.trim(),
        totalAmount: parsedTotal,
        date,
        participants: participants.map((p) => ({
          participantName: p.name.trim(),
          amountPaid: parseFloat(p.amountPaid) || 0,
        })),
      });
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to split expense');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
              <Users2 className="w-4 h-4" />
            </div>
            <h3 className="text-base font-bold text-white">Split Bill Between Friends</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mt-4 p-3 rounded-xl bg-rose-950/40 border border-rose-800 text-rose-300 text-xs font-medium">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-4 space-y-4 text-xs">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Bill Description</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Food bill at Dhaba, Auto share"
                className="w-full bg-slate-800/80 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Total Bill Amount (₹)</label>
              <input
                type="number"
                step="any"
                required
                value={totalAmount}
                onChange={(e) => {
                  setTotalAmount(e.target.value);
                  // By default set Krishna's paid amount to total if empty
                  if (participants.length > 0 && (!participants[0].amountPaid || participants[0].amountPaid === '0')) {
                    const p = [...participants];
                    p[0].amountPaid = e.target.value;
                    setParticipants(p);
                  }
                }}
                placeholder="e.g. 1200"
                className="w-full bg-slate-800/80 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs font-bold focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-indigo-400" />
              <span>Date</span>
            </label>
            <input
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full bg-slate-800/80 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Real-Time Split Card Indicator */}
          <div className="p-3.5 rounded-xl bg-indigo-950/30 border border-indigo-500/20 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-slate-400">Equal share per student</span>
              <div className="text-lg font-extrabold text-white">₹{splitPerPerson}</div>
            </div>
            <span className="text-xs text-indigo-300 font-medium font-mono">
              {participants.length} Friends
            </span>
          </div>

          {/* Friends List */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-slate-300 font-semibold">Friends & Who Paid</label>
              <button
                type="button"
                onClick={handleAddParticipant}
                className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Friend</span>
              </button>
            </div>

            <div className="space-y-2">
              {participants.map((p, idx) => (
                <div key={idx} className="flex items-center space-x-2">
                  <input
                    type="text"
                    required
                    placeholder="Friend's Name"
                    value={p.name}
                    onChange={(e) => handleParticipantChange(idx, 'name', e.target.value)}
                    className="flex-1 bg-slate-800/80 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-indigo-500"
                  />
                  <div className="relative w-32">
                    <input
                      type="number"
                      step="any"
                      placeholder="Paid ₹"
                      value={p.amountPaid}
                      onChange={(e) => handleParticipantChange(idx, 'amountPaid', e.target.value)}
                      className="w-full bg-slate-800/80 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs font-mono focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                  {participants.length > 2 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveParticipant(idx)}
                      className="p-2 text-slate-500 hover:text-rose-400 transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 flex justify-end space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/30 disabled:opacity-50"
            >
              {isSubmitting ? 'Calculating...' : 'Create Split Bill'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
