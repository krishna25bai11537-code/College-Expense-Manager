import React from 'react';
import { LucideIcon } from 'lucide-react';

interface ExpenseCardProps {
  title: string;
  amount: number | string;
  subtitle?: string;
  icon: LucideIcon;
  variant?: 'indigo' | 'emerald' | 'amber' | 'rose' | 'slate';
  trend?: {
    value: number | string;
    isPositive?: boolean;
    label?: string;
  };
}

export const ExpenseCard: React.FC<ExpenseCardProps> = ({
  title,
  amount,
  subtitle,
  icon: Icon,
  variant = 'indigo',
  trend,
}) => {
  const variantStyles = {
    indigo: {
      bg: 'from-indigo-500/10 to-indigo-600/5 border-indigo-500/20 text-indigo-400',
      iconBg: 'bg-indigo-500/20 border-indigo-500/30 text-indigo-300',
    },
    emerald: {
      bg: 'from-emerald-500/10 to-emerald-600/5 border-emerald-500/20 text-emerald-400',
      iconBg: 'bg-emerald-500/20 border-emerald-500/30 text-emerald-300',
    },
    amber: {
      bg: 'from-amber-500/10 to-amber-600/5 border-amber-500/20 text-amber-400',
      iconBg: 'bg-amber-500/20 border-amber-500/30 text-amber-300',
    },
    rose: {
      bg: 'from-rose-500/10 to-rose-600/5 border-rose-500/20 text-rose-400',
      iconBg: 'bg-rose-500/20 border-rose-500/30 text-rose-300',
    },
    slate: {
      bg: 'from-slate-500/10 to-slate-600/5 border-slate-500/20 text-slate-400',
      iconBg: 'bg-slate-500/20 border-slate-500/30 text-slate-300',
    },
  }[variant];

  const formattedAmount =
    typeof amount === 'number'
      ? `₹${amount.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`
      : amount;

  return (
    <div className={`p-5 rounded-2xl bg-gradient-to-br ${variantStyles.bg} border backdrop-blur-md shadow-lg transition-all hover:translate-y-[-2px]`}>
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{title}</span>
        <div className={`w-9 h-9 rounded-xl flex items-center justify-center border ${variantStyles.iconBg}`}>
          <Icon className="w-4 h-4" />
        </div>
      </div>

      <div className="mt-3">
        <div className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          {formattedAmount}
        </div>
        {subtitle && <p className="text-xs text-slate-400 mt-1 font-medium">{subtitle}</p>}
      </div>

      {trend && (
        <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center text-xs space-x-1.5">
          <span
            className={`font-semibold ${
              trend.isPositive ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {trend.value}
          </span>
          {trend.label && <span className="text-slate-400">{trend.label}</span>}
        </div>
      )}
    </div>
  );
};
