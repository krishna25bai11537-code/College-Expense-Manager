import React, { useState } from 'react';
import { Gauge, Sparkles, BookOpen, CheckCircle, Info, ChevronRight, X } from 'lucide-react';
import { SpendingScore } from '../types';

interface SpendingScoreCardProps {
  scoreData: SpendingScore;
}

export const SpendingScoreCard: React.FC<SpendingScoreCardProps> = ({ scoreData }) => {
  const [showVivaModal, setShowVivaModal] = useState(false);
  const {
    score,
    status,
    grade,
    feedbackMessage,
    budgetUtilizationScore,
    discretionarySpendingScore,
    categoryDisciplineScore,
    savingsRatioScore,
    budgetUsedPercentage,
    unnecessarySpendingRatio,
    vivaExplanationPoints,
    studentTips,
  } = scoreData;

  // Meter color logic
  let ringColor = 'text-emerald-500';
  let badgeBg = 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
  if (score < 45) {
    ringColor = 'text-rose-500';
    badgeBg = 'bg-rose-500/20 text-rose-300 border-rose-500/30';
  } else if (score < 60) {
    ringColor = 'text-amber-500';
    badgeBg = 'bg-amber-500/20 text-amber-300 border-amber-500/30';
  } else if (score < 75) {
    ringColor = 'text-sky-500';
    badgeBg = 'bg-sky-500/20 text-sky-300 border-sky-500/30';
  }

  // SVG circular gauge calculation
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <>
      <div className="p-6 rounded-3xl bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-500/20 shadow-xl relative overflow-hidden">
        {/* Subtle Background Accent Glow */}
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-56 h-56 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          
          {/* Left: Circular Gauge Meter */}
          <div className="flex items-center space-x-6">
            <div className="relative w-32 h-32 flex items-center justify-center shrink-0">
              <svg className="w-32 h-32 transform -rotate-90">
                {/* Background Ring */}
                <circle
                  cx="64"
                  cy="64"
                  r={radius}
                  className="text-slate-800"
                  strokeWidth="10"
                  stroke="currentColor"
                  fill="transparent"
                />
                {/* Score Ring */}
                <circle
                  cx="64"
                  cy="64"
                  r={radius}
                  className={`${ringColor} transition-all duration-1000 ease-out`}
                  strokeWidth="10"
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  stroke="currentColor"
                  fill="transparent"
                />
              </svg>

              <div className="absolute flex flex-col items-center justify-center text-center">
                <span className="text-3xl font-black text-white tracking-tight">{score}</span>
                <span className="text-[10px] uppercase font-bold text-slate-400">Score / 100</span>
              </div>
            </div>

            {/* Score Meta */}
            <div>
              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-extrabold border bg-indigo-500/20 text-indigo-300 border-indigo-500/30">
                  Grade {grade}
                </span>
                <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${badgeBg}`}>
                  {score >= 75 ? 'Healthy' : score >= 60 ? 'Moderate' : 'Needs Action'}
                </span>
              </div>

              <h3 className="text-base sm:text-lg font-bold text-white mt-1.5 leading-snug">
                {status}
              </h3>
              <p className="text-xs text-slate-300 mt-1 max-w-md leading-relaxed">
                {feedbackMessage}
              </p>
            </div>
          </div>

          {/* Right: Quick Action Buttons */}
          <div className="flex flex-col sm:flex-row md:flex-col gap-2 shrink-0">
            <button
              onClick={() => setShowVivaModal(true)}
              className="flex items-center justify-center space-x-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md shadow-indigo-600/30 transition active:scale-95"
            >
              <BookOpen className="w-4 h-4" />
              <span>Viva & Formula Breakdown</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 4 Deterministic Pillars Breakdown Bars */}
        <div className="mt-6 pt-5 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-800">
            <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
              <span>1. Budget Velocity</span>
              <span className="text-indigo-400">{budgetUtilizationScore}/35 pts</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-indigo-500 h-full rounded-full"
                style={{ width: `${(budgetUtilizationScore / 35) * 100}%` }}
              />
            </div>
            <span className="text-[10px] text-slate-400 mt-1 block">Used: {budgetUsedPercentage}%</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-800">
            <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
              <span>2. Discretionary Control</span>
              <span className="text-indigo-400">{discretionarySpendingScore}/25 pts</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-emerald-500 h-full rounded-full"
                style={{ width: `${(discretionarySpendingScore / 25) * 100}%` }}
              />
            </div>
            <span className="text-[10px] text-slate-400 mt-1 block">Fun spend: {unnecessarySpendingRatio}%</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-800">
            <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
              <span>3. Category Discipline</span>
              <span className="text-indigo-400">{categoryDisciplineScore}/20 pts</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-amber-500 h-full rounded-full"
                style={{ width: `${(categoryDisciplineScore / 20) * 100}%` }}
              />
            </div>
            <span className="text-[10px] text-slate-400 mt-1 block">Breach deductions</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-800">
            <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
              <span>4. Retained Buffer</span>
              <span className="text-indigo-400">{savingsRatioScore}/20 pts</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-teal-500 h-full rounded-full"
                style={{ width: `${(savingsRatioScore / 20) * 100}%` }}
              />
            </div>
            <span className="text-[10px] text-slate-400 mt-1 block">Pocket savings buffer</span>
          </div>

        </div>
      </div>

      {/* Viva Explanation Modal */}
      {showVivaModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center space-x-2.5">
                <div className="w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
                  <Gauge className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Student Spending Score — Viva Explanation</h3>
                  <p className="text-xs text-slate-400">Pure Mathematical Model in Java (No Black-Box AI)</p>
                </div>
              </div>
              <button
                onClick={() => setShowVivaModal(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Viva Script Body */}
            <div className="mt-4 space-y-4 text-xs text-slate-300 leading-relaxed">
              <div className="p-3.5 rounded-xl bg-indigo-950/30 border border-indigo-500/20">
                <h4 className="font-bold text-indigo-300 mb-1 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" /> Viva Talking Point
                </h4>
                <p>
                  "Examiner Sir/Ma'am: The spending score uses a 4-pillar deterministic formula inside <code className="text-white font-mono bg-indigo-900/50 px-1 py-0.5 rounded">SpendingScoreService.java</code>. It requires zero training data or external API cost, guarantees 100% reproducibility, and evaluates how wisely a student balances survival needs vs discretionary wants."
                </p>
              </div>

              <div>
                <h4 className="font-bold text-white text-sm mb-2">Pillar-by-Pillar Calculations:</h4>
                <div className="space-y-2">
                  {vivaExplanationPoints.map((point, idx) => (
                    <div key={idx} className="p-2.5 rounded-lg bg-slate-800/60 border border-slate-700/60 font-mono text-[11px]">
                      {point}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-bold text-white text-sm mb-2">Automated Student Tips:</h4>
                <ul className="space-y-1.5">
                  {studentTips.map((tip, idx) => (
                    <li key={idx} className="flex items-start space-x-2 text-slate-300">
                      <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setShowVivaModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white transition"
              >
                Close Explanation
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
