import axios from 'axios';
import {
  Expense,
  Budget,
  BudgetOverview,
  SpendingScore,
  AlertItem,
  SharedExpense,
  RecurringExpense,
  AnalyticsData,
  ReportSummary,
  User,
  Category,
  CategoryBudgetDetail,
  SettlementNote,
} from '../types';
import {
  INITIAL_USER,
  INITIAL_BUDGET,
  INITIAL_CATEGORY_BUDGETS,
  INITIAL_EXPENSES,
  INITIAL_SHARED_EXPENSES,
  INITIAL_RECURRING,
} from './mockData';

const STORAGE_KEYS = {
  TOKEN: 'college_expense_jwt_token',
  USER: 'college_expense_user',
  EXPENSES: 'college_expense_list_v1',
  BUDGET: 'college_expense_budget_v1',
  CATEGORY_BUDGETS: 'college_expense_cat_budgets_v1',
  SHARED: 'college_expense_shared_v1',
  RECURRING: 'college_expense_recurring_v1',
  API_URL: 'college_expense_backend_url',
  MODE: 'college_expense_backend_mode', // 'mock' | 'spring-boot'
};

const DEFAULT_SPRING_BOOT_URL = 'http://localhost:8080/api';

// Create Axios Instance
export const apiClient = axios.create({
  baseURL: localStorage.getItem(STORAGE_KEYS.API_URL) || DEFAULT_SPRING_BOOT_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 5000,
});

// Interceptor to inject JWT Bearer token
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem(STORAGE_KEYS.TOKEN);
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Helpers for Local Simulator State
function getLocal<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch {
    return defaultValue;
  }
}

function setLocal<T>(key: string, value: T): void {
  localStorage.setItem(key, JSON.stringify(value));
}

// Ensure initial seed data in browser storage
export function ensureInitialData() {
  if (!localStorage.getItem(STORAGE_KEYS.EXPENSES)) {
    setLocal(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);
  }
  if (!localStorage.getItem(STORAGE_KEYS.BUDGET)) {
    setLocal(STORAGE_KEYS.BUDGET, INITIAL_BUDGET);
  }
  if (!localStorage.getItem(STORAGE_KEYS.CATEGORY_BUDGETS)) {
    setLocal(STORAGE_KEYS.CATEGORY_BUDGETS, INITIAL_CATEGORY_BUDGETS);
  }
  if (!localStorage.getItem(STORAGE_KEYS.SHARED)) {
    setLocal(STORAGE_KEYS.SHARED, INITIAL_SHARED_EXPENSES);
  }
  if (!localStorage.getItem(STORAGE_KEYS.RECURRING)) {
    setLocal(STORAGE_KEYS.RECURRING, INITIAL_RECURRING);
  }
  if (!localStorage.getItem(STORAGE_KEYS.USER)) {
    setLocal(STORAGE_KEYS.USER, INITIAL_USER);
  }
  if (!localStorage.getItem(STORAGE_KEYS.TOKEN)) {
    localStorage.setItem(STORAGE_KEYS.TOKEN, 'demo-jwt-student-token-v1');
  }
}

ensureInitialData();

export function isLiveBackendMode(): boolean {
  return localStorage.getItem(STORAGE_KEYS.MODE) === 'spring-boot';
}

export function setBackendMode(mode: 'mock' | 'spring-boot', customUrl?: string) {
  localStorage.setItem(STORAGE_KEYS.MODE, mode);
  if (customUrl) {
    localStorage.setItem(STORAGE_KEYS.API_URL, customUrl);
    apiClient.defaults.baseURL = customUrl;
  }
}

export function getBackendUrl(): string {
  return localStorage.getItem(STORAGE_KEYS.API_URL) || DEFAULT_SPRING_BOOT_URL;
}

export function resetToDemoData(): void {
  setLocal(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);
  setLocal(STORAGE_KEYS.BUDGET, INITIAL_BUDGET);
  setLocal(STORAGE_KEYS.CATEGORY_BUDGETS, INITIAL_CATEGORY_BUDGETS);
  setLocal(STORAGE_KEYS.SHARED, INITIAL_SHARED_EXPENSES);
  setLocal(STORAGE_KEYS.RECURRING, INITIAL_RECURRING);
  setLocal(STORAGE_KEYS.USER, INITIAL_USER);
  localStorage.setItem(STORAGE_KEYS.TOKEN, 'demo-jwt-student-token-v1');
}

// -------------------------------------------------------------
// Pure Java Algorithm Replicated for Client-side Simulator
// -------------------------------------------------------------

function calculateSimulatorScore(
  expenses: Expense[],
  totalBudget: number,
  catBudgets: Record<string, number>
): SpendingScore {
  const totalSpent = expenses.reduce((sum, e) => sum + Number(e.amount), 0);
  const remaining = totalBudget - totalSpent;
  const budgetUsedRatio = totalBudget > 0 ? totalSpent / totalBudget : 0;

  // 1. Discretionary categories
  const discretionaryCategories = ['Entertainment', 'Shopping', 'Other'];
  const discretionarySpend = expenses
    .filter((e) => discretionaryCategories.includes(e.category))
    .reduce((sum, e) => sum + Number(e.amount), 0);
  const unnecessaryRatio = totalSpent > 0 ? discretionarySpend / totalSpent : 0;

  // Pillar 1: Budget Utilization (Max 35 pts)
  let budgetUtilizationScore = 0;
  if (budgetUsedRatio <= 0.5) {
    budgetUtilizationScore = 35;
  } else if (budgetUsedRatio <= 0.7) {
    budgetUtilizationScore = 30;
  } else if (budgetUsedRatio <= 0.85) {
    budgetUtilizationScore = 22;
  } else if (budgetUsedRatio <= 1.0) {
    budgetUtilizationScore = 12;
  } else {
    budgetUtilizationScore = Math.max(0, Math.round(12 - (budgetUsedRatio - 1.0) * 30));
  }

  // Pillar 2: Discretionary Spending Control (Max 25 pts)
  let discretionaryScore = 0;
  if (unnecessaryRatio <= 0.15) {
    discretionaryScore = 25;
  } else if (unnecessaryRatio <= 0.3) {
    discretionaryScore = 20;
  } else if (unnecessaryRatio <= 0.45) {
    discretionaryScore = 15;
  } else if (unnecessaryRatio <= 0.6) {
    discretionaryScore = 8;
  } else {
    discretionaryScore = 3;
  }

  // Pillar 3: Category Discipline (Max 20 pts)
  let breachedCategories = 0;
  let warningCategories = 0;
  Object.entries(catBudgets).forEach(([cat, budgetAmt]) => {
    const spentInCat = expenses
      .filter((e) => e.category === cat)
      .reduce((sum, e) => sum + Number(e.amount), 0);
    if (spentInCat > budgetAmt) {
      breachedCategories++;
    } else if (budgetAmt > 0 && spentInCat / budgetAmt >= 0.9) {
      warningCategories++;
    }
  });

  let categoryDisciplineScore = 20 - (breachedCategories * 8) - (warningCategories * 3);
  categoryDisciplineScore = Math.max(0, categoryDisciplineScore);

  // Pillar 4: Savings Ratio & Remaining Buffer (Max 20 pts)
  let savingsScore = 0;
  const remainingRatio = totalBudget > 0 ? remaining / totalBudget : 0;
  if (remainingRatio >= 0.35) {
    savingsScore = 20;
  } else if (remainingRatio >= 0.2) {
    savingsScore = 15;
  } else if (remainingRatio >= 0.1) {
    savingsScore = 10;
  } else if (remainingRatio >= 0.0) {
    savingsScore = 5;
  } else {
    savingsScore = 0;
  }

  const finalScore = Math.min(
    100,
    Math.max(0, budgetUtilizationScore + discretionaryScore + categoryDisciplineScore + savingsScore)
  );

  let status = '';
  let grade = '';
  let feedbackMessage = '';

  if (finalScore >= 85) {
    status = 'Excellent — Outstanding financial discipline! 🌟';
    grade = 'A+';
    feedbackMessage = 'You have exceptional control over your college budget, high savings potential, and balanced spending habits.';
  } else if (finalScore >= 75) {
    status = "Good — you're managing your money well 👍";
    grade = 'A';
    feedbackMessage = "Your spending is healthy and well-regulated. Keep an eye on minor weekend splurges to stay in top tier.";
  } else if (finalScore >= 60) {
    status = 'Fair — Moderate financial stability ⚖️';
    grade = 'B';
    feedbackMessage = 'You are currently within safe limits, but your discretionary expenditures and remaining buffer need closer observation.';
  } else if (finalScore >= 45) {
    status = 'Needs Attention — High spending velocity ⚠️';
    grade = 'C';
    feedbackMessage = 'You have consumed a large percentage of your monthly funds. Cut back on non-essential entertainment and shopping.';
  } else {
    status = 'Critical — Budget depleted or exceeded 🚨';
    grade = 'D';
    feedbackMessage = 'Immediate expense freezing required. Re-evaluate core daily expenses and settle outstanding shared debts.';
  }

  const vivaPoints = [
    `1. Budget Utilization Factor (35 pts max): Achieved ${budgetUtilizationScore} pts. Current budget used: ${(budgetUsedRatio * 100).toFixed(1)}%.`,
    `2. Discretionary Spending Factor (25 pts max): Achieved ${discretionaryScore} pts. Non-essential ratio (Shopping/Fun): ${(unnecessaryRatio * 100).toFixed(1)}%.`,
    `3. Category Discipline (20 pts max): Achieved ${categoryDisciplineScore} pts. Breached categories: ${breachedCategories}.`,
    `4. Retained Savings Buffer (20 pts max): Achieved ${savingsScore} pts. Net remaining buffer: ₹${remaining.toFixed(0)}.`,
  ];

  const tips: string[] = [];
  if (discretionaryScore < 15) {
    tips.push('Limit entertainment & shopping to 2 transactions per week to safeguard your primary allowance.');
  }
  if (breachedCategories > 0) {
    tips.push(`Rebalance the ${breachedCategories} breached category budgets next month to prevent month-end stress.`);
  }
  if (remainingRatio < 0.2) {
    tips.push(`Strive to retain at least ₹${(totalBudget * 0.2).toFixed(0)} (20%) as an emergency cushion for unexpected college fees.`);
  }
  if (tips.length === 0) {
    tips.push('Excellent financial health! Consider investing excess funds in skill courses or an emergency fund.');
  }

  return {
    score: finalScore,
    status,
    grade,
    feedbackMessage,
    budgetUtilizationScore,
    discretionarySpendingScore: discretionaryScore,
    categoryDisciplineScore,
    savingsRatioScore: savingsScore,
    totalBudget,
    totalSpent,
    remainingAmount: remaining,
    budgetUsedPercentage: Number((budgetUsedRatio * 100).toFixed(1)),
    unnecessarySpendingRatio: Number((unnecessaryRatio * 100).toFixed(1)),
    vivaExplanationPoints: vivaPoints,
    studentTips: tips,
  };
}

function generateSimulatorAlerts(
  expenses: Expense[],
  totalBudget: number,
  catBudgets: Record<string, number>
): AlertItem[] {
  const alerts: AlertItem[] = [];
  const totalSpent = expenses.reduce((sum, e) => sum + Number(e.amount), 0);
  const remaining = totalBudget - totalSpent;

  // 1. Remaining Budget alert
  if (remaining >= 0) {
    alerts.push({
      id: 'alert-remaining',
      type: 'REMAINING_BUDGET',
      severity: 'SUCCESS',
      title: 'Budget Balance Update',
      message: `🎯 You have ₹${remaining.toLocaleString()} remaining from your monthly budget.`,
      icon: 'target',
    });
  } else {
    alerts.push({
      id: 'alert-overspent',
      type: 'REMAINING_BUDGET',
      severity: 'DANGER',
      title: 'Budget Exceeded',
      message: `🚨 You have exceeded your monthly budget by ₹${Math.abs(remaining).toLocaleString()}!`,
      icon: 'alert-triangle',
    });
  }

  // 2. Weekly velocity
  alerts.push({
    id: 'alert-weekly-spike',
    type: 'WEEKLY_SPIKE',
    severity: 'WARNING',
    title: 'Weekly Pace Spike',
    message: `💡 Your spending this week is 25% higher than last week (₹2,150 vs ₹1,720).`,
    icon: 'trending-up',
  });

  // 3. Category pace alerts
  const foodBudget = catBudgets['Food'] || 3500;
  const foodSpent = expenses
    .filter((e) => e.category === 'Food')
    .reduce((sum, e) => sum + Number(e.amount), 0);
  const foodPct = foodBudget > 0 ? (foodSpent / foodBudget) * 100 : 0;

  if (foodPct >= 40) {
    alerts.push({
      id: 'alert-pace-food',
      type: 'BUDGET_PACE',
      severity: 'WARNING',
      title: 'Food Budget Pace Warning',
      message: `⚠️ You've spent ${foodPct.toFixed(0)}% of your food budget in the first 15 days of the month.`,
      icon: 'clock',
    });
  }

  return alerts;
}

// -------------------------------------------------------------
// EXPORTED API FUNCTIONS (Dual Mode: Live Spring Boot vs Simulator)
// -------------------------------------------------------------

export const authApi = {
  login: async (email: string, _pass: string) => {
    if (isLiveBackendMode()) {
      const res = await apiClient.post('/auth/login', { email, password: _pass });
      localStorage.setItem(STORAGE_KEYS.TOKEN, res.data.token);
      return res.data;
    }
    // Simulator login
    const user: User = {
      id: 1,
      name: email.split('@')[0].toUpperCase(),
      email,
      collegeName: 'VIT Bhopal University',
      studentId: '25BAI11537',
    };
    setLocal(STORAGE_KEYS.USER, user);
    localStorage.setItem(STORAGE_KEYS.TOKEN, 'demo-jwt-student-token-v1');
    return { token: 'demo-jwt-student-token-v1', ...user };
  },

  register: async (name: string, email: string, _pass: string) => {
    if (isLiveBackendMode()) {
      const res = await apiClient.post('/auth/register', { name, email, password: _pass });
      localStorage.setItem(STORAGE_KEYS.TOKEN, res.data.token);
      return res.data;
    }
    const user: User = {
      id: Date.now(),
      name,
      email,
      collegeName: 'VIT Bhopal University',
      studentId: '25BAI' + Math.floor(1000 + Math.random() * 9000),
    };
    setLocal(STORAGE_KEYS.USER, user);
    localStorage.setItem(STORAGE_KEYS.TOKEN, 'demo-jwt-student-token-v1');
    return { token: 'demo-jwt-student-token-v1', ...user };
  },

  getCurrentUser: async (): Promise<User> => {
    if (isLiveBackendMode()) {
      const res = await apiClient.get('/auth/me');
      return res.data;
    }
    return getLocal<User>(STORAGE_KEYS.USER, INITIAL_USER);
  },
};

export const expenseApi = {
  getExpenses: async (params?: {
    category?: string;
    search?: string;
    startDate?: string;
    endDate?: string;
    sortBy?: string;
    sortOrder?: string;
  }): Promise<Expense[]> => {
    if (isLiveBackendMode()) {
      const res = await apiClient.get('/expenses', { params });
      return res.data;
    }

    let items = getLocal<Expense[]>(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);

    if (params?.category && params.category !== 'ALL') {
      items = items.filter((e) => e.category === params.category);
    }
    if (params?.search && params.search.trim() !== '') {
      const q = params.search.toLowerCase();
      items = items.filter(
        (e) =>
          e.description.toLowerCase().includes(q) ||
          e.category.toLowerCase().includes(q) ||
          e.paymentMethod.toLowerCase().includes(q)
      );
    }
    if (params?.startDate) {
      items = items.filter((e) => e.date >= params.startDate!);
    }
    if (params?.endDate) {
      items = items.filter((e) => e.date <= params.endDate!);
    }

    // Sort
    const sortBy = params?.sortBy || 'date';
    const sortOrder = params?.sortOrder || 'desc';

    items.sort((a, b) => {
      if (sortBy === 'amount') {
        return sortOrder === 'asc' ? a.amount - b.amount : b.amount - a.amount;
      }
      return sortOrder === 'asc'
        ? new Date(a.date).getTime() - new Date(b.date).getTime()
        : new Date(b.date).getTime() - new Date(a.date).getTime();
    });

    return items;
  },

  createExpense: async (expense: Omit<Expense, 'id' | 'userId' | 'createdAt'>): Promise<Expense> => {
    if (isLiveBackendMode()) {
      const res = await apiClient.post('/expenses', expense);
      return res.data;
    }

    const items = getLocal<Expense[]>(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);
    const newExpense: Expense = {
      ...expense,
      id: Date.now(),
      userId: 1,
      createdAt: new Date().toISOString(),
    };
    items.unshift(newExpense);
    setLocal(STORAGE_KEYS.EXPENSES, items);
    return newExpense;
  },

  updateExpense: async (id: number, expense: Partial<Expense>): Promise<Expense> => {
    if (isLiveBackendMode()) {
      const res = await apiClient.put(`/expenses/${id}`, expense);
      return res.data;
    }

    const items = getLocal<Expense[]>(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);
    const idx = items.findIndex((e) => e.id === id);
    if (idx !== -1) {
      items[idx] = { ...items[idx], ...expense };
      setLocal(STORAGE_KEYS.EXPENSES, items);
      return items[idx];
    }
    throw new Error('Expense not found');
  },

  deleteExpense: async (id: number): Promise<void> => {
    if (isLiveBackendMode()) {
      await apiClient.delete(`/expenses/${id}`);
      return;
    }

    const items = getLocal<Expense[]>(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);
    const filtered = items.filter((e) => e.id !== id);
    setLocal(STORAGE_KEYS.EXPENSES, filtered);
  },
};

export const budgetApi = {
  getBudgetOverview: async (month?: number, year?: number): Promise<BudgetOverview> => {
    if (isLiveBackendMode()) {
      const res = await apiClient.get('/budget', { params: { month, year } });
      return res.data;
    }

    const budget = getLocal<Budget>(STORAGE_KEYS.BUDGET, INITIAL_BUDGET);
    const catBudgets = getLocal<Record<string, number>>(
      STORAGE_KEYS.CATEGORY_BUDGETS,
      INITIAL_CATEGORY_BUDGETS
    );
    const expenses = getLocal<Expense[]>(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);

    const totalBudget = budget.amount;
    const totalSpent = expenses.reduce((sum, e) => sum + Number(e.amount), 0);
    const remainingBudget = totalBudget - totalSpent;
    const percentageUsed = totalBudget > 0 ? (totalSpent / totalBudget) * 100 : 0;

    let warningLevel: 'SAFE' | 'WARNING' | 'CRITICAL' | 'EXCEEDED' = 'SAFE';
    let warningMessage = 'Budget is on track 👍';

    if (percentageUsed >= 100) {
      warningLevel = 'EXCEEDED';
      warningMessage = '🚨 You have exceeded your budget.';
    } else if (percentageUsed >= 90) {
      warningLevel = 'CRITICAL';
      warningMessage = '⚠️ Your budget is almost exhausted.';
    } else if (percentageUsed >= 70) {
      warningLevel = 'WARNING';
      warningMessage = "You're getting close to your limit.";
    }

    const categoryBudgets: CategoryBudgetDetail[] = Object.entries(catBudgets).map(
      ([cat, budgetedAmount], idx) => {
        const spent = expenses
          .filter((e) => e.category === cat)
          .reduce((sum, e) => sum + Number(e.amount), 0);
        const rem = budgetedAmount - spent;
        const pct = budgetedAmount > 0 ? (spent / budgetedAmount) * 100 : 0;

        let catWarnLevel: 'SAFE' | 'WARNING' | 'CRITICAL' | 'EXCEEDED' = 'SAFE';
        let catWarnMsg = 'Within healthy limits';
        if (pct >= 100) {
          catWarnLevel = 'EXCEEDED';
          catWarnMsg = `🚨 Exceeded ${cat} budget`;
        } else if (pct >= 90) {
          catWarnLevel = 'CRITICAL';
          catWarnMsg = `⚠️ ${cat} budget almost exhausted`;
        } else if (pct >= 70) {
          catWarnLevel = 'WARNING';
          catWarnMsg = `Getting close to limit for ${cat}`;
        }

        return {
          id: idx + 1,
          category: cat as Category,
          budgetedAmount,
          spentAmount: spent,
          remainingAmount: rem,
          percentageUsed: Number(pct.toFixed(1)),
          warningMessage: catWarnMsg,
          warningLevel: catWarnLevel,
        };
      }
    );

    return {
      month: month || 9,
      year: year || 2026,
      totalBudget,
      totalSpent,
      remainingBudget,
      percentageUsed: Number(percentageUsed.toFixed(1)),
      warningMessage,
      warningLevel,
      categoryBudgets,
    };
  },

  setMonthlyBudget: async (amount: number, month = 9, year = 2026): Promise<void> => {
    if (isLiveBackendMode()) {
      await apiClient.post('/budget', { amount, month, year });
      return;
    }
    const b: Budget = { id: 1, userId: 1, amount, month, year };
    setLocal(STORAGE_KEYS.BUDGET, b);
  },

  setCategoryBudget: async (category: string, amount: number, month = 9, year = 2026): Promise<void> => {
    if (isLiveBackendMode()) {
      await apiClient.post('/budget/category', { category, amount, month, year });
      return;
    }
    const catBudgets = getLocal<Record<string, number>>(
      STORAGE_KEYS.CATEGORY_BUDGETS,
      INITIAL_CATEGORY_BUDGETS
    );
    catBudgets[category] = amount;
    setLocal(STORAGE_KEYS.CATEGORY_BUDGETS, catBudgets);
  },
};

export const dashboardApi = {
  getDashboardData: async () => {
    if (isLiveBackendMode()) {
      const res = await apiClient.get('/dashboard');
      return res.data;
    }

    const expenses = getLocal<Expense[]>(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);
    const budget = getLocal<Budget>(STORAGE_KEYS.BUDGET, INITIAL_BUDGET);
    const catBudgets = getLocal<Record<string, number>>(
      STORAGE_KEYS.CATEGORY_BUDGETS,
      INITIAL_CATEGORY_BUDGETS
    );

    const totalSpent = expenses.reduce((sum, e) => sum + Number(e.amount), 0);
    const remaining = budget.amount - totalSpent;
    const percentage = budget.amount > 0 ? (totalSpent / budget.amount) * 100 : 0;

    // Today's expenses (e.g. matching 2026-09-15)
    const today = '2026-09-15';
    const todayExpenses = expenses
      .filter((e) => e.date === today)
      .reduce((sum, e) => sum + Number(e.amount), 0);

    // Highest category
    const catMap: Record<string, number> = {};
    expenses.forEach((e) => {
      catMap[e.category] = (catMap[e.category] || 0) + Number(e.amount);
    });

    let highestCat = 'Food';
    let highestCatAmt = 0;
    Object.entries(catMap).forEach(([cat, amt]) => {
      if (amt > highestCatAmt) {
        highestCat = cat;
        highestCatAmt = amt;
      }
    });

    const recentTransactions = expenses.slice(0, 6);

    const monthlySpendingTrend = [
      { month: 'Apr', amount: 5800 },
      { month: 'May', amount: 6200 },
      { month: 'Jun', amount: 4900 },
      { month: 'Jul', amount: 7100 },
      { month: 'Aug', amount: 6850 },
      { month: 'Sep', amount: totalSpent },
    ];

    const score = calculateSimulatorScore(expenses, budget.amount, catBudgets);
    const alerts = generateSimulatorAlerts(expenses, budget.amount, catBudgets);

    return {
      totalExpensesThisMonth: totalSpent,
      monthlyBudget: budget.amount,
      remainingBudget: remaining,
      budgetPercentageUsed: Number(percentage.toFixed(1)),
      todayExpenses,
      totalTransactionsCount: expenses.length,
      highestSpendingCategory: highestCat,
      highestCategoryAmount: highestCatAmt,
      recentTransactions,
      monthlySpendingTrend,
      recentAlerts: alerts,
      quickSpendingScore: score,
    };
  },
};

export const analyticsApi = {
  getAnalytics: async (month = 9, year = 2026): Promise<AnalyticsData> => {
    if (isLiveBackendMode()) {
      const res = await apiClient.get('/analytics', { params: { month, year } });
      return res.data;
    }

    const expenses = getLocal<Expense[]>(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);
    const budget = getLocal<Budget>(STORAGE_KEYS.BUDGET, INITIAL_BUDGET);

    const totalSpent = expenses.reduce((sum, e) => sum + Number(e.amount), 0);

    const catColors: Record<string, string> = {
      Food: '#f97316',
      Travel: '#3b82f6',
      Education: '#8b5cf6',
      Entertainment: '#ec4899',
      Health: '#10b981',
      Hostel: '#6366f1',
      Shopping: '#f59e0b',
      Bills: '#06b6d4',
      Other: '#64748b',
    };

    const catTotals: Record<string, number> = {};
    expenses.forEach((e) => {
      catTotals[e.category] = (catTotals[e.category] || 0) + Number(e.amount);
    });

    const categoryWiseSpending = Object.entries(catTotals).map(([cat, amt]) => ({
      category: cat,
      amount: amt,
      percentage: totalSpent > 0 ? Number(((amt / totalSpent) * 100).toFixed(1)) : 0,
      color: catColors[cat] || '#94a3b8',
    }));

    categoryWiseSpending.sort((a, b) => b.amount - a.amount);

    const weeklySpending = [
      { weekLabel: 'Wk 1 (1-7)', amount: 1280 },
      { weekLabel: 'Wk 2 (8-14)', amount: 2980 },
      { weekLabel: 'Wk 3 (15-21)', amount: 570 },
      { weekLabel: 'Wk 4 (22-30)', amount: 0 },
    ];

    const monthlySpending = [
      { month: 'Apr', amount: 5800, budget: 10000 },
      { month: 'May', amount: 6200, budget: 10000 },
      { month: 'Jun', amount: 4900, budget: 10000 },
      { month: 'Jul', amount: 7100, budget: 10000 },
      { month: 'Aug', amount: 6850, budget: 10000 },
      { month: 'Sep', amount: totalSpent, budget: budget.amount },
    ];

    return {
      selectedMonth: month,
      selectedYear: year,
      totalSpent,
      totalBudget: budget.amount,
      categoryWiseSpending,
      monthlySpending,
      weeklySpending,
      topCategories: categoryWiseSpending.slice(0, 4),
    };
  },
};

export const scoreApi = {
  getScore: async (month = 9, year = 2026): Promise<SpendingScore> => {
    if (isLiveBackendMode()) {
      const res = await apiClient.get('/spending-score', { params: { month, year } });
      return res.data;
    }

    const expenses = getLocal<Expense[]>(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);
    const budget = getLocal<Budget>(STORAGE_KEYS.BUDGET, INITIAL_BUDGET);
    const catBudgets = getLocal<Record<string, number>>(
      STORAGE_KEYS.CATEGORY_BUDGETS,
      INITIAL_CATEGORY_BUDGETS
    );

    return calculateSimulatorScore(expenses, budget.amount, catBudgets);
  },
};

export const alertsApi = {
  getAlerts: async (): Promise<AlertItem[]> => {
    if (isLiveBackendMode()) {
      const res = await apiClient.get('/alerts');
      return res.data;
    }

    const expenses = getLocal<Expense[]>(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);
    const budget = getLocal<Budget>(STORAGE_KEYS.BUDGET, INITIAL_BUDGET);
    const catBudgets = getLocal<Record<string, number>>(
      STORAGE_KEYS.CATEGORY_BUDGETS,
      INITIAL_CATEGORY_BUDGETS
    );

    return generateSimulatorAlerts(expenses, budget.amount, catBudgets);
  },
};

export const sharedExpenseApi = {
  getSharedExpenses: async (): Promise<SharedExpense[]> => {
    if (isLiveBackendMode()) {
      const res = await apiClient.get('/shared-expenses');
      return res.data;
    }
    return getLocal<SharedExpense[]>(STORAGE_KEYS.SHARED, INITIAL_SHARED_EXPENSES);
  },

  createSharedExpense: async (data: {
    title: string;
    totalAmount: number;
    date: string;
    participants: { participantName: string; amountPaid: number }[];
  }): Promise<SharedExpense> => {
    if (isLiveBackendMode()) {
      const res = await apiClient.post('/shared-expenses', data);
      return res.data;
    }

    const list = getLocal<SharedExpense[]>(STORAGE_KEYS.SHARED, INITIAL_SHARED_EXPENSES);
    const num = data.participants.length || 1;
    const split = Math.round((data.totalAmount / num) * 100) / 100;

    const participants = data.participants.map((p, idx) => ({
      id: Date.now() + idx,
      participantName: p.participantName,
      amountPaid: p.amountPaid,
      amountOwed: split,
      netBalance: p.amountPaid - split,
    }));

    // Settle notes
    const settlements: SettlementNote[] = [];
    const debtors = participants.filter((p) => p.netBalance < 0).map((d) => ({ ...d }));
    const creditors = participants.filter((p) => p.netBalance > 0).map((c) => ({ ...c }));

    let d = 0;
    let c = 0;
    while (d < debtors.length && c < creditors.length) {
      const debtorAmt = Math.abs(debtors[d].netBalance);
      const credAmt = creditors[c].netBalance;
      const settle = Math.min(debtorAmt, credAmt);

      settlements.push({
        fromPerson: debtors[d].participantName,
        toPerson: creditors[c].participantName,
        amount: settle,
        displayText: `${debtors[d].participantName} owes ${creditors[c].participantName} ₹${settle.toFixed(0)}`,
      });

      debtors[d].netBalance += settle;
      creditors[c].netBalance -= settle;

      if (Math.abs(debtors[d].netBalance) < 0.01) d++;
      if (Math.abs(creditors[c].netBalance) < 0.01) c++;
    }

    const newShared: SharedExpense = {
      id: Date.now(),
      userId: 1,
      title: data.title,
      totalAmount: data.totalAmount,
      splitPerPerson: split,
      date: data.date,
      participants,
      settlements,
    };

    list.unshift(newShared);
    setLocal(STORAGE_KEYS.SHARED, list);
    return newShared;
  },

  deleteSharedExpense: async (id: number): Promise<void> => {
    if (isLiveBackendMode()) {
      await apiClient.delete(`/shared-expenses/${id}`);
      return;
    }
    const list = getLocal<SharedExpense[]>(STORAGE_KEYS.SHARED, INITIAL_SHARED_EXPENSES);
    const filtered = list.filter((s) => s.id !== id);
    setLocal(STORAGE_KEYS.SHARED, filtered);
  },
};

export const recurringApi = {
  getRecurringExpenses: async (): Promise<RecurringExpense[]> => {
    if (isLiveBackendMode()) {
      const res = await apiClient.get('/recurring-expenses');
      return res.data;
    }
    return getLocal<RecurringExpense[]>(STORAGE_KEYS.RECURRING, INITIAL_RECURRING);
  },

  createRecurringExpense: async (
    data: Omit<RecurringExpense, 'id' | 'userId' | 'nextDueDate' | 'active'>
  ): Promise<RecurringExpense> => {
    if (isLiveBackendMode()) {
      const res = await apiClient.post('/recurring-expenses', data);
      return res.data;
    }

    const list = getLocal<RecurringExpense[]>(STORAGE_KEYS.RECURRING, INITIAL_RECURRING);
    const newRec: RecurringExpense = {
      ...data,
      id: Date.now(),
      userId: 1,
      active: true,
      nextDueDate: '2026-10-01',
    };
    list.unshift(newRec);
    setLocal(STORAGE_KEYS.RECURRING, list);
    return newRec;
  },

  deleteRecurringExpense: async (id: number): Promise<void> => {
    if (isLiveBackendMode()) {
      await apiClient.delete(`/recurring-expenses/${id}`);
      return;
    }
    const list = getLocal<RecurringExpense[]>(STORAGE_KEYS.RECURRING, INITIAL_RECURRING);
    const filtered = list.filter((r) => r.id !== id);
    setLocal(STORAGE_KEYS.RECURRING, filtered);
  },
};

export const reportsApi = {
  getReportSummary: async (month = 9, year = 2026): Promise<ReportSummary> => {
    if (isLiveBackendMode()) {
      const res = await apiClient.get('/reports', { params: { month, year } });
      return res.data;
    }

    const expenses = getLocal<Expense[]>(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);
    const budgetOverview = await budgetApi.getBudgetOverview(month, year);
    const analytics = await analyticsApi.getAnalytics(month, year);

    const totalBudget = budgetOverview.totalBudget;
    const totalSpent = budgetOverview.totalSpent;
    const netSavings = totalBudget - totalSpent;
    const avgDaily = totalSpent / 30;

    return {
      month,
      year,
      totalBudget,
      totalSpent,
      netSavings,
      budgetUtilizationPercentage: budgetOverview.percentageUsed,
      totalTransactions: expenses.length,
      averageExpensePerDay: Number(avgDaily.toFixed(1)),
      categorySummary: analytics.categoryWiseSpending,
      budgetReport: budgetOverview.categoryBudgets,
      expenseItems: expenses,
    };
  },

  downloadCsv: async (month = 9, year = 2026): Promise<void> => {
    if (isLiveBackendMode()) {
      const response = await apiClient.get('/reports/export', {
        params: { month, year },
        responseType: 'blob',
      });
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `college_expenses_${year}_${month}.csv`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      return;
    }

    // Client-side CSV generator for simulator preview
    const expenses = getLocal<Expense[]>(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);
    let csvContent = 'Transaction ID,Date,Category,Amount (INR),Payment Method,Description\n';
    expenses.forEach((e) => {
      const escapedDesc = `"${(e.description || '').replace(/"/g, '""')}"`;
      csvContent += `${e.id},${e.date},${e.category},${e.amount},${e.paymentMethod},${escapedDesc}\n`;
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `college_expenses_${year}_${month}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  },
};
