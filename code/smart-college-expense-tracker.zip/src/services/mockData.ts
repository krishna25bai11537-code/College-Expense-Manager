import { Expense, Budget, CategoryBudgetDetail, SharedExpense, RecurringExpense, User } from '../types';

export const INITIAL_USER: User = {
  id: 1,
  name: 'Krishna Sharma',
  email: 'krishna.25bai11537@vitbhopal.ac.in',
  collegeName: 'VIT Bhopal University',
  studentId: '25BAI11537',
};

export const INITIAL_BUDGET: Budget = {
  id: 1,
  userId: 1,
  month: 9,
  year: 2026,
  amount: 10000,
};

export const INITIAL_CATEGORY_BUDGETS: Record<string, number> = {
  Food: 3500,
  Travel: 1500,
  Education: 1500,
  Entertainment: 1000,
  Hostel: 1500,
  Bills: 1000,
  Shopping: 1000,
  Health: 800,
  Other: 500,
};

export const INITIAL_EXPENSES: Expense[] = [
  {
    id: 1,
    userId: 1,
    amount: 180,
    category: 'Food',
    paymentMethod: 'UPI',
    description: 'Campus Canteen Lunch & Chai',
    date: '2026-09-02',
    createdAt: '2026-09-02T13:30:00Z',
  },
  {
    id: 2,
    userId: 1,
    amount: 450,
    category: 'Education',
    paymentMethod: 'Debit Card',
    description: 'Data Structures & Algorithms Reference Book',
    date: '2026-09-04',
    createdAt: '2026-09-04T16:20:00Z',
  },
  {
    id: 3,
    userId: 1,
    amount: 120,
    category: 'Travel',
    paymentMethod: 'UPI',
    description: 'Auto fare to Metro Station',
    date: '2026-09-05',
    createdAt: '2026-09-05T09:15:00Z',
  },
  {
    id: 4,
    userId: 1,
    amount: 650,
    category: 'Food',
    paymentMethod: 'UPI',
    description: 'Hostel Mess weekend dinner with roommates',
    date: '2026-09-07',
    createdAt: '2026-09-07T20:45:00Z',
  },
  {
    id: 5,
    userId: 1,
    amount: 199,
    category: 'Entertainment',
    paymentMethod: 'Debit Card',
    description: 'Netflix Student Subscription',
    date: '2026-09-08',
    createdAt: '2026-09-08T11:00:00Z',
  },
  {
    id: 6,
    userId: 1,
    amount: 350,
    category: 'Shopping',
    paymentMethod: 'UPI',
    description: 'Lab Notebooks & Engineering Stationery',
    date: '2026-09-09',
    createdAt: '2026-09-09T17:30:00Z',
  },
  {
    id: 7,
    userId: 1,
    amount: 1200,
    category: 'Hostel',
    paymentMethod: 'UPI',
    description: 'Monthly Laundry & Maintenance Fee',
    date: '2026-09-10',
    createdAt: '2026-09-10T10:00:00Z',
  },
  {
    id: 8,
    userId: 1,
    amount: 280,
    category: 'Food',
    paymentMethod: 'Cash',
    description: 'Evening Maggi & snacks at Nescafe corner',
    date: '2026-09-11',
    createdAt: '2026-09-11T19:20:00Z',
  },
  {
    id: 9,
    userId: 1,
    amount: 550,
    category: 'Health',
    paymentMethod: 'UPI',
    description: 'Gym supplements & multivitamins',
    date: '2026-09-12',
    createdAt: '2026-09-12T18:10:00Z',
  },
  {
    id: 10,
    userId: 1,
    amount: 80,
    category: 'Travel',
    paymentMethod: 'UPI',
    description: 'College shuttle bus pass ticket',
    date: '2026-09-13',
    createdAt: '2026-09-13T08:30:00Z',
  },
  {
    id: 11,
    userId: 1,
    amount: 420,
    category: 'Food',
    paymentMethod: 'UPI',
    description: 'Pizza treat after mid-term exams',
    date: '2026-09-14',
    createdAt: '2026-09-14T21:00:00Z',
  },
  {
    id: 12,
    userId: 1,
    amount: 150,
    category: 'Bills',
    paymentMethod: 'UPI',
    description: 'Mobile recharge 28-day student plan',
    date: '2026-09-15',
    createdAt: '2026-09-15T09:00:00Z',
  }
];

export const INITIAL_SHARED_EXPENSES: SharedExpense[] = [
  {
    id: 1,
    userId: 1,
    title: 'College Dhaba Dinner',
    totalAmount: 1200,
    splitPerPerson: 300,
    date: '2026-09-10',
    participants: [
      { id: 1, participantName: 'Krishna (You)', amountPaid: 1200, amountOwed: 300, netBalance: 900 },
      { id: 2, participantName: 'Rahul', amountPaid: 0, amountOwed: 300, netBalance: -300 },
      { id: 3, participantName: 'Aman', amountPaid: 0, amountOwed: 300, netBalance: -300 },
      { id: 4, participantName: 'Rohan', amountPaid: 0, amountOwed: 300, netBalance: -300 },
    ],
    settlements: [
      { fromPerson: 'Rahul', toPerson: 'Krishna', amount: 300, displayText: 'Rahul owes Krishna ₹300.00' },
      { fromPerson: 'Aman', toPerson: 'Krishna', amount: 300, displayText: 'Aman owes Krishna ₹300.00' },
      { fromPerson: 'Rohan', toPerson: 'Krishna', amount: 300, displayText: 'Rohan owes Krishna ₹300.00' },
    ]
  },
  {
    id: 2,
    userId: 1,
    title: 'Weekend Project Hardware Kit',
    totalAmount: 800,
    splitPerPerson: 400,
    date: '2026-09-08',
    participants: [
      { id: 5, participantName: 'Rahul', amountPaid: 800, amountOwed: 400, netBalance: 400 },
      { id: 6, participantName: 'Krishna (You)', amountPaid: 0, amountOwed: 400, netBalance: -400 },
    ],
    settlements: [
      { fromPerson: 'Krishna', toPerson: 'Rahul', amount: 400, displayText: 'Krishna owes Rahul ₹400.00' },
    ]
  }
];

export const INITIAL_RECURRING: RecurringExpense[] = [
  {
    id: 1,
    userId: 1,
    name: 'Hostel Gym Membership',
    amount: 800,
    category: 'Health',
    frequency: 'MONTHLY',
    startDate: '2026-08-01',
    endDate: '2027-05-31',
    nextDueDate: '2026-10-01',
    active: true,
  },
  {
    id: 2,
    userId: 1,
    name: 'Spotify Student Pack',
    amount: 59,
    category: 'Entertainment',
    frequency: 'MONTHLY',
    startDate: '2026-07-01',
    endDate: null,
    nextDueDate: '2026-10-01',
    active: true,
  },
  {
    id: 3,
    userId: 1,
    name: 'Hostel WiFi Contribution',
    amount: 300,
    category: 'Bills',
    frequency: 'MONTHLY',
    startDate: '2026-08-01',
    endDate: null,
    nextDueDate: '2026-10-01',
    active: true,
  }
];
