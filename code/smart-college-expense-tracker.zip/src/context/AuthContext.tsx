import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import { authApi, isLiveBackendMode, setBackendMode as setApiBackendMode, getBackendUrl } from '../services/api';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, pass: string) => Promise<void>;
  register: (name: string, email: string, pass: string) => Promise<void>;
  logout: () => void;
  switchDemoUser: (name: string, email: string) => void;
  backendMode: 'mock' | 'spring-boot';
  setMode: (mode: 'mock' | 'spring-boot', url?: string) => void;
  backendUrl: string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('college_expense_jwt_token'));
  const [isLoading, setIsLoading] = useState(true);
  const [backendMode, setBackendModeState] = useState<'mock' | 'spring-boot'>(
    isLiveBackendMode() ? 'spring-boot' : 'mock'
  );
  const [backendUrl, setBackendUrlState] = useState(getBackendUrl());

  useEffect(() => {
    async function initUser() {
      try {
        const u = await authApi.getCurrentUser();
        setUser(u);
      } catch (err) {
        console.warn('Failed to load active user session:', err);
      } finally {
        setIsLoading(false);
      }
    }
    initUser();
  }, []);

  const login = async (email: string, pass: string) => {
    setIsLoading(true);
    try {
      const res = await authApi.login(email, pass);
      setUser({
        id: res.id,
        name: res.name,
        email: res.email,
        collegeName: 'VIT Bhopal University',
        studentId: '25BAI11537',
      });
      setToken(res.token);
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (name: string, email: string, pass: string) => {
    setIsLoading(true);
    try {
      const res = await authApi.register(name, email, pass);
      setUser({
        id: res.id,
        name: res.name,
        email: res.email,
        collegeName: 'VIT Bhopal University',
        studentId: '25BAI' + Math.floor(1000 + Math.random() * 9000),
      });
      setToken(res.token);
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem('college_expense_jwt_token');
    setToken(null);
    setUser(null);
  };

  const switchDemoUser = (name: string, email: string) => {
    const newUser: User = {
      id: Math.floor(Math.random() * 1000) + 1,
      name,
      email,
      collegeName: 'VIT Bhopal University',
      studentId: '25BAI' + Math.floor(1000 + Math.random() * 9000),
    };
    setUser(newUser);
    localStorage.setItem('college_expense_user', JSON.stringify(newUser));
  };

  const setMode = (mode: 'mock' | 'spring-boot', url?: string) => {
    setApiBackendMode(mode, url);
    setBackendModeState(mode);
    if (url) setBackendUrlState(url);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!user,
        isLoading,
        login,
        register,
        logout,
        switchDemoUser,
        backendMode,
        setMode,
        backendUrl,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
