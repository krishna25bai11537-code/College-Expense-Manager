export type Category = 
  | 'Food'
  | 'Travel'
  | 'Shopping'
  | 'Education'
  | 'Entertainment'
  | 'Health'
  | 'Hostel'
  | 'Bills'
  | 'Other';

export type PaymentMethod = 
  | 'Cash'
  | 'UPI'
  | 'Debit Card'
  | 'Credit Card'
  | 'Other';

export type Frequency = 'MONTHLY' | 'WEEKLY';

export interface User {
  id: number;
  name: string;
  email: string;
  collegeName?: string;
  studentId?: string;
}

export interface Expense {
  id: number;
  userId: number;
  amount: number;
  category: Category;
  paymentMethod: PaymentMethod;
  description: string;
  date: string; // YYYY-MM-DD
  createdAt?: string;
}

export interface Budget {
  id?: number;
  userId: number;
  month: number;
  year: number;
  amount: number;
}

export interface CategoryBudgetDetail {
  id?: number;
  category: Category;
  budgetedAmount: number;
  spentAmount: number;
  remainingAmount: number;
  percentageUsed: number;
  warningMessage: string;
  warningLevel: 'SAFE' | 'WARNING' | 'CRITICAL' | 'EXCEEDED';
}

export interface BudgetOverview {
  month: number;
  year: number;
  totalBudget: number;
  totalSpent: number;
  remainingBudget: number;
  percentageUsed: number;
  warningMessage: string;
  warningLevel: 'SAFE' | 'WARNING' | 'CRITICAL' | 'EXCEEDED';
  categoryBudgets: CategoryBudgetDetail[];
}

export interface SpendingScore {
  score: number; // 0 - 100
  status: string;
  feedbackMessage: string;
  grade: string;
  budgetUtilizationScore: number;
  discretionarySpendingScore: number;
  categoryDisciplineScore: number;
  savingsRatioScore: number;
  totalBudget: number;
  totalSpent: number;
  remainingAmount: number;
  budgetUsedPercentage: number;
  unnecessarySpendingRatio: number;
  vivaExplanationPoints: string[];
  studentTips: string[];
}

export interface AlertItem {
  id: string;
  type: 'BUDGET_PACE' | 'WEEKLY_SPIKE' | 'REMAINING_BUDGET' | 'CATEGORY_EXCEEDED';
  severity: 'INFO' | 'WARNING' | 'DANGER' | 'SUCCESS';
  title: string;
  message: string;
  icon: string;
}

export interface SharedExpenseParticipant {
  id?: number;
  participantName: string;
  amountPaid: number;
  amountOwed: number;
  netBalance?: number;
}

export interface SettlementNote {
  fromPerson: string;
  toPerson: string;
  amount: number;
  displayText: string;
}

export interface SharedExpense {
  id: number;
  userId: number;
  title: string;
  totalAmount: number;
  splitPerPerson?: number;
  date: string;
  participants: SharedExpenseParticipant[];
  settlements?: SettlementNote[];
}

export interface RecurringExpense {
  id: number;
  userId: number;
  name: string;
  amount: number;
  category: Category;
  frequency: Frequency;
  startDate: string;
  endDate?: string | null;
  nextDueDate?: string;
  active?: boolean;
}

export interface CategorySlice {
  category: string;
  amount: number;
  percentage: number;
  color: string;
}

export interface WeeklyDataPoint {
  weekLabel: string;
  amount: number;
}

export interface MonthlyDataPoint {
  month: string;
  amount: number;
  budget: number;
}

export interface AnalyticsData {
  selectedMonth: number;
  selectedYear: number;
  totalSpent: number;
  totalBudget: number;
  categoryWiseSpending: CategorySlice[];
  monthlySpending: MonthlyDataPoint[];
  weeklySpending: WeeklyDataPoint[];
  topCategories: CategorySlice[];
}

export interface ReportSummary {
  month: number;
  year: number;
  totalBudget: number;
  totalSpent: number;
  netSavings: number;
  budgetUtilizationPercentage: number;
  totalTransactions: number;
  averageExpensePerDay: number;
  categorySummary: CategorySlice[];
  budgetReport: CategoryBudgetDetail[];
  expenseItems: Expense[];
}
