import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { Toast } from './components/Toast';
import { ExpenseModal } from './components/ExpenseModal';

// Pages
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { DashboardPage } from './pages/DashboardPage';
import { ExpensesPage } from './pages/ExpensesPage';
import { AddExpensePage } from './pages/AddExpensePage';
import { BudgetPage } from './pages/BudgetPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { ExpenseSplitterPage } from './pages/ExpenseSplitterPage';
import { RecurringExpensesPage } from './pages/RecurringExpensesPage';
import { ReportsPage } from './pages/ReportsPage';
import { SpendingScorePage } from './pages/SpendingScorePage';
import { DocsPage } from './pages/DocsPage';
import { ProfilePage } from './pages/ProfilePage';
import { expenseApi } from './services/api';
import { Expense } from './types';

// Protected Route Wrapper
const ProtectedLayout: React.FC<{
  onNotify: (type: 'success' | 'error' | 'warning' | 'info', message: string) => void;
}> = ({ onNotify }) => {
  const { isAuthenticated, loading } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-white text-sm">
        Initializing Student Session...
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  const handleQuickAddExpense = async (
    data: Omit<Expense, 'id' | 'userId' | 'createdAt'>
  ) => {
    try {
      await expenseApi.createExpense(data);
      onNotify('success', `Added ₹${data.amount} for ${data.category}!`);
      // Reload current route components if needed
      window.dispatchEvent(new Event('expense-updated'));
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to add expense');
      throw err;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-indigo-500 selection:text-white">
      {/* Top Navigation */}
      <Navbar
        onToggleSidebar={() => setSidebarOpen((prev) => !prev)}
        onOpenAddExpense={() => setIsQuickAddOpen(true)}
      />

      {/* Main Body Area */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto px-3 sm:px-6 py-6 gap-6">
        
        {/* Sidebar */}
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

        {/* Content Viewport */}
        <main className="flex-1 min-w-0">
          <Routes>
            <Route path="/" element={<DashboardPage onNotify={onNotify} />} />
            <Route path="/expenses" element={<ExpensesPage onNotify={onNotify} />} />
            <Route path="/add-expense" element={<AddExpensePage onNotify={onNotify} />} />
            <Route path="/budget" element={<BudgetPage onNotify={onNotify} />} />
            <Route path="/analytics" element={<AnalyticsPage />} />
            <Route path="/splitter" element={<ExpenseSplitterPage onNotify={onNotify} />} />
            <Route path="/recurring" element={<RecurringExpensesPage onNotify={onNotify} />} />
            <Route path="/reports" element={<ReportsPage onNotify={onNotify} />} />
            <Route path="/score" element={<SpendingScorePage />} />
            <Route path="/docs" element={<DocsPage />} />
            <Route path="/profile" element={<ProfilePage onNotify={onNotify} />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>

      {/* Global Quick Add Expense Modal */}
      <ExpenseModal
        isOpen={isQuickAddOpen}
        onClose={() => setIsQuickAddOpen(false)}
        onSave={handleQuickAddExpense}
      />
    </div>
  );
};

export default function App() {
  const [toast, setToast] = useState<{
    id: string;
    type: 'success' | 'error' | 'warning' | 'info';
    message: string;
  } | null>(null);

  const showToast = (type: 'success' | 'error' | 'warning' | 'info', message: string) => {
    setToast({
      id: Date.now().toString(),
      type,
      message,
    });
  };

  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* Public Auth Routes */}
          <Route path="/login" element={<LoginPage onNotify={showToast} />} />
          <Route path="/register" element={<RegisterPage onNotify={showToast} />} />

          {/* Protected Application Routes */}
          <Route path="/*" element={<ProtectedLayout onNotify={showToast} />} />
        </Routes>

        {/* Toast Notifications */}
        {toast && (
          <Toast
            key={toast.id}
            type={toast.type}
            message={toast.message}
            onClose={() => setToast(null)}
          />
        )}
      </BrowserRouter>
    </AuthProvider>
  );
}
