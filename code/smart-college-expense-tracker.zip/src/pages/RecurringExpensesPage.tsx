import React, { useState, useEffect } from 'react';
import {
  RefreshCw,
  Plus,
  Calendar,
  Tag,
  Trash2,
  Clock,
  CheckCircle2,
  AlertCircle,
  IndianRupee,
} from 'lucide-react';
import { recurringApi } from '../services/api';
import { RecurringExpense } from '../types';
import { RecurringModal } from '../components/RecurringModal';
import { LoadingSpinner } from '../components/LoadingSpinner';

interface RecurringExpensesPageProps {
  onNotify?: (type: 'success' | 'error' | 'warning' | 'info', message: string) => void;
}

export const RecurringExpensesPage: React.FC<RecurringExpensesPageProps> = ({ onNotify }) => {
  const [recurringList, setRecurringList] = useState<RecurringExpense[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const fetchRecurring = async () => {
    try {
      setLoading(true);
      const data = await recurringApi.getRecurringExpenses();
      setRecurringList(data);
    } catch {
      onNotify?.('error', 'Failed to fetch recurring expenses');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRecurring();
  }, []);

  const handleCreateRecurring = async (
    data: Omit<RecurringExpense, 'id' | 'userId' | 'nextDueDate' | 'active'>
  ) => {
    try {
      await recurringApi.createRecurringExpense(data);
      onNotify?.('success', `Added subscription: ${data.name}`);
      await fetchRecurring();
    } catch (err: any) {
      onNotify?.('error', err?.message || 'Failed to create subscription');
      throw err;
    }
  };

  const handleDelete = async (id: number) => {
    if (window.confirm('Delete this recurring subscription?')) {
      try {
        await recurringApi.deleteRecurringExpense(id);
        onNotify?.('success', 'Subscription removed');
        await fetchRecurring();
      } catch {
        onNotify?.('error', 'Failed to remove subscription');
      }
    }
  };

  if (loading) {
    return <LoadingSpinner message="Tracking student subscriptions & bills..." size="lg" />;
  }

  const totalMonthlyCommitment = recurringList.reduce((sum, r) => {
    const factor = r.frequency === 'WEEKLY' ? 4 : 1;
    return sum + Number(r.amount) * factor;
  }, 0);

  return (
    <div className="space-y-6 pb-12 animate-in fade-in">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Recurring Subscriptions & Fees
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              Auto-Calculated Dues
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Keep track of gym memberships, Netflix, hostel WiFi, and regular mess fees before due dates.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center space-x-2 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/25 active:scale-95 transition"
        >
          <Plus className="w-4 h-4" />
          <span>Add Subscription</span>
        </button>
      </div>

      {/* Monthly Commitment Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-500/20 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
            Total Monthly Fixed Commitments
          </span>
          <div className="flex items-center space-x-3 mt-1">
            <span className="text-3xl sm:text-4xl font-black text-white font-mono tracking-tight">
              ₹{totalMonthlyCommitment.toLocaleString()}
            </span>
            <span className="text-xs text-slate-400">
              Reserved automatically from your monthly allowance
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <div className="p-3 rounded-2xl bg-slate-800/60 border border-slate-700/60 text-xs font-mono">
            <span className="text-slate-400 block mb-0.5">Active Subscriptions</span>
            <strong className="text-white text-base font-bold">{recurringList.length} Active</strong>
          </div>
        </div>
      </div>

      {/* Recurring Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {recurringList.map((item) => (
          <div
            key={item.id}
            className="p-5 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-xl hover:border-slate-700 transition flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2.5">
                  <div className="w-9 h-9 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center border border-indigo-500/20">
                    <RefreshCw className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white tracking-tight">{item.name}</h3>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                      {item.category}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => handleDelete(item.id)}
                  className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition"
                  title="Remove Subscription"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              <div className="mt-4">
                <div className="text-2xl font-black text-white font-mono">
                  ₹{item.amount.toLocaleString()}
                  <span className="text-xs text-slate-400 font-normal font-sans ml-1">
                    / {item.frequency.toLowerCase()}
                  </span>
                </div>
              </div>

              {/* Next Due Date Calculation Pill */}
              <div className="mt-4 p-3 rounded-2xl bg-slate-800/40 border border-slate-800 space-y-1.5 text-xs">
                <div className="flex items-center justify-between text-slate-400">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-amber-400" />
                    <span>Next Due Date:</span>
                  </span>
                  <strong className="text-white font-mono">{item.nextDueDate || '2026-10-01'}</strong>
                </div>

                <div className="flex items-center justify-between text-slate-400 text-[11px]">
                  <span>Started:</span>
                  <span className="font-mono">{item.startDate}</span>
                </div>
                {item.endDate && (
                  <div className="flex items-center justify-between text-slate-400 text-[11px]">
                    <span>Expires:</span>
                    <span className="font-mono">{item.endDate}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-1 text-emerald-400 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Auto-Tracked</span>
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      <RecurringModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleCreateRecurring}
      />
    </div>
  );
};
