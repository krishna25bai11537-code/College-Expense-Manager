import React, { useState, useEffect } from 'react';
import {
  Gauge,
  Sparkles,
  BookOpen,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  Award,
  Layers,
  Code,
} from 'lucide-react';
import { scoreApi } from '../services/api';
import { SpendingScore } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';

export const SpendingScorePage: React.FC = () => {
  const [scoreData, setScoreData] = useState<SpendingScore | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        const data = await scoreApi.getScore(9, 2026);
        setScoreData(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  if (loading || !scoreData) {
    return <LoadingSpinner message="Calculating deterministic 4-pillar financial score..." size="lg" />;
  }

  const {
    score,
    status,
    grade,
    feedbackMessage,
    budgetUtilizationScore,
    discretionarySpendingScore,
    categoryDisciplineScore,
    savingsRatioScore,
    totalBudget,
    totalSpent,
    remainingAmount,
    budgetUsedPercentage,
    unnecessarySpendingRatio,
    vivaExplanationPoints,
    studentTips,
  } = scoreData;

  // Gauge calculations
  const radius = 60;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <div className="space-y-6 pb-12 animate-in fade-in">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Student Spending Score
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              Deterministic Viva Model
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            0 to 100 financial health index calculated using transparent mathematical rules in Java.
          </p>
        </div>
      </div>

      {/* Hero Score Showcase */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-500/20 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-center justify-around gap-6 text-center md:text-left">
          
          {/* Circular SVG Gauge */}
          <div className="relative w-44 h-44 flex items-center justify-center shrink-0">
            <svg className="w-44 h-44 transform -rotate-90">
              <circle
                cx="88"
                cy="88"
                r={radius}
                className="text-slate-800"
                strokeWidth="12"
                stroke="currentColor"
                fill="transparent"
              />
              <circle
                cx="88"
                cy="88"
                r={radius}
                className="text-indigo-400 transition-all duration-1000 ease-out"
                strokeWidth="12"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                stroke="currentColor"
                fill="transparent"
              />
            </svg>

            <div className="absolute flex flex-col items-center justify-center">
              <span className="text-4xl sm:text-5xl font-black text-white font-mono">{score}</span>
              <span className="text-xs uppercase font-extrabold text-indigo-400 tracking-wider mt-0.5">
                Grade {grade}
              </span>
            </div>
          </div>

          {/* Status & Feedback */}
          <div className="max-w-md">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 mb-2">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>Verified Financial Health</span>
            </div>

            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight leading-snug">
              {status}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
              {feedbackMessage}
            </p>

            <div className="mt-4 flex flex-wrap gap-2 justify-center md:justify-start text-xs font-mono">
              <span className="px-3 py-1 rounded-xl bg-slate-800/80 border border-slate-700 text-slate-300">
                Budget Consumed: <strong className="text-white">{budgetUsedPercentage}%</strong>
              </span>
              <span className="px-3 py-1 rounded-xl bg-slate-800/80 border border-slate-700 text-slate-300">
                Discretionary Ratio: <strong className="text-white">{unnecessarySpendingRatio}%</strong>
              </span>
            </div>
          </div>

        </div>
      </div>

      {/* 4 Deterministic Mathematical Pillars */}
      <div>
        <h3 className="text-base font-bold text-white mb-3 flex items-center gap-2">
          <Layers className="w-4 h-4 text-indigo-400" />
          <span>The 4 Deterministic Scoring Pillars (Explained for Viva)</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 shadow-md">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-indigo-400 uppercase">Pillar 1</span>
              <span className="text-sm font-extrabold text-white font-mono">{budgetUtilizationScore}/35 pts</span>
            </div>
            <h4 className="text-sm font-bold text-white">Budget Utilization Rate</h4>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Penalizes early-month overspending. Evaluates total expenditures relative to ₹{totalBudget.toLocaleString()} allowance.
            </p>
            <div className="mt-3 w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-indigo-500 h-full rounded-full"
                style={{ width: `${(budgetUtilizationScore / 35) * 100}%` }}
              />
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 shadow-md">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-emerald-400 uppercase">Pillar 2</span>
              <span className="text-sm font-extrabold text-white font-mono">{discretionarySpendingScore}/25 pts</span>
            </div>
            <h4 className="text-sm font-bold text-white">Discretionary Spending</h4>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Measures non-essential wants (Entertainment & Shopping) against survival needs (Food, Hostel, Education).
            </p>
            <div className="mt-3 w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-emerald-500 h-full rounded-full"
                style={{ width: `${(discretionarySpendingScore / 25) * 100}%` }}
              />
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 shadow-md">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-amber-400 uppercase">Pillar 3</span>
              <span className="text-sm font-extrabold text-white font-mono">{categoryDisciplineScore}/20 pts</span>
            </div>
            <h4 className="text-sm font-bold text-white">Category Discipline</h4>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Deducts 8 points for every breached category threshold and 3 points for categories nearing 90% depletion.
            </p>
            <div className="mt-3 w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-amber-500 h-full rounded-full"
                style={{ width: `${(categoryDisciplineScore / 20) * 100}%` }}
              />
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 shadow-md">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-teal-400 uppercase">Pillar 4</span>
              <span className="text-sm font-extrabold text-white font-mono">{savingsRatioScore}/20 pts</span>
            </div>
            <h4 className="text-sm font-bold text-white">Retained Savings Buffer</h4>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Rewards having a safe cushion. Retaining ≥20% of pocket allowance grants top savings buffer points.
            </p>
            <div className="mt-3 w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-teal-500 h-full rounded-full"
                style={{ width: `${(savingsRatioScore / 20) * 100}%` }}
              />
            </div>
          </div>

        </div>
      </div>

      {/* Viva Q&A & Talking Points */}
      <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center space-x-2">
          <BookOpen className="w-5 h-5 text-indigo-400" />
          <h3 className="text-base font-bold text-white">Viva Talking Points & Math Justification</h3>
        </div>

        <div className="space-y-2 text-xs text-slate-300 leading-relaxed font-mono">
          {vivaExplanationPoints.map((point, idx) => (
            <div key={idx} className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
              {point}
            </div>
          ))}
        </div>

        <div className="p-4 rounded-2xl bg-indigo-950/20 border border-indigo-500/20 text-xs text-slate-300">
          <h4 className="font-bold text-white mb-1 flex items-center gap-1.5">
            <Code className="w-4 h-4 text-indigo-400" />
            <span>Why Deterministic Java Logic over AI?</span>
          </h4>
          <p className="leading-relaxed">
            "In a collegiate financial utility, users and project examiners require deterministic results where adding an identical expense produces a strictly predictable mathematical outcome without hallucination, API token costs, or opaque network latency."
          </p>
        </div>
      </div>

    </div>
  );
};
