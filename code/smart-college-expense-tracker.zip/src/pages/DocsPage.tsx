import React, { useState } from 'react';
import {
  BookOpen,
  Terminal,
  Database,
  Layers,
  Server,
  Code2,
  CheckCircle2,
  Copy,
  ExternalLink,
  ShieldCheck,
} from 'lucide-react';

export const DocsPage: React.FC = () => {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const handleCopy = (text: string, sectionId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(sectionId);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in max-w-5xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Architecture, APIs & Viva Guide
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              College Project Spec
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Complete technical documentation, Spring Boot 3 + Java 17 architecture, and MySQL setup guide.
          </p>
        </div>
      </div>

      {/* Tech Stack Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div className="flex items-center space-x-2 text-indigo-400 font-bold text-xs mb-1">
            <Server className="w-4 h-4" />
            <span>Spring Boot 3.2</span>
          </div>
          <p className="text-xs text-white font-semibold">Java 17 + Maven</p>
          <p className="text-[11px] text-slate-400 mt-0.5">REST API, JPA Hibernate, Spring Security</p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div className="flex items-center space-x-2 text-emerald-400 font-bold text-xs mb-1">
            <ShieldCheck className="w-4 h-4" />
            <span>JWT + BCrypt</span>
          </div>
          <p className="text-xs text-white font-semibold">Stateless Auth</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Per-user isolation, Bearer tokens, Claims</p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div className="flex items-center space-x-2 text-amber-400 font-bold text-xs mb-1">
            <Database className="w-4 h-4" />
            <span>MySQL 8.0</span>
          </div>
          <p className="text-xs text-white font-semibold">Relational Schema</p>
          <p className="text-[11px] text-slate-400 mt-0.5">6 relational entities with foreign keys & indexes</p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div className="flex items-center space-x-2 text-teal-400 font-bold text-xs mb-1">
            <Layers className="w-4 h-4" />
            <span>React + Vite</span>
          </div>
          <p className="text-xs text-white font-semibold">Tailwind + Recharts</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Dual Mode: Live Spring Boot & Browser Simulator</p>
        </div>
      </div>

      {/* Layered Architectural Flow Diagram */}
      <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-xl space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <Layers className="w-4 h-4 text-indigo-400" />
          <span>System Architecture Flow</span>
        </h3>

        <div className="p-5 rounded-2xl bg-slate-950/80 border border-slate-800 font-mono text-xs text-slate-300 leading-relaxed overflow-x-auto">
          <div className="text-indigo-400 font-bold mb-2">// Flow Diagram: React → Spring Boot → MySQL</div>
          <pre className="text-slate-300 font-mono text-xs">{`
   [React.js Frontend (Vite + Tailwind + Recharts)]
                           │
                 HTTP REST / Axios (JSON)
                 Authorization: Bearer <JWT>
                           ▼
  ┌──────────────────────────────────────────────────────────┐
  │              Spring Boot Backend (Port 8080)             │
  │                                                          │
  │  JwtAuthenticationFilter  ──►  SecurityFilterChain       │
  │                                         │                │
  │  ┌──────────────────────────────────────▼─────────────┐  │
  │  │ REST Controllers (10 Controllers)                  │  │
  │  │  - AuthController          - ExpenseController     │  │
  │  │  - DashboardController     - BudgetController      │  │
  │  │  - AnalyticsController     - SpendingScoreCtrl     │  │
  │  │  - AlertController         - SharedExpenseCtrl     │  │
  │  │  - RecurringExpenseCtrl    - ReportController      │  │
  │  └──────────────────────┬─────────────────────────────┘  │
  │                         │                                │
  │  ┌──────────────────────▼─────────────────────────────┐  │
  │  │ Service Layer (Business Logic & 4-Pillar Score)    │  │
  │  │  - SpendingScoreService    - DashboardService      │  │
  │  │  - AnalyticsService        - AlertService          │  │
  │  │  - SharedExpenseService    - ReportService (CSV)   │  │
  │  └──────────────────────┬─────────────────────────────┘  │
  │                         │                                │
  │  ┌──────────────────────▼─────────────────────────────┐  │
  │  │ Spring Data JPA Repositories                       │  │
  │  │  - UserRepository          - ExpenseRepository     │  │
  │  │  - BudgetRepository        - SharedExpenseRepo     │  │
  │  │  - RecurringExpenseRepo                            │  │
  │  └──────────────────────┬─────────────────────────────┘  │
  └─────────────────────────┼────────────────────────────────┘
                            │
                     Hibernate ORM
                            ▼
              [ MySQL Database: college_expense_db ]
`}</pre>
        </div>
      </div>

      {/* Spring Boot Setup Instructions */}
      <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-xl space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <Terminal className="w-4 h-4 text-emerald-400" />
          <span>How to Run Spring Boot Backend</span>
        </h3>

        <div className="space-y-3 text-xs text-slate-300">
          <p>
            The backend source code is fully arranged in the <code className="text-indigo-300 font-mono">/backend</code> folder with a complete <code className="text-indigo-300 font-mono">pom.xml</code>, Spring Boot 3 dependencies, JPA entities, and MySQL configuration.
          </p>

          <div className="p-4 rounded-xl bg-slate-950/90 border border-slate-800 font-mono relative">
            <button
              onClick={() =>
                handleCopy(
                  `cd backend\n# Configure MySQL credentials in src/main/resources/application.properties\nmvn clean spring-boot:run`,
                  'bash-cmd'
                )
              }
              className="absolute right-3 top-3 p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
              title="Copy"
            >
              {copiedSection === 'bash-cmd' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
            <div className="text-slate-400">// 1. Navigate to backend directory</div>
            <div className="text-white">cd backend</div>
            <div className="text-slate-400 mt-2">// 2. Start Spring Boot with Maven</div>
            <div className="text-emerald-400">mvn clean spring-boot:run</div>
          </div>
        </div>
      </div>

      {/* Complete REST API Endpoints Catalog */}
      <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-xl space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <Code2 className="w-4 h-4 text-indigo-400" />
          <span>REST API Catalog</span>
        </h3>

        <div className="space-y-2 text-xs">
          {[
            { method: 'POST', path: '/api/auth/register', desc: 'Registers new student with BCrypt hash' },
            { method: 'POST', path: '/api/auth/login', desc: 'Validates credentials & returns JWT token' },
            { method: 'GET', path: '/api/dashboard', desc: 'Monthly summary, top category, KPI metrics' },
            { method: 'GET', path: '/api/expenses', desc: 'List filtered expenses by category, date, search' },
            { method: 'POST', path: '/api/expenses', desc: 'Add new expense record' },
            { method: 'PUT', path: '/api/expenses/{id}', desc: 'Update existing expense' },
            { method: 'DELETE', path: '/api/expenses/{id}', desc: 'Delete expense' },
            { method: 'GET', path: '/api/budget?month=9&year=2026', desc: 'Category budgets & 70%/90%/100% warnings' },
            { method: 'POST', path: '/api/budget/monthly', desc: 'Update total monthly budget' },
            { method: 'POST', path: '/api/budget/category', desc: 'Set category-specific spending limit' },
            { method: 'GET', path: '/api/analytics?month=9&year=2026', desc: 'Donut & line chart data feeds' },
            { method: 'GET', path: '/api/score?month=9&year=2026', desc: '0-100 deterministic financial score' },
            { method: 'GET', path: '/api/alerts', desc: 'Rule-based spending notifications' },
            { method: 'GET', path: '/api/shared-expenses', desc: 'Fetch split bills & participant settlements' },
            { method: 'POST', path: '/api/shared-expenses', desc: 'Create split bill (e.g. Rahul owes Krishna)' },
            { method: 'GET', path: '/api/recurring', desc: 'List active subscriptions & next due dates' },
            { method: 'GET', path: '/api/reports/csv', desc: 'Download CSV spreadsheet of expenses' },
          ].map((api, idx) => (
            <div
              key={idx}
              className="p-3 rounded-xl bg-slate-800/40 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
            >
              <div className="flex items-center space-x-3">
                <span
                  className={`px-2 py-0.5 rounded-md font-mono font-bold text-[10px] uppercase ${
                    api.method === 'GET'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : api.method === 'POST'
                      ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30'
                      : api.method === 'PUT'
                      ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                  }`}
                >
                  {api.method}
                </span>
                <span className="font-mono text-white font-semibold text-xs">{api.path}</span>
              </div>
              <span className="text-slate-400 text-xs">{api.desc}</span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
