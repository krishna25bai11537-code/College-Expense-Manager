import React, { useState } from 'react';
import {
  User,
  GraduationCap,
  Mail,
  Calendar,
  Database,
  ShieldCheck,
  Server,
  LogOut,
  IndianRupee,
  CheckCircle2,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface ProfilePageProps {
  onNotify?: (type: 'success' | 'error' | 'warning' | 'info', message: string) => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({ onNotify }) => {
  const { user, logout, backendMode, setBackendMode } = useAuth();
  const [targetBudget, setTargetBudget] = useState('10000');
  const [saved, setSaved] = useState(false);

  const handleSavePreferences = (e: React.FormEvent) => {
    e.preventDefault();
    setSaved(true);
    onNotify?.('success', 'Student preferences saved successfully');
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-12 animate-in fade-in">
      
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Student Profile & Settings
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Account details, college information, and backend connectivity mode.
        </p>
      </div>

      {/* Profile Card */}
      <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-xl space-y-6">
        <div className="flex items-center space-x-4 pb-6 border-b border-slate-800">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-white text-2xl font-black shadow-lg shadow-indigo-500/20">
            {user?.name?.charAt(0) || 'K'}
          </div>

          <div>
            <h2 className="text-lg font-bold text-white">{user?.name || 'Krishna Sharma'}</h2>
            <div className="flex items-center space-x-2 text-xs text-slate-400 mt-0.5">
              <GraduationCap className="w-3.5 h-3.5 text-indigo-400" />
              <span>{user?.college || 'IIT Delhi'} • Computer Science & Engg</span>
            </div>
            <div className="flex items-center space-x-2 text-xs text-slate-400 mt-0.5">
              <Mail className="w-3.5 h-3.5 text-indigo-400" />
              <span>{user?.email || 'krishna@college.edu'}</span>
            </div>
          </div>
        </div>

        {/* Backend Dual-Mode Configuration Box */}
        <div className="p-5 rounded-2xl bg-slate-800/40 border border-slate-700/60 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-white font-bold text-xs">
              <Server className="w-4 h-4 text-indigo-400" />
              <span>Data Engine & Backend Mode</span>
            </div>
            <span
              className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                backendMode === 'spring-boot'
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                  : 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
              }`}
            >
              {backendMode === 'spring-boot' ? 'Live Spring Boot (Port 8080)' : 'Client-Side Simulator'}
            </span>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            The project features a full <strong>Spring Boot 3 + MySQL</strong> backend ready to run in <code className="text-indigo-300 font-mono">/backend</code>. By default, it operates with a pre-seeded student dataset so you can preview everything immediately in the browser.
          </p>

          <div className="flex items-center space-x-3 pt-2">
            <button
              onClick={() => {
                setBackendMode('simulator');
                onNotify?.('info', 'Switched to Browser Simulator mode');
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition ${
                backendMode === 'simulator'
                  ? 'bg-indigo-600 border-indigo-500 text-white shadow'
                  : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
              }`}
            >
              Use Browser Simulator
            </button>

            <button
              onClick={() => {
                setBackendMode('spring-boot');
                onNotify?.('info', 'Switched to Live Spring Boot mode');
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition ${
                backendMode === 'spring-boot'
                  ? 'bg-emerald-600 border-emerald-500 text-white shadow'
                  : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
              }`}
            >
              Connect to Spring Boot (http://localhost:8080)
            </button>
          </div>
        </div>

        {/* Security & Authentication status */}
        <div className="p-4 rounded-2xl bg-slate-800/20 border border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center space-x-2 text-slate-300">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>JWT Session Token Active</span>
          </div>
          <button
            onClick={() => {
              logout();
              onNotify?.('info', 'Logged out successfully');
            }}
            className="flex items-center space-x-1 text-rose-400 hover:text-rose-300 font-semibold"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

    </div>
  );
};
