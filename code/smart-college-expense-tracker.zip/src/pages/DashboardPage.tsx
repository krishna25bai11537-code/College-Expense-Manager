import React, { useState, useEffect } from 'react';
import {
  Wallet,
  PiggyBank,
  TrendingDown,
  CalendarDays,
  Receipt,
  Flame,
  PlusCircle,
  ArrowRight,
  TrendingUp,
  CreditCard,
  Trash2,
  Edit2,
  Sparkles,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { dashboardApi, expenseApi } from '../services/api';
import { ExpenseCard } from '../components/ExpenseCard';
import { SpendingScoreCard } from '../components/SpendingScoreCard';
import { AlertCard } from '../components/AlertCard';
import { ExpenseModal } from '../components/ExpenseModal';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { Expense, SpendingScore, AlertItem } from '../types';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';

interface DashboardPageProps {
  onNotify?: (type: 'success' | 'error' | 'warning' | 'info', message: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNotify }) => {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<{
    totalExpensesThisMonth: number;
    monthlyBudget: number;
    remainingBudget: number;
    budgetPercentageUsed: number;
    todayExpenses: number;
    totalTransactionsCount: number;
    highestSpendingCategory: string;
    highestCategoryAmount: number;
    recentTransactions: Expense[];
    monthlySpendingTrend: { month: string; amount: number }[];
    recentAlerts: AlertItem[];
    quickSpendingScore: SpendingScore;
  } | null>(null);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);

  const fetchDashboard = async () => {
    try {
      const res = await dashboardApi.getDashboardData();
      setData(res);
    } catch (err) {
      console.error(err);
      onNotify?.('error', 'Failed to fetch dashboard data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboard();
  }, []);

  const handleSaveExpense = async (
    expenseData: Omit<Expense, 'id' | 'userId' | 'createdAt'>,
    id?: number
  ) => {
    try {
      if (id) {
        await expenseApi.updateExpense(id, expenseData);
        onNotify?.('success', 'Expense updated successfully');
      } else {
        await expenseApi.createExpense(expenseData);
        onNotify?.('success', `Added ₹${expenseData.amount} for ${expenseData.category}`);
      }
      await fetchDashboard();
    } catch (err: any) {
      onNotify?.('error', err?.message || 'Failed to save expense');
      throw err;
    }
  };

  const handleDeleteExpense = async (id: number) => {
    if (window.confirm('Delete this expense?')) {
      try {
        await expenseApi.deleteExpense(id);
        onNotify?.('success', 'Expense deleted');
        await fetchDashboard();
      } catch (err: any) {
        onNotify?.('error', 'Failed to delete expense');
      }
    }
  };

  if (loading) {
    return <LoadingSpinner message="Calculating student financial metrics..." size="lg" />;
  }

  if (!data) return null;

  return (
    <div className="space-y-6 pb-12 animate-in fade-in">
      
      {/* Top Banner / Student Greeting */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Student Finance Hub
            </h1>
            <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              September 2026
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time balance, category spending limits, and viva-ready financial score.
          </p>
        </div>

        <button
          onClick={() => {
            setEditingExpense(null);
            setIsModalOpen(true);
          }}
          className="flex items-center justify-center space-x-2 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/25 active:scale-95 transition"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Record New Expense</span>
        </button>
      </div>

      {/* Primary KPI Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        
        <ExpenseCard
          title="Total Spent"
          amount={data.totalExpensesThisMonth}
          subtitle={`${data.budgetPercentageUsed}% of monthly budget`}
          icon={Wallet}
          variant="indigo"
        />

        <ExpenseCard
          title="Monthly Budget"
          amount={data.monthlyBudget}
          subtitle="Fixed Student Target"
          icon={PiggyBank}
          variant="slate"
        />

        <ExpenseCard
          title="Remaining"
          amount={data.remainingBudget}
          subtitle={data.remainingBudget >= 0 ? 'Safe spendable buffer' : 'Over budget limit'}
          icon={TrendingDown}
          variant={data.remainingBudget >= 0 ? 'emerald' : 'rose'}
        />

        <ExpenseCard
          title="Today's Spend"
          amount={data.todayExpenses}
          subtitle="Campus daily burn"
          icon={CalendarDays}
          variant="amber"
        />

        <ExpenseCard
          title="Transactions"
          amount={data.totalTransactionsCount}
          subtitle="Logged this month"
          icon={Receipt}
          variant="slate"
        />

        <ExpenseCard
          title="Top Category"
          amount={data.highestSpendingCategory}
          subtitle={`₹${data.highestCategoryAmount.toLocaleString()} total`}
          icon={Flame}
          variant="rose"
        />

      </div>

      {/* Student Spending Score (Hero Card with Gauge) */}
      <SpendingScoreCard scoreData={data.quickSpendingScore} />

      {/* Smart Alerts Grid */}
      {data.recentAlerts && data.recentAlerts.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Smart Spending Alerts & Pace Warnings</span>
            </h3>
            <span className="text-[11px] text-slate-400">Rule-based backend triggers</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {data.recentAlerts.map((alert) => (
              <AlertCard key={alert.id} alert={alert} />
            ))}
          </div>
        </div>
      )}

      {/* Charts & Recent Transactions Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left 7 cols: Monthly Spending Trend Bar Chart */}
        <div className="lg:col-span-7 p-5 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white tracking-wide">6-Month Spending Trend</h3>
              <p className="text-[11px] text-slate-400">Historical campus spending progression</p>
            </div>
            <Link
              to="/analytics"
              className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center space-x-1"
            >
              <span>Full Analytics</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.monthlySpendingTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis
                  stroke="#94a3b8"
                  fontSize={11}
                  tickLine={false}
                  tickFormatter={(val) => `₹${val}`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '12px',
                    fontSize: '12px',
                    color: '#fff',
                  }}
                  formatter={(val: any) => [`₹${Number(val).toLocaleString()}`, 'Spent']}
                />
                <Bar dataKey="amount" fill="#6366f1" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right 5 cols: Recent Transactions */}
        <div className="lg:col-span-5 p-5 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm font-bold text-white tracking-wide">Recent Expenses</h3>
                <p className="text-[11px] text-slate-400">Latest campus transactions</p>
              </div>
              <Link
                to="/expenses"
                className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center space-x-1"
              >
                <span>View All</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            <div className="space-y-2 max-h-[290px] overflow-y-auto pr-1">
              {data.recentTransactions.length === 0 ? (
                <div className="text-center py-8 text-slate-400 text-xs">
                  No expenses recorded yet.
                </div>
              ) : (
                data.recentTransactions.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 rounded-2xl bg-slate-800/40 hover:bg-slate-800/80 border border-slate-800 transition flex items-center justify-between group"
                  >
                    <div className="flex items-center space-x-3 min-w-0">
                      <div className="w-8 h-8 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center font-bold text-xs shrink-0 border border-indigo-500/20">
                        {item.category.charAt(0)}
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-white truncate">{item.description}</p>
                        <div className="flex items-center space-x-2 text-[10px] text-slate-400 font-mono mt-0.5">
                          <span>{item.category}</span>
                          <span>•</span>
                          <span>{item.paymentMethod}</span>
                          <span>•</span>
                          <span>{item.date}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 shrink-0">
                      <span className="text-xs font-extrabold text-white font-mono">
                        ₹{item.amount.toLocaleString()}
                      </span>

                      <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => {
                            setEditingExpense(item);
                            setIsModalOpen(true);
                          }}
                          className="p-1 text-slate-400 hover:text-white"
                          title="Edit"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteExpense(item.id)}
                          className="p-1 text-slate-400 hover:text-rose-400"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800/80 mt-3">
            <Link
              to="/add-expense"
              className="w-full flex items-center justify-center space-x-2 py-2 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-300 text-xs font-semibold transition border border-slate-700/60"
            >
              <PlusCircle className="w-4 h-4 text-indigo-400" />
              <span>Add Another Expense</span>
            </Link>
          </div>
        </div>

      </div>

      {/* Expense Modal (Add / Edit) */}
      <ExpenseModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveExpense}
        editingExpense={editingExpense}
      />
    </div>
  );
};
