import React, { useState, useEffect } from 'react';
import {
  PiggyBank,
  AlertTriangle,
  AlertCircle,
  CheckCircle2,
  Edit2,
  Save,
  Plus,
  IndianRupee,
  Sparkles,
} from 'lucide-react';
import { budgetApi } from '../services/api';
import { BudgetOverview, CategoryBudgetDetail, Category } from '../types';
import { BudgetProgress } from '../components/BudgetProgress';
import { LoadingSpinner } from '../components/LoadingSpinner';

interface BudgetPageProps {
  onNotify?: (type: 'success' | 'error' | 'warning' | 'info', message: string) => void;
}

export const BudgetPage: React.FC<BudgetPageProps> = ({ onNotify }) => {
  const [overview, setOverview] = useState<BudgetOverview | null>(null);
  const [loading, setLoading] = useState(true);

  // Overall budget editing
  const [isEditingOverall, setIsEditingOverall] = useState(false);
  const [overallAmount, setOverallAmount] = useState('');

  // Category budget editing modal
  const [editingCategory, setEditingCategory] = useState<CategoryBudgetDetail | null>(null);
  const [categoryLimit, setCategoryLimit] = useState('');

  const fetchBudget = async () => {
    try {
      setLoading(true);
      const data = await budgetApi.getBudgetOverview(9, 2026);
      setOverview(data);
      setOverallAmount(data.totalBudget.toString());
    } catch (err) {
      onNotify?.('error', 'Failed to fetch budget details');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBudget();
  }, []);

  const handleSaveOverall = async () => {
    const amt = parseFloat(overallAmount);
    if (isNaN(amt) || amt <= 0) {
      onNotify?.('error', 'Please enter a valid monthly budget');
      return;
    }
    try {
      await budgetApi.setMonthlyBudget(amt, 9, 2026);
      setIsEditingOverall(false);
      onNotify?.('success', `Monthly budget set to ₹${amt.toLocaleString()}`);
      await fetchBudget();
    } catch {
      onNotify?.('error', 'Failed to update monthly budget');
    }
  };

  const handleSaveCategoryLimit = async () => {
    if (!editingCategory) return;
    const amt = parseFloat(categoryLimit);
    if (isNaN(amt) || amt < 0) {
      onNotify?.('error', 'Please enter a valid category limit');
      return;
    }
    try {
      await budgetApi.setCategoryBudget(editingCategory.category, amt, 9, 2026);
      setEditingCategory(null);
      onNotify?.('success', `Updated ${editingCategory.category} budget to ₹${amt.toLocaleString()}`);
      await fetchBudget();
    } catch {
      onNotify?.('error', 'Failed to update category limit');
    }
  };

  if (loading || !overview) {
    return <LoadingSpinner message="Auditing category budget limits..." size="lg" />;
  }

  const { totalBudget, totalSpent, remainingBudget, percentageUsed, warningLevel, warningMessage, categoryBudgets } =
    overview;

  return (
    <div className="space-y-6 pb-12 animate-in fade-in">
      
      {/* Page Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Budget Management & Thresholds
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Configure monthly targets with real-time 70%, 90%, and 100%+ breach warnings.
          </p>
        </div>
      </div>

      {/* Main Overall Monthly Budget Card */}
      <div className="p-6 rounded-3xl bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-500/20 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-semibold text-indigo-400 uppercase tracking-wider">
                Monthly Allowance / Target
              </span>
              <span
                className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                  warningLevel === 'EXCEEDED'
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                    : warningLevel === 'CRITICAL'
                    ? 'bg-orange-500/20 text-orange-300 border-orange-500/30'
                    : warningLevel === 'WARNING'
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                    : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                }`}
              >
                {percentageUsed}% Consumed
              </span>
            </div>

            {isEditingOverall ? (
              <div className="flex items-center space-x-2 mt-2">
                <input
                  type="number"
                  value={overallAmount}
                  onChange={(e) => setOverallAmount(e.target.value)}
                  className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-white font-mono text-xl font-bold focus:outline-none focus:border-indigo-500 w-44"
                />
                <button
                  onClick={handleSaveOverall}
                  className="p-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition flex items-center space-x-1"
                >
                  <Save className="w-4 h-4" />
                  <span>Save</span>
                </button>
                <button
                  onClick={() => setIsEditingOverall(false)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-3 mt-1">
                <span className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                  ₹{totalBudget.toLocaleString()}
                </span>
                <button
                  onClick={() => setIsEditingOverall(true)}
                  className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-indigo-400 transition"
                  title="Edit Total Monthly Budget"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
              </div>
            )}

            <p className="text-xs text-slate-400 mt-2 font-medium">
              Spent ₹{totalSpent.toLocaleString()} of ₹{totalBudget.toLocaleString()} •{' '}
              <strong className={remainingBudget >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                {remainingBudget >= 0
                  ? `₹${remainingBudget.toLocaleString()} remaining`
                  : `Exceeded by ₹${Math.abs(remainingBudget).toLocaleString()}`}
              </strong>
            </p>
          </div>

          {/* Quick Warning Pill */}
          <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/60 text-xs max-w-sm">
            <div className="font-bold text-white mb-1 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>Overall Status:</span>
            </div>
            <p className="text-slate-300">{warningMessage}</p>
          </div>
        </div>

        {/* Global Progress Bar */}
        <div className="mt-6 w-full bg-slate-800 h-3 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              percentageUsed >= 100
                ? 'bg-gradient-to-r from-rose-600 to-red-500'
                : percentageUsed >= 90
                ? 'bg-gradient-to-r from-orange-500 to-amber-500'
                : percentageUsed >= 70
                ? 'bg-gradient-to-r from-amber-400 to-yellow-400'
                : 'bg-gradient-to-r from-indigo-500 to-emerald-400'
            }`}
            style={{ width: `${Math.min(percentageUsed, 100)}%` }}
          />
        </div>

        {/* Threshold Color Legend */}
        <div className="mt-4 flex flex-wrap items-center gap-4 text-[11px] text-slate-400">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
            <span>&lt; 70% Safe</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
            <span>70% - 89% Yellow Warning</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-orange-500"></span>
            <span>90% - 99% Orange Alert</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
            <span>100%+ Red Exceeded</span>
          </span>
        </div>
      </div>

      {/* Category-wise Budgets Section */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight">
              Category-Wise Spending Limits
            </h2>
            <p className="text-xs text-slate-400">
              Personalized thresholds for Food, Travel, Education, Entertainment, and Hostel.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {categoryBudgets.map((detail) => (
            <BudgetProgress
              key={detail.category}
              detail={detail}
              onEdit={(d) => {
                setEditingCategory(d);
                setCategoryLimit(d.budgetedAmount.toString());
              }}
            />
          ))}
        </div>
      </div>

      {/* Category Edit Modal */}
      {editingCategory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-sm w-full p-5 shadow-2xl">
            <h3 className="text-sm font-bold text-white mb-1">
              Edit Budget: {editingCategory.category}
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Set maximum allowable spending for {editingCategory.category} this month.
            </p>

            <div className="mb-4">
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Limit in INR (₹)
              </label>
              <input
                type="number"
                step="any"
                value={categoryLimit}
                onChange={(e) => setCategoryLimit(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold text-base focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="flex justify-end space-x-2 text-xs">
              <button
                onClick={() => setEditingCategory(null)}
                className="px-3.5 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveCategoryLimit}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold"
              >
                Update Limit
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
