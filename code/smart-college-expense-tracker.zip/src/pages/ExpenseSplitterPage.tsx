import React, { useState, useEffect } from 'react';
import {
  Users2,
  Plus,
  ArrowRight,
  CheckCircle2,
  Trash2,
  Receipt,
  IndianRupee,
  Sparkles,
  Calendar,
} from 'lucide-react';
import { sharedExpenseApi } from '../services/api';
import { SharedExpense } from '../types';
import { SplitModal } from '../components/SplitModal';
import { LoadingSpinner } from '../components/LoadingSpinner';

interface ExpenseSplitterPageProps {
  onNotify?: (type: 'success' | 'error' | 'warning' | 'info', message: string) => void;
}

export const ExpenseSplitterPage: React.FC<ExpenseSplitterPageProps> = ({ onNotify }) => {
  const [sharedList, setSharedList] = useState<SharedExpense[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const fetchShared = async () => {
    try {
      setLoading(true);
      const data = await sharedExpenseApi.getSharedExpenses();
      setSharedList(data);
    } catch {
      onNotify?.('error', 'Failed to load shared expenses');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchShared();
  }, []);

  const handleCreateSplit = async (data: {
    title: string;
    totalAmount: number;
    date: string;
    participants: { participantName: string; amountPaid: number }[];
  }) => {
    try {
      await sharedExpenseApi.createSharedExpense(data);
      onNotify?.('success', `Created split bill: ${data.title}`);
      await fetchShared();
    } catch (err: any) {
      onNotify?.('error', err?.message || 'Failed to create split');
      throw err;
    }
  };

  const handleDeleteSplit = async (id: number) => {
    if (window.confirm('Delete this shared bill?')) {
      try {
        await sharedExpenseApi.deleteSharedExpense(id);
        onNotify?.('success', 'Shared bill deleted');
        await fetchShared();
      } catch {
        onNotify?.('error', 'Failed to delete shared bill');
      }
    }
  };

  if (loading) {
    return <LoadingSpinner message="Calculating group debts and settlements..." size="lg" />;
  }

  // Calculate global net balance for current student Krishna
  let netBalanceKrishna = 0;
  sharedList.forEach((s) => {
    s.participants.forEach((p) => {
      if (p.participantName.toLowerCase().includes('krishna') || p.participantName.toLowerCase().includes('you')) {
        netBalanceKrishna += p.netBalance || (p.amountPaid - p.amountOwed);
      }
    });
  });

  return (
    <div className="space-y-6 pb-12 animate-in fade-in">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Expense Splitter
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              Campus Group Bills
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Split hostel food bills, auto fares, and projects among friends with auto-settlement calculations.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center space-x-2 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/25 active:scale-95 transition"
        >
          <Plus className="w-4 h-4" />
          <span>Split a New Bill</span>
        </button>
      </div>

      {/* Net Balance Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-500/20 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
            Your Overall Net Balance
          </span>
          <div className="flex items-center space-x-3 mt-1">
            <span
              className={`text-3xl sm:text-4xl font-black font-mono tracking-tight ${
                netBalanceKrishna >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {netBalanceKrishna >= 0 ? `+₹${netBalanceKrishna.toFixed(0)}` : `-₹${Math.abs(netBalanceKrishna).toFixed(0)}`}
            </span>
            <span className="text-xs text-slate-400">
              {netBalanceKrishna >= 0
                ? 'Your friends owe you this amount overall'
                : 'You owe this amount to your roommates/friends'}
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <div className="p-3 rounded-2xl bg-slate-800/60 border border-slate-700/60 text-xs">
            <span className="text-slate-400 block mb-0.5">Active Split Bills</span>
            <strong className="text-white text-base font-bold">{sharedList.length} Bills</strong>
          </div>
        </div>
      </div>

      {/* Shared Bills List */}
      <div className="space-y-4">
        {sharedList.length === 0 ? (
          <div className="text-center py-16 bg-slate-900/40 border border-slate-800 rounded-3xl">
            <Users2 className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <p className="text-base font-bold text-white">No Shared Bills Yet</p>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              Split lunch bills, Dhaba dinners, or room supplies with Rahul, Aman, Krishna, and Rohan.
            </p>
            <button
              onClick={() => setIsModalOpen(true)}
              className="mt-4 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold"
            >
              Create First Split
            </button>
          </div>
        ) : (
          sharedList.map((bill) => (
            <div
              key={bill.id}
              className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-xl space-y-4 hover:border-slate-700 transition"
            >
              {/* Top Row: Title, Date, Total Amount */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800/80">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center border border-indigo-500/20 shrink-0">
                    <Receipt className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">{bill.title}</h3>
                    <div className="flex items-center space-x-2 text-xs text-slate-400 font-mono mt-0.5">
                      <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                      <span>{bill.date}</span>
                      <span>•</span>
                      <span>{bill.participants.length} Participants</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <span className="text-[11px] text-slate-400 block">Total Bill</span>
                    <span className="text-xl font-black text-white font-mono">
                      ₹{bill.totalAmount.toLocaleString()}
                    </span>
                  </div>

                  <div className="text-right pl-4 border-l border-slate-800">
                    <span className="text-[11px] text-slate-400 block">Per Person</span>
                    <span className="text-sm font-extrabold text-indigo-300 font-mono">
                      ₹{bill.splitPerPerson?.toFixed(2) || (bill.totalAmount / bill.participants.length).toFixed(2)}
                    </span>
                  </div>

                  <button
                    onClick={() => handleDeleteSplit(bill.id)}
                    className="p-2 rounded-xl text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition ml-2"
                    title="Delete split record"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Participant Breakdown Chips */}
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">
                  Participants & Payments
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  {bill.participants.map((p, idx) => {
                    const net = p.netBalance !== undefined ? p.netBalance : (p.amountPaid - p.amountOwed);
                    return (
                      <div
                        key={idx}
                        className="p-3 rounded-2xl bg-slate-800/40 border border-slate-800 flex items-center justify-between text-xs"
                      >
                        <div>
                          <div className="font-bold text-white">{p.participantName}</div>
                          <span className="text-[11px] text-slate-400 font-mono">
                            Paid: ₹{p.amountPaid} • Owed: ₹{p.amountOwed}
                          </span>
                        </div>
                        <div
                          className={`font-mono font-extrabold text-xs px-2 py-0.5 rounded-lg border ${
                            net > 0
                              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                              : net < 0
                              ? 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                              : 'bg-slate-700/30 text-slate-400 border-slate-700'
                          }`}
                        >
                          {net > 0 ? `+₹${net.toFixed(0)}` : net < 0 ? `-₹${Math.abs(net).toFixed(0)}` : 'Settled'}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Settlement Notes (The user's exact required example: "Rahul owes Krishna ₹300") */}
              {bill.settlements && bill.settlements.length > 0 && (
                <div className="p-3.5 rounded-2xl bg-indigo-950/30 border border-indigo-500/20 space-y-1.5">
                  <div className="text-xs font-bold text-indigo-300 flex items-center gap-1.5 mb-1">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Calculated Settlement Breakdown</span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {bill.settlements.map((s, sIdx) => (
                      <div
                        key={sIdx}
                        className="flex items-center justify-between p-2 rounded-xl bg-slate-900/60 border border-indigo-500/10 text-xs font-medium"
                      >
                        <div className="flex items-center space-x-2">
                          <span className="text-white font-bold">{s.fromPerson}</span>
                          <span className="text-slate-400">owes</span>
                          <span className="text-emerald-400 font-bold">{s.toPerson}</span>
                        </div>
                        <span className="font-mono font-extrabold text-white text-xs">
                          ₹{s.amount.toFixed(0)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Modal */}
      <SplitModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleCreateSplit}
      />
    </div>
  );
};
