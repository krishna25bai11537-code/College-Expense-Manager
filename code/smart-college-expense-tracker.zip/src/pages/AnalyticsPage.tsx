import React, { useState, useEffect } from 'react';
import {
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
  CartesianGrid,
} from 'recharts';
import {
  Calendar,
  PieChart as PieIcon,
  BarChart3,
  TrendingUp,
  Award,
  Wallet,
} from 'lucide-react';
import { analyticsApi } from '../services/api';
import { AnalyticsData } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';

const MONTHS = [
  { value: 9, label: 'September 2026' },
  { value: 8, label: 'August 2026' },
  { value: 7, label: 'July 2026' },
  { value: 6, label: 'June 2026' },
];

export const AnalyticsPage: React.FC = () => {
  const [selectedMonth, setSelectedMonth] = useState(9);
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        const data = await analyticsApi.getAnalytics(selectedMonth, 2026);
        setAnalytics(data);
      } catch (err) {
        console.error('Failed to load analytics', err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [selectedMonth]);

  if (loading || !analytics) {
    return <LoadingSpinner message="Generating visual charts and trends..." size="lg" />;
  }

  const { categoryWiseSpending, monthlySpending, weeklySpending, topCategories, totalSpent, totalBudget } =
    analytics;

  return (
    <div className="space-y-6 pb-12 animate-in fade-in">
      
      {/* Top Bar with Month Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Financial Analytics & Insights
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Category distributions, weekly burn rate, and historical spending charts.
          </p>
        </div>

        {/* Month Selector Dropdown */}
        <div className="flex items-center space-x-2 bg-slate-900 border border-slate-800 rounded-2xl p-1.5 shadow">
          <Calendar className="w-4 h-4 text-indigo-400 ml-2" />
          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(Number(e.target.value))}
            className="bg-transparent text-white text-xs font-semibold pr-4 py-1 focus:outline-none cursor-pointer"
          >
            {MONTHS.map((m) => (
              <option key={m.value} value={m.value} className="bg-slate-900 text-white">
                {m.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Top 4 Categories Quick Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {topCategories.map((cat, idx) => (
          <div
            key={cat.category}
            className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 shadow-md flex items-center justify-between"
          >
            <div className="flex items-center space-x-3">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center font-bold text-white text-sm shadow"
                style={{ backgroundColor: `${cat.color}25`, border: `1px solid ${cat.color}50` }}
              >
                #{idx + 1}
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">{cat.category}</h4>
                <p className="text-[11px] text-slate-400 font-mono">
                  {cat.percentage}% of total
                </p>
              </div>
            </div>
            <div className="text-right">
              <span className="text-sm font-black text-white font-mono">
                ₹{cat.amount.toLocaleString()}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Row 1: Donut Category Distribution + Weekly Burn Line */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Category-wise Spending (Donut Chart) */}
        <div className="lg:col-span-5 p-5 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <PieIcon className="w-4 h-4 text-indigo-400" />
                <h3 className="text-sm font-bold text-white">Category-Wise Distribution</h3>
              </div>
              <span className="text-xs font-mono text-slate-400">Total ₹{totalSpent.toLocaleString()}</span>
            </div>

            <div className="h-64 w-full relative flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsPieChart>
                  <Pie
                    data={categoryWiseSpending}
                    cx="50%"
                    cy="50%"
                    innerRadius={65}
                    outerRadius={95}
                    paddingAngle={3}
                    dataKey="amount"
                  >
                    {categoryWiseSpending.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} stroke="#0f172a" strokeWidth={2} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: '#334155',
                      borderRadius: '12px',
                      fontSize: '12px',
                      color: '#fff',
                    }}
                    formatter={(val: any) => [`₹${Number(val).toLocaleString()}`, 'Amount']}
                  />
                </RechartsPieChart>
              </ResponsiveContainer>

              {/* Center Donut Label */}
              <div className="absolute flex flex-col items-center justify-center pointer-events-none text-center">
                <span className="text-xs font-semibold text-slate-400">Total Spend</span>
                <span className="text-lg font-black text-white font-mono">₹{totalSpent.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Color Legend Tags */}
          <div className="grid grid-cols-3 gap-2 mt-4 pt-4 border-t border-slate-800 text-[11px]">
            {categoryWiseSpending.map((c) => (
              <div key={c.category} className="flex items-center space-x-1.5 truncate">
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: c.color }} />
                <span className="text-slate-300 truncate">{c.category}</span>
                <span className="text-slate-500 font-mono text-[10px]">{c.percentage}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Weekly Spending (Line Chart) */}
        <div className="lg:col-span-7 p-5 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-bold text-white">Weekly Spend Velocity (Line Chart)</h3>
              </div>
              <span className="text-xs text-slate-400">Weekly campus burn rate</span>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={weeklySpending}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                  <XAxis dataKey="weekLabel" stroke="#94a3b8" fontSize={11} tickLine={false} />
                  <YAxis
                    stroke="#94a3b8"
                    fontSize={11}
                    tickLine={false}
                    tickFormatter={(v) => `₹${v}`}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: '#334155',
                      borderRadius: '12px',
                      fontSize: '12px',
                      color: '#fff',
                    }}
                    formatter={(val: any) => [`₹${Number(val).toLocaleString()}`, 'Spent']}
                  />
                  <Line
                    type="monotone"
                    dataKey="amount"
                    stroke="#10b981"
                    strokeWidth={3}
                    dot={{ fill: '#10b981', r: 5 }}
                    activeDot={{ r: 7 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-800 text-xs text-slate-300 mt-4 flex items-center justify-between">
            <span>💡 Highest spending observed in Week 2 due to hostel fee settlement and semester books.</span>
          </div>
        </div>

      </div>

      {/* Charts Row 2: Monthly Spending vs Budget (Bar Chart) */}
      <div className="p-5 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <BarChart3 className="w-4 h-4 text-indigo-400" />
            <div>
              <h3 className="text-sm font-bold text-white">Monthly Spending vs Budget (Past 6 Months)</h3>
              <p className="text-[11px] text-slate-400">Compare actual spending against the ₹10,000 monthly target</p>
            </div>
          </div>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={monthlySpending} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
              <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} tickLine={false} />
              <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} tickFormatter={(v) => `₹${v}`} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  borderRadius: '12px',
                  fontSize: '12px',
                  color: '#fff',
                }}
                formatter={(val: any, name: any) => [
                  `₹${Number(val).toLocaleString()}`,
                  name === 'amount' ? 'Actual Spent' : 'Target Budget',
                ]}
              />
              <Legend
                wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }}
                formatter={(val) => (val === 'amount' ? 'Actual Spent' : 'Monthly Budget')}
              />
              <Bar dataKey="amount" fill="#6366f1" radius={[6, 6, 0, 0]} name="amount" />
              <Bar dataKey="budget" fill="#334155" radius={[6, 6, 0, 0]} name="budget" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

    </div>
  );
};
