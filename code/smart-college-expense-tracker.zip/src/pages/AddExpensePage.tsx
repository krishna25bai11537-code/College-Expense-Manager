import React, { useState } from 'react';
import {
  IndianRupee,
  Tag,
  CreditCard,
  AlignLeft,
  Calendar,
  CheckCircle2,
  Sparkles,
  ArrowLeft,
} from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { expenseApi } from '../services/api';
import { Category, PaymentMethod } from '../types';

interface AddExpensePageProps {
  onNotify?: (type: 'success' | 'error' | 'warning' | 'info', message: string) => void;
}

const CATEGORIES: { name: Category; emoji: string; desc: string }[] = [
  { name: 'Food', emoji: '🍔', desc: 'Canteen, mess, dhaba, snacks' },
  { name: 'Travel', emoji: '🚌', desc: 'Auto, metro, bus pass, cab' },
  { name: 'Education', emoji: '📚', desc: 'Books, xerox, courses, project kits' },
  { name: 'Hostel', emoji: '🏠', desc: 'Room rent, laundry, mess advance' },
  { name: 'Entertainment', emoji: '🍿', desc: 'Movies, outings, OTT subscriptions' },
  { name: 'Shopping', emoji: '🛍️', desc: 'Clothing, personal items, gadgets' },
  { name: 'Health', emoji: '💊', desc: 'Gym fees, medicine, wellness' },
  { name: 'Bills', emoji: '⚡', desc: 'Mobile recharge, WiFi, utilities' },
  { name: 'Other', emoji: '📦', desc: 'Miscellaneous campus spends' },
];

const PAYMENT_METHODS: { name: PaymentMethod; desc: string }[] = [
  { name: 'UPI', desc: 'Google Pay, PhonePe, Paytm' },
  { name: 'Cash', desc: 'Cash from pocket/wallet' },
  { name: 'Debit Card', desc: 'Student bank card' },
  { name: 'Credit Card', desc: 'Card or post-paid' },
  { name: 'Other', desc: 'Netbanking / Vouchers' },
];

export const AddExpensePage: React.FC<AddExpensePageProps> = ({ onNotify }) => {
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<Category>('Food');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('UPI');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setError('Please enter a valid amount greater than ₹0.');
      return;
    }
    if (!description.trim()) {
      setError('Please provide a short description or merchant name.');
      return;
    }

    setIsSubmitting(true);
    try {
      await expenseApi.createExpense({
        amount: parsedAmount,
        category,
        paymentMethod,
        description: description.trim(),
        date,
      });
      onNotify?.('success', `Recorded ₹${parsedAmount} for ${category}!`);
      navigate('/expenses');
    } catch (err: any) {
      setError(err?.message || 'Failed to add expense');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-12 animate-in fade-in">
      
      {/* Top Header */}
      <div className="flex items-center space-x-3">
        <Link
          to="/"
          className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-white transition"
        >
          <ArrowLeft className="w-4 h-4" />
        </Link>
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">Record Expense</h1>
          <p className="text-xs text-slate-400">Log campus expenditures to update your live student score.</p>
        </div>
      </div>

      {error && (
        <div className="p-3.5 rounded-2xl bg-rose-950/40 border border-rose-800 text-rose-300 text-xs font-semibold">
          {error}
        </div>
      )}

      {/* Main Form Container */}
      <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-xl backdrop-blur-md">
        <form onSubmit={handleSubmit} className="space-y-6 text-xs">
          
          {/* Amount Field (Hero Input) */}
          <div className="p-5 rounded-2xl bg-slate-800/40 border border-slate-700/60">
            <label className="block text-slate-400 font-semibold mb-1 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <IndianRupee className="w-4 h-4 text-indigo-400" />
                <span>Expense Amount</span>
              </span>
              <span className="text-[11px] text-indigo-400 font-mono">Indian Rupees (₹)</span>
            </label>
            <div className="relative mt-2">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-2xl font-bold text-slate-400">
                ₹
              </span>
              <input
                type="number"
                step="any"
                required
                autoFocus
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-10 pr-4 py-3 text-white text-2xl font-black focus:outline-none focus:border-indigo-500 font-mono tracking-tight"
              />
            </div>
          </div>

          {/* Category Selector Grid */}
          <div>
            <label className="block text-slate-300 font-bold mb-2 flex items-center gap-1.5">
              <Tag className="w-4 h-4 text-indigo-400" />
              <span>Select Category</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {CATEGORIES.map((c) => (
                <button
                  key={c.name}
                  type="button"
                  onClick={() => setCategory(c.name)}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    category === c.name
                      ? 'bg-indigo-600 border-indigo-500 text-white shadow-lg shadow-indigo-600/30 ring-2 ring-indigo-400/50'
                      : 'bg-slate-800/40 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="text-xl mb-1">{c.emoji}</div>
                  <div className="font-bold text-xs">{c.name}</div>
                  <div className={`text-[10px] truncate ${category === c.name ? 'text-indigo-200' : 'text-slate-500'}`}>
                    {c.desc}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Payment Method */}
          <div>
            <label className="block text-slate-300 font-bold mb-2 flex items-center gap-1.5">
              <CreditCard className="w-4 h-4 text-indigo-400" />
              <span>Payment Mode</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {PAYMENT_METHODS.map((pm) => (
                <button
                  key={pm.name}
                  type="button"
                  onClick={() => setPaymentMethod(pm.name)}
                  className={`p-2.5 rounded-xl border text-left transition ${
                    paymentMethod === pm.name
                      ? 'bg-emerald-600 border-emerald-500 text-white shadow'
                      : 'bg-slate-800/40 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="font-bold">{pm.name}</div>
                  <div className={`text-[10px] ${paymentMethod === pm.name ? 'text-emerald-200' : 'text-slate-500'}`}>
                    {pm.desc}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Description & Merchant */}
          <div>
            <label className="block text-slate-300 font-bold mb-1.5 flex items-center gap-1.5">
              <AlignLeft className="w-4 h-4 text-indigo-400" />
              <span>Description / Merchant / Purpose</span>
            </label>
            <input
              type="text"
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Dhaba dinner with roommates, Reference textbook, Metro card reload"
              className="w-full bg-slate-800/80 border border-slate-700 rounded-xl px-4 py-2.5 text-white text-xs focus:outline-none focus:border-indigo-500 font-medium"
            />
          </div>

          {/* Date Picker */}
          <div>
            <label className="block text-slate-300 font-bold mb-1.5 flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-indigo-400" />
              <span>Transaction Date</span>
            </label>
            <input
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full bg-slate-800/80 border border-slate-700 rounded-xl px-4 py-2.5 text-white text-xs focus:outline-none focus:border-indigo-500 font-mono"
            />
          </div>

          {/* Submit Action */}
          <div className="pt-4 border-t border-slate-800 flex items-center justify-end space-x-3">
            <button
              type="button"
              onClick={() => navigate(-1)}
              className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-xs font-extrabold shadow-lg shadow-indigo-600/30 active:scale-95 transition disabled:opacity-50 flex items-center space-x-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isSubmitting ? 'Saving...' : 'Save Expense Record'}</span>
            </button>
          </div>

        </form>
      </div>

    </div>
  );
};
