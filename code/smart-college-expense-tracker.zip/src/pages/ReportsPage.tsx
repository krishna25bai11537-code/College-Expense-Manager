import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  Download,
  Calendar,
  DollarSign,
  TrendingDown,
  PiggyBank,
  CheckCircle2,
  Table,
  IndianRupee,
} from 'lucide-react';
import { reportsApi } from '../services/api';
import { ReportSummary } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';

const MONTHS = [
  { value: 9, label: 'September 2026' },
  { value: 8, label: 'August 2026' },
  { value: 7, label: 'July 2026' },
];

interface ReportsPageProps {
  onNotify?: (type: 'success' | 'error' | 'warning' | 'info', message: string) => void;
}

export const ReportsPage: React.FC<ReportsPageProps> = ({ onNotify }) => {
  const [selectedMonth, setSelectedMonth] = useState(9);
  const [report, setReport] = useState<ReportSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [isExporting, setIsExporting] = useState(false);

  const fetchReport = async () => {
    try {
      setLoading(true);
      const data = await reportsApi.getReportSummary(selectedMonth, 2026);
      setReport(data);
    } catch {
      onNotify?.('error', 'Failed to generate financial report');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReport();
  }, [selectedMonth]);

  const handleDownloadCsv = async () => {
    try {
      setIsExporting(true);
      await reportsApi.downloadCsv(selectedMonth, 2026);
      onNotify?.('success', 'Report exported successfully as CSV');
    } catch {
      onNotify?.('error', 'Failed to download CSV');
    } finally {
      setIsExporting(false);
    }
  };

  if (loading || !report) {
    return <LoadingSpinner message="Assembling monthly financial audit report..." size="lg" />;
  }

  const {
    totalBudget,
    totalSpent,
    netSavings,
    budgetUtilizationPercentage,
    totalTransactions,
    averageExpensePerDay,
    categorySummary,
    budgetReport,
    expenseItems,
  } = report;

  return (
    <div className="space-y-6 pb-12 animate-in fade-in">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Financial Reports & Audits
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Comprehensive monthly balance sheets, category audits, and downloadable CSV spreadsheets.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2 bg-slate-900 border border-slate-800 rounded-2xl p-1.5 shadow">
            <Calendar className="w-4 h-4 text-indigo-400 ml-2" />
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(Number(e.target.value))}
              className="bg-transparent text-white text-xs font-semibold pr-4 py-1 focus:outline-none cursor-pointer"
            >
              {MONTHS.map((m) => (
                <option key={m.value} value={m.value} className="bg-slate-900 text-white">
                  {m.label}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={handleDownloadCsv}
            disabled={isExporting}
            className="flex items-center space-x-2 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow-lg shadow-emerald-600/25 active:scale-95 transition disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>{isExporting ? 'Generating...' : 'Export to CSV'}</span>
          </button>
        </div>
      </div>

      {/* High-Level Financial Summary Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 shadow-md">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Monthly Spent</span>
          <div className="text-2xl font-black text-white font-mono mt-1">₹{totalSpent.toLocaleString()}</div>
          <span className="text-[11px] text-slate-400 mt-1 block">From ₹{totalBudget.toLocaleString()} budget</span>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 shadow-md">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Net Retained Savings</span>
          <div className={`text-2xl font-black font-mono mt-1 ${netSavings >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            ₹{netSavings.toLocaleString()}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {netSavings >= 0 ? 'Pocket balance saved' : 'Overspent budget'}
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 shadow-md">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Utilization Rate</span>
          <div className="text-2xl font-black text-indigo-400 font-mono mt-1">{budgetUtilizationPercentage}%</div>
          <span className="text-[11px] text-slate-400 mt-1 block">{totalTransactions} total transactions</span>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 shadow-md">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Avg Daily Campus Spend</span>
          <div className="text-2xl font-black text-amber-400 font-mono mt-1">₹{averageExpensePerDay.toFixed(0)}</div>
          <span className="text-[11px] text-slate-400 mt-1 block">Per day burn rate</span>
        </div>
      </div>

      {/* Category Audit Table */}
      <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 shadow-xl space-y-4">
        <div>
          <h3 className="text-base font-bold text-white tracking-tight">Category-Wise Budget Audit</h3>
          <p className="text-xs text-slate-400">Analysis of budgeted vs actual expenditures for September 2026.</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-900/90 text-slate-400 uppercase tracking-wider font-semibold">
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Budget Target</th>
                <th className="py-3 px-4">Actual Spent</th>
                <th className="py-3 px-4">Variance (Remaining)</th>
                <th className="py-3 px-4">Utilization</th>
                <th className="py-3 px-4 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {budgetReport.map((b) => (
                <tr key={b.category} className="hover:bg-slate-800/40 transition">
                  <td className="py-3.5 px-4 font-bold text-white">{b.category}</td>
                  <td className="py-3.5 px-4 font-mono text-slate-300">₹{b.budgetedAmount.toLocaleString()}</td>
                  <td className="py-3.5 px-4 font-mono font-bold text-white">₹{b.spentAmount.toLocaleString()}</td>
                  <td className="py-3.5 px-4 font-mono">
                    <span className={b.remainingAmount >= 0 ? 'text-emerald-400' : 'text-rose-400 font-bold'}>
                      {b.remainingAmount >= 0 ? `+₹${b.remainingAmount.toLocaleString()}` : `-₹${Math.abs(b.remainingAmount).toLocaleString()}`}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-mono">
                    <div className="flex items-center space-x-2">
                      <span className="w-10">{b.percentageUsed}%</span>
                      <div className="w-20 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            b.percentageUsed >= 100
                              ? 'bg-rose-500'
                              : b.percentageUsed >= 90
                              ? 'bg-orange-500'
                              : b.percentageUsed >= 70
                              ? 'bg-amber-400'
                              : 'bg-emerald-400'
                          }`}
                          style={{ width: `${Math.min(b.percentageUsed, 100)}%` }}
                        />
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider border ${
                        b.warningLevel === 'EXCEEDED'
                          ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                          : b.warningLevel === 'CRITICAL'
                          ? 'bg-orange-500/20 text-orange-300 border-orange-500/30'
                          : b.warningLevel === 'WARNING'
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                          : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                      }`}
                    >
                      {b.warningLevel}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* CSV Export Banner */}
      <div className="p-6 rounded-3xl bg-emerald-950/20 border border-emerald-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30 shrink-0">
            <FileSpreadsheet className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">Need an Offline Excel / Sheets Copy?</h3>
            <p className="text-xs text-slate-300">
              Download the standard CSV file format with Transaction ID, Category, Payment Method, Date, and Description.
            </p>
          </div>
        </div>

        <button
          onClick={handleDownloadCsv}
          className="flex items-center space-x-2 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2.5 rounded-xl text-xs font-bold transition shadow-lg shadow-emerald-600/30 shrink-0"
        >
          <Download className="w-4 h-4" />
          <span>Download CSV File</span>
        </button>
      </div>

    </div>
  );
};
